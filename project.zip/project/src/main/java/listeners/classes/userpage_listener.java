package listeners.classes;

import events.logic_to_view.send_chats_event;
import events.view_to_logic.userpage.block_event;
import events.view_to_logic.userpage.friend_request_send_event;
import events.view_to_logic.userpage.message_send_event;
import logic.Maincontroller;
import view.controllers.userpage;

public class userpage_listener {
    Maincontroller maincontroller;
    userpage userpage;

    public view.controllers.userpage getUserpage() {
        return userpage;
    }

    public void setUserpage(view.controllers.userpage userpage) {
        this.userpage = userpage;
    }

    public Maincontroller getMaincontroller() {
        return maincontroller;
    }

    public void setMaincontroller(Maincontroller maincontroller) {
        this.maincontroller = maincontroller;
    }

    public void block_form_user_page(block_event b
                                              ){
        maincontroller.block_from_userpage(b);


    }
    public void request_send_from_user_page(friend_request_send_event f){
        maincontroller.send_request(f);
    }
    public void send_mesg(message_send_event event1){
        maincontroller.send_message_userpage(event1);
    }
    public void show_chats(send_chats_event load_chats_event){
        userpage.show_chats_first_time(load_chats_event);
    }

}
