package listeners.classes;

import events.logic_to_view.send_usernames_to_notifpage_event;
import events.logic_to_view.set_mesg_in_editbox_event;
import events.view_to_logic.chatpage_e.add_user_to_group_event;
import events.view_to_logic.chatpage_e.edit_content_msg_event;
import events.view_to_logic.chatpage_e.go_to_chatpage_event;
import events.view_to_logic.explore_e.go_to_user_page_event;
import events.view_to_logic.explore_e.make_hot_list_event;
import events.view_to_logic.personalpage_e.*;
import events.view_to_logic.requests.accepted_req_event;
import events.view_to_logic.requests.bullshit_event;
import events.view_to_logic.requests.initialize_requests_event;
import events.view_to_logic.requests.rejected_req_event;
import events.view_to_logic.tweets_e.forward_tweet_event;
import listeners.interfaces.stringlistener;
import logic.Maincontroller;
import view.controllers.chatpage;
import view.controllers.notifpage;

public class string_listener implements stringlistener {
    public string_listener(Maincontroller maincontroller){
        this.maincontroller=maincontroller;
    }
    Maincontroller maincontroller;
    chatpage chatpage;
    notifpage  notifpage;

    public view.controllers.notifpage getNotifpage() {
        return notifpage;
    }

    public void setNotifpage(view.controllers.notifpage notifpage) {
        this.notifpage = notifpage;
    }

    public view.controllers.chatpage getChatpage() {
        return chatpage;
    }

    public void setChatpage(view.controllers.chatpage chatpage) {
        this.chatpage = chatpage;
    }

    public Maincontroller getMaincontroller() {
        return maincontroller;
    }

    public void setMaincontroller(Maincontroller maincontroller) {
        this.maincontroller = maincontroller;
    }

    @Override
    public void removefollower(followers_remove_event e) {
        maincontroller.remove_from_followers(e);
    }

    @Override
    public void removefollowing(followings_remove_event e) {
        maincontroller.remove_from_followings(e);
    }

    @Override
    public void addblacklist(blacklist_add_event e) {
        maincontroller.add_to_blacklist(e);
    }

    @Override
    public void removeblacklist(blacklist_remove_event e) {
        maincontroller.remove_from_blacklist(e);
    }

    @Override
    public void add_category(add_category_event e) {
        maincontroller.add_cat(e);
    }

    @Override
    public void remove_category(remove_category_event e) {
        maincontroller.remove_cat(e);
    }

    @Override
    public void add_user_category(add_user_to_cat_event e) {
        maincontroller.add_user_to_cat(e);
    }

    @Override
    public void remove_user_category(remove_user_from_cat_event e) {
        maincontroller.remove_user_from_cat(e);
    }

    @Override
    public void go_to_chatpage(go_to_chatpage_event e) {
            maincontroller.load_chats(e);
    }

    @Override
    public void set_msg_in_edit_box(set_mesg_in_editbox_event e) {
            chatpage.set_in_edit_box(e);
    }

    @Override
    public void edit_content_msg_event(edit_content_msg_event e) {
        maincontroller.edit_content_of_msg(e);
    }

    @Override
    public void add_user_to_group(add_user_to_group_event e) {
        maincontroller.add_user_to_group(e.getGroupname(),e.getUsername());
    }

    public void accepted_req(accepted_req_event e){
       maincontroller.accepted_request(e);
    }
    public void rejected_req(rejected_req_event e){
        maincontroller.rejected_request(e);
    }
    public void initialize_reqs(initialize_requests_event e){
        maincontroller.make_request_list();;
    }
    public void initiale_notif_page(send_usernames_to_notifpage_event event){
        notifpage.initialize(event);
    }
    public void initalie_notifs(bullshit_event b){
        notifpage.firstnotifs(b);
    }


}
