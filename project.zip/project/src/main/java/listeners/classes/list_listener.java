package listeners.classes;

import events.logic_to_view.send_chats_event;
import events.logic_to_view.send_list_of_follower_event;
import events.logic_to_view.send_notifs_event;
import events.logic_to_view.update_chats_event;
import events.view_to_logic.forwardpage.send_users_to_logic_event;
import events.view_to_logic.groupmakingpage.make_group_event;
import listeners.interfaces.listlistener;
import logic.Maincontroller;
import view.controllers.Showoptions_c_page;
import view.controllers.chatpage;
import view.controllers.groupmaker;

public class list_listener  implements listlistener {
    Maincontroller maincontroller;

    Showoptions_c_page Showoptions_c_page;
    groupmaker groupmaker;
    chatpage chatpage;

    public view.controllers.chatpage getChatpage() {
        return chatpage;
    }

    public void setChatpage(view.controllers.chatpage chatpage) {
        this.chatpage = chatpage;
    }

    public view.controllers.groupmaker getGroupmaker() {
        return groupmaker;
    }

    public void setGroupmaker(view.controllers.groupmaker groupmaker) {
        this.groupmaker = groupmaker;
    }

    public view.controllers.Showoptions_c_page getShowoptions_c_page() {
        return Showoptions_c_page;
    }

    public void setShowoptions_c_page(view.controllers.Showoptions_c_page showoptions_c_page) {
        Showoptions_c_page = showoptions_c_page;
    }

    public Maincontroller getMaincontroller() {
        return maincontroller;
    }

    public void setMaincontroller(Maincontroller maincontroller) {
        this.maincontroller = maincontroller;
    }

    @Override
    public void send_notifs(send_notifs_event event) {
        Showoptions_c_page.make_notifs(event);
    }

    @Override
    public void send_chats(send_chats_event event) {
        Showoptions_c_page.show_chats_first_time(event);


    }
    public void update_chats(update_chats_event e){
        chatpage.makemessages(e.getMessages(),e.getUsernames(),e.getTypes(),e.getUsername(),e.getUserimagepath());
    }

    @Override
    public void send_users_to_logic(send_users_to_logic_event event) {

    }
    public void send_list_of_group_makes(send_list_of_follower_event event1 ){
        groupmaker.initialize(event1);
    }
    public void make_group(make_group_event e){
        maincontroller.make_new_group(e);
    }
}
