package listeners.classes;

import events.logic_to_view.initialize_forward_message_event;
import events.logic_to_view.send_own_tweets_event;
import events.logic_to_view.send_tweet_n_comments_event;
import events.view_to_logic.tweets_e.*;
import listeners.interfaces.tweeetlistener;
import logic.Maincontroller;
import view.controllers.forwardmessage;
import view.controllers.owntweetbox;
import view.controllers.tweetpage;

public class tweet_listener  implements tweeetlistener {
    public tweet_listener(Maincontroller maincontroller){
        this.maincontroller=maincontroller;
    }
    public tweetpage tweetpage;
    public forwardmessage forwardmessage;

    public view.controllers.forwardmessage getForwardmessage() {
        return forwardmessage;
    }

    public void setForwardmessage(view.controllers.forwardmessage forwardmessage) {
        this.forwardmessage = forwardmessage;
    }

    public view.controllers.tweetpage getTweetpage() {
        return tweetpage;
    }

    public void setTweetpage(view.controllers.tweetpage tweetpage) {
        this.tweetpage = tweetpage;
    }

    public Maincontroller getMaincontroller() {
        return maincontroller;
    }

    public void setMaincontroller(Maincontroller maincontroller) {
        this.maincontroller = maincontroller;
    }

    Maincontroller maincontroller;
    public void send_tweet(send_tweet_event event){
        maincontroller.send_tweet(event);

    }
    public void next_tweet(next_tweet_event event){
        maincontroller.go_to_next_tweet();
    }
    public void previous_tweet(previous_tweet_event event){
        maincontroller.go_to_previous_tweet();
    }
    public void like_tweet(like_tweet_event event){
        maincontroller.like_tweet();
    }
    public void block_writer(block_wrtiter_event event){
        maincontroller.block_wrtier();
    }
    public void add_comment(add_comment_tweet event){
        maincontroller.add_comment(event);
    }

    public void report_writer(report_event event){
        maincontroller.report_tweet();
    }
    public void comment_clicked(comment_clicked event){
        maincontroller.go_to_child(event);
    }
    public void show_tweet(send_tweet_n_comments_event event){
        tweetpage.show(event);
    }
    public void initialize(initiliaze_event event){
        maincontroller.intitialize_tweets_list(event);
    }
    public void go_to_parent(go_to_parent_twitt_event event) {
        maincontroller.go_to_parent_twitt();
    }
    public void retweet(retweet_tweet_event e){
        maincontroller.retweet_tweet();
    }

    public void go_to_writer_page(go_to_writer_page_event  event){
        maincontroller.go_to_writer_page_event(event);
    }
    public void forward_tweet(forward_tweet_event e){
        maincontroller.go_forward_page_t(e);
    }
    public void go_to_forward_page(initialize_forward_message_event e){
        forwardmessage.initialize(e);
    }
    public void send_own_tweets(send_own_tweets_event e){
        owntweetbox.initilze(e);
    }
    public void get_own_tweets_permission(){
        maincontroller.show_own_tweets();
    }
    view.controllers.owntweetbox owntweetbox;

    public view.controllers.owntweetbox getOwntweetbox() {
        return owntweetbox;
    }

    public void setOwntweetbox(view.controllers.owntweetbox owntweetbox) {
        this.owntweetbox = owntweetbox;
    }
}
