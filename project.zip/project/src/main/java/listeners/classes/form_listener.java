package listeners.classes;

import events.logic_to_view.initialize_forward_message_event;
import events.logic_to_view.send_personal_datas_event;
import events.logic_to_view.send_viewed_user_datas_event;
import events.view_to_logic.chatpage_e.*;
import events.view_to_logic.explore_e.go_to_user_page_event;
import events.view_to_logic.explore_e.make_hot_list_event;
import events.view_to_logic.forwardpage.send_users_to_logic_event;
import events.view_to_logic.personalpage_e.edit_user_datas_event;
import events.view_to_logic.loginform_event;
import events.view_to_logic.registrationform_event;
import listeners.interfaces.formlistener;
import logic.Maincontroller;
import view.controllers.Personalpage;
import view.controllers.explore;
import view.controllers.forwardmessage;
import view.controllers.userpage;

public class form_listener implements formlistener {
    Maincontroller maincontroller;
    Personalpage personalpage;
    view.controllers.userpage userpage;
    forwardmessage forwardmessage;

    public view.controllers.explore getExplore() {
        return explore;
    }

    public void setExplore(view.controllers.explore explore) {
        this.explore = explore;
    }

    view.controllers.explore explore;

    public view.controllers.forwardmessage getForwardmessage() {
        return forwardmessage;
    }

    public void setForwardmessage(view.controllers.forwardmessage forwardmessage) {
        this.forwardmessage = forwardmessage;
    }

    public userpage getUserpage() {
        return userpage;
    }

    public void setUserpage(userpage userpage) {
        this.userpage = userpage;
    }

    public Personalpage getPersonalpage() {
        return personalpage;
    }

    public void setPersonalpage(Personalpage personalpage) {
        this.personalpage = personalpage;
    }

    public form_listener(Maincontroller maincontroller) {
        this.maincontroller = maincontroller;
    }

    public Maincontroller getMaincontroller() {
        return maincontroller;
    }

    public void setMaincontroller(Maincontroller maincontroller) {
        this.maincontroller = maincontroller;
    }

    @Override
    public void getform(registrationform_event r) {
        maincontroller.check_valid_registration(r);
    }



    @Override
    public void getform(loginform_event l) {
        maincontroller.check_valid_login(l);
    }

    @Override
    public void sendform(send_personal_datas_event event) {
        personalpage.make_all_labels(event);
    }
    @Override
    public void getform(edit_user_datas_event e){
        maincontroller.edituserpersonaldatas(e);
    }

    public void send_mesg(add_message_event add_message_event){
        maincontroller.add_message(add_message_event);System.out.println("fuck");
    }

    @Override
    public void delete_mesg(delete_message_event event) {
        maincontroller.delete_message(event);
    }

    @Override
    public void edit_mesg(edit_message_event event) {

    }
    public void initialize_forward_page(initialize_forward_message_event event){
        forwardmessage.initialize(event);
    }


    @Override
    public void select_mesg(select_mesg_event event) {
        maincontroller.select_mesg(event);
    }
    public void forward_content(send_users_to_logic_event e){
        maincontroller.forward_to_users(e);
    }
    public void search_user_by_username(go_to_user_page_event e){
        maincontroller.go_to_search_userpage(e);

    }
    public void make_tweets_hot_list(make_hot_list_event e){
        maincontroller.make_hot_list_tweet();
    }


    public void send_other_user_datas(send_viewed_user_datas_event e){
        userpage.initialize(e);
    }
    public void forward_mesg(forward_message_event e){
        maincontroller.go_forward_page_c(e);
    }
    public void edit_content(edit_content_msg_event e){
        maincontroller.edit_content_of_msg(e);
    }
    public void get_ready_to_go_touser_page(send_viewed_user_datas_event e){
        explore.go_to_user_page(e);
    }


}
