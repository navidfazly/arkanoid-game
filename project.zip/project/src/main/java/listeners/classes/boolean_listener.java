package listeners.classes;

import listeners.interfaces.booleanlistener;
import logic.Maincontroller;
import view.controllers.Loginpage;
import view.controllers.Personalpage;
import view.controllers.Registrationpage;

public class boolean_listener implements booleanlistener {
    Registrationpage registrationpage;
    Loginpage loginpage;
    Maincontroller maincontroller;
    Personalpage personalpage;

    public Maincontroller getMaincontroller() {
        return maincontroller;
    }

    public void setMaincontroller(Maincontroller maincontroller) {
        this.maincontroller = maincontroller;
    }

    public Registrationpage getRegistrationpage() {
        return registrationpage;
    }

    public void setRegistrationpage(Registrationpage registrationpage) {
        this.registrationpage = registrationpage;
    }

    public Loginpage getLoginpage() {
        return loginpage;
    }

    public void setLoginpage(Loginpage loginpage) {
        this.loginpage = loginpage;
    }

    @Override
    public void change_to_main_page_r(Boolean b) {
        registrationpage.change_to_mainpage();
    }

    @Override
    public void change_to_main_page_l(Boolean b) {
        loginpage.change_to_mainpage();
    }

    @Override
    public void change_to_personal_page() {

    }
}
