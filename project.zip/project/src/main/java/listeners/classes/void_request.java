package listeners.classes;

import events.view_to_logic.chatpage_e.get_notifs_event;
import events.view_to_logic.groupmakingpage.set_datas_perm_event;
import events.view_to_logic.personalpage_e.go_to_personal_page_event;
import events.view_to_logic.settings_e.*;
import listeners.interfaces.voidrequest;
import logic.Maincontroller;

public class void_request implements voidrequest {
    public void_request(Maincontroller maincontroller){
        this.maincontroller=maincontroller;
    }
    public Maincontroller getMaincontroller() {
        return maincontroller;
    }

    public void setMaincontroller(Maincontroller maincontroller) {
        this.maincontroller = maincontroller;
    }

    Maincontroller maincontroller;
    @Override
    public void change_to_personalpage(go_to_personal_page_event e) {
        maincontroller.send_datas_to_personal_page();
    }

    @Override
    public void delete_acc(delete_acc_event e) {
        maincontroller.delete_acc(e);
    }

    @Override
    public void change_priv_mode(change_privmode_event event) {
        maincontroller.change_prive_mode(event);
    }

    @Override
    public void last_seen_mode(change_last_seen_event event) {
        maincontroller.change_last_seen(event);

    }

    @Override
    public void logout(logout_event event) {
        maincontroller.logout(event);
    }

    @Override
    public void acc_mode(change_accmode_active_event event) {
        maincontroller.change_acc_mode(event);
    }

    @Override
    public void pass_change(pass_change_event event) {
        maincontroller.pass_change(event);
    }

    @Override
    public void get_notifs(get_notifs_event e) {
        maincontroller.initial_notifs(e);
    }

    @Override
    public void set_datas_perm(set_datas_perm_event e) {
        maincontroller.send_datas_to_group_page(e);
    }

    @Override
    public void exit() {
        maincontroller.exit();
    }
}
