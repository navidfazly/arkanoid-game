package listeners;

import listeners.classes.*;
import listeners.interfaces.formlistener;
import listeners.interfaces.voidrequest;
import logic.Maincontroller;
import view.controllers.Loginpage;
import view.controllers.Personalpage;
import view.controllers.Registrationpage;
import view.controllers.Showoptions_c_page;

public class motherlistener {
    Maincontroller maincontroller;
    form_listener form_listener;
    Registrationpage registrationpage;
    Loginpage loginpage;
    boolean_listener boolean_listener;
    string_listener string_listener;
    Personalpage personalpage;
    void_request void_request;
    Showoptions_c_page showoptions_c_page;
    tweet_listener tweet_listener;
    userpage_listener userpage_listener;

    public listeners.classes.userpage_listener getUserpage_listener() {
        return userpage_listener;
    }

    public void setUserpage_listener(listeners.classes.userpage_listener userpage_listener) {
        this.userpage_listener = userpage_listener;
    }

    public listeners.classes.tweet_listener getTweet_listener() {
        return tweet_listener;
    }

    public void setTweet_listener(listeners.classes.tweet_listener tweet_listener) {
        this.tweet_listener = tweet_listener;
    }

    public Showoptions_c_page getShowoptions_c_page() {
        return showoptions_c_page;
    }

    public void setShowoptions_c_page(Showoptions_c_page showoptions_c_page) {
        this.showoptions_c_page = showoptions_c_page;
    }

    public listeners.classes.list_listener getList_listener() {
        return list_listener;
    }

    public void setList_listener(listeners.classes.list_listener list_listener) {
        this.list_listener = list_listener;
    }

    list_listener list_listener;
    public listeners.classes.void_request getVoid_request() {
        return void_request;
    }

    public void setVoid_request(listeners.classes.void_request void_request) {
        this.void_request = void_request;
    }

    public Personalpage getPersonalpage() {
        return personalpage;
    }

    public void setPersonalpage(Personalpage personalpage) {
        this.personalpage = personalpage;
    }

    public listeners.classes.string_listener getString_listener() {
        return string_listener;
    }

    public void setString_listener(listeners.classes.string_listener string_listener) {
        this.string_listener = string_listener;
    }

    public Loginpage getLoginpage() {
        return loginpage;
    }

    public void setLoginpage(Loginpage loginpage) {
        this.loginpage = loginpage;
    }

    public listeners.classes.boolean_listener getBoolean_listener() {
        return boolean_listener;
    }

    public void setBoolean_listener(listeners.classes.boolean_listener boolean_listener) {
        this.boolean_listener = boolean_listener;
    }

    public Maincontroller getMaincontroller() {
        return maincontroller;
    }

    public void setMaincontroller(Maincontroller maincontroller) {
        this.maincontroller = maincontroller;
    }

    public Registrationpage getRegistrationpage() {
        return registrationpage;
    }

    public void setRegistrationpage(Registrationpage registrationpage) {
        this.registrationpage = registrationpage;
    }

    public motherlistener(Maincontroller maincontroller){
        this.maincontroller=maincontroller;
    }
    public void initialize(){
         form_listener=new form_listener(maincontroller);
         boolean_listener=new boolean_listener();
         string_listener=new string_listener(maincontroller);
         void_request =new void_request(maincontroller);
         list_listener=new list_listener();
         list_listener.setMaincontroller(maincontroller);
         userpage_listener=new userpage_listener();
         userpage_listener.setMaincontroller(maincontroller);
        tweet_listener=new tweet_listener(maincontroller);
    }



    public listeners.classes.form_listener getForm_listener() {
        return form_listener;
    }

    public void setForm_listener(listeners.classes.form_listener form_listener) {
        this.form_listener = form_listener;
    }


}
