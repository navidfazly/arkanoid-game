package listeners.interfaces;

public interface tweeetlistener {

}
