package listeners.interfaces;

import events.logic_to_view.send_chats_event;
import events.logic_to_view.send_notifs_event;
import events.view_to_logic.forwardpage.send_users_to_logic_event;

public interface listlistener {
    public void send_notifs(send_notifs_event event);
    public void send_chats(send_chats_event event);
    public void send_users_to_logic(send_users_to_logic_event event);
}
