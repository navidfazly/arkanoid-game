package listeners.interfaces;

import events.logic_to_view.set_mesg_in_editbox_event;
import events.view_to_logic.chatpage_e.add_user_to_group_event;
import events.view_to_logic.chatpage_e.edit_content_msg_event;
import events.view_to_logic.chatpage_e.go_to_chatpage_event;
import events.view_to_logic.personalpage_e.*;

public interface stringlistener {
    public void removefollower(followers_remove_event e);
    public void removefollowing(followings_remove_event e);
    public void addblacklist(blacklist_add_event e);
    public void removeblacklist(blacklist_remove_event e);
    public void add_category( add_category_event e);
    public void remove_category(remove_category_event e);
    public void add_user_category(add_user_to_cat_event e);
    public void remove_user_category(remove_user_from_cat_event e);
    public void go_to_chatpage(go_to_chatpage_event e);
    public void set_msg_in_edit_box(set_mesg_in_editbox_event e);
    public void edit_content_msg_event(edit_content_msg_event e);
    public void add_user_to_group(add_user_to_group_event e);


}
