package listeners.interfaces;

import events.view_to_logic.chatpage_e.get_notifs_event;
import events.view_to_logic.groupmakingpage.set_datas_perm_event;
import events.view_to_logic.personalpage_e.go_to_personal_page_event;
import events.view_to_logic.settings_e.*;

public interface voidrequest {
    public void change_to_personalpage(go_to_personal_page_event e);
    public void delete_acc(delete_acc_event e);
    public void change_priv_mode(change_privmode_event event);
    public void last_seen_mode(change_last_seen_event event);
    public void logout(logout_event event);
    public void acc_mode(change_accmode_active_event event);
    public void pass_change(pass_change_event event);
    public void get_notifs(get_notifs_event e);
    public void set_datas_perm(set_datas_perm_event e);
    public  void exit();

}
