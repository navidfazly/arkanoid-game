package listeners.interfaces;


import events.logic_to_view.send_personal_datas_event;
import events.view_to_logic.chatpage_e.add_message_event;
import events.view_to_logic.chatpage_e.delete_message_event;
import events.view_to_logic.chatpage_e.edit_message_event;
import events.view_to_logic.chatpage_e.select_mesg_event;
import events.view_to_logic.forwardpage.send_users_to_logic_event;
import events.view_to_logic.personalpage_e.edit_user_datas_event;
import events.view_to_logic.loginform_event;
import events.view_to_logic.registrationform_event;

public interface formlistener {
        public void getform(registrationform_event r);

        void getform(loginform_event l);
        void sendform(send_personal_datas_event event);
        public void getform(edit_user_datas_event e);
        public void send_mesg(add_message_event add_message_event);
        public void delete_mesg(delete_message_event event);
        public void edit_mesg(edit_message_event event);
        public void select_mesg(select_mesg_event event);
        }




