package listeners.interfaces;

public interface booleanlistener {
    public void change_to_main_page_r(Boolean b);
    public void change_to_main_page_l(Boolean b);
    public void change_to_personal_page();
}
