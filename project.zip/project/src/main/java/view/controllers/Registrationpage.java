package view.controllers;


import configs.config;
import events.view_to_logic.registrationform_event;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.stage.FileChooser;

import listeners.motherlistener;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;


public class Registrationpage{
    public configs.config getConfig() {
        return config;
    }

    public void setConfig(configs.config config) {
        this.config = config;
    }

    config config;
    graphicmodel graphicmodel;

    public view.controllers.graphicmodel getGraphicmodel() {
        return graphicmodel;
    }

    public void setGraphicmodel(view.controllers.graphicmodel graphicmodel) {
        this.graphicmodel = graphicmodel;
    }

    String imgpath="1";

    public String getImgpath() {
        return imgpath;
    }

    public void setImgpath(String imgpath) {
        this.imgpath = imgpath;
    }

    @FXML
    Pane registerform;
    //    Stage stage= (Stage) registerform.getScene().getWindow();
    motherlistener motherlistener;

    public listeners.motherlistener getMotherlistener() {
        return motherlistener;
    }

    public void setMotherlistener(listeners.motherlistener motherlistener) {
        this.motherlistener = motherlistener;
    }

    public Pane getRegisterform() {
        return registerform;
    }

    public void setRegisterform(Pane registerform) {
        this.registerform = registerform;
    }



    public TextField getEmailfield() {
        return emailfield;
    }

    public void setEmailfield(TextField emailfield) {
        this.emailfield = emailfield;
    }

    public TextField getPhonenumfield() {
        return phonenumfield;
    }

    public void setPhonenumfield(TextField phonenumfield) {
        this.phonenumfield = phonenumfield;
    }

    public TextField getBiofield() {
        return biofield;
    }

    public void setBiofield(TextField biofield) {
        this.biofield = biofield;
    }

    public Button getImagebtn() {
        return imagebtn;
    }

    public void setImagebtn(Button imagebtn) {
        this.imagebtn = imagebtn;
    }

    public ImageView getImageview() {
        return imageview;
    }

    public void setImageview(ImageView imageview) {
        this.imageview = imageview;
    }

    @FXML
    private TextField emailfield;

    @FXML
    private TextField phonenumfield;

    @FXML
    private TextField biofield;

    @FXML
    private TextField namefield;

    @FXML
    private TextField lastnamefield;

    @FXML
    private TextField usernamefield;

    @FXML
    private PasswordField passwordfield;
    @FXML
    private Button imagebtn;

    @FXML
    private ImageView imageview;




    public TextField getNamefield() {
        return namefield;
    }

    public void setNamefield(TextField namefield) {
        this.namefield = namefield;
    }

    public TextField getLastnamefield() {
        return lastnamefield;
    }

    public void setLastnamefield(TextField lastnamefield) {
        this.lastnamefield = lastnamefield;
    }

    public TextField getUsernamefield() {
        return usernamefield;
    }

    public void setUsernamefield(TextField usernamefield) {
        this.usernamefield = usernamefield;
    }

    public PasswordField getPasswordfield() {
        return passwordfield;
    }

    public void setPasswordfield(PasswordField passwordfield) {
        this.passwordfield = passwordfield;
    }

    public void registrationrequest(ActionEvent actionEvent) {

    }
    public void accepted_registration_request(){

    }
    @FXML
    void hello(ActionEvent event) {
        motherlistener.getBoolean_listener().setRegistrationpage(this);
        System.out.println(namefield.getText()+  lastnamefield.getText()+ usernamefield.getText()+ passwordfield.getText()+ emailfield.getText()+phonenumfield.getText()+biofield.getText()+imgpath);
        registrationform_event registrationformevent=new registrationform_event(this,namefield.getText(),lastnamefield.getText(),usernamefield.getText(),passwordfield.getText(),emailfield.getText(),phonenumfield.getText(),biofield.getText(),imgpath);
        motherlistener.getForm_listener().getform(registrationformevent);
    }


    public void addimage(ActionEvent actionEvent) {
        FileChooser fc=new FileChooser();
        fc.getExtensionFilters().add(new FileChooser.ExtensionFilter("Img Files","*.jpg"));
        File file=fc.showOpenDialog(null);

        if(file!=null){

            try {
                FileInputStream inputStream=new FileInputStream(file.getPath());
                Image image=new Image(inputStream);
                imageview.setImage(image);
                imgpath=file.getPath();
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }

        }
    }
    public void change_to_mainpage(){
        FXMLLoader loader = new FXMLLoader(getClass().getResource(config.getProperty("mainpage")));



        try {
            Pane root = loader.load();
            Mainpage mainpage=loader.getController();
            mainpage.setMotherlistener(this.motherlistener);
            graphicmodel.getBacklist().add((AnchorPane) root);
            mainpage.setGraphicmodel(this.graphicmodel);
            mainpage.setConfig(config);
            Scene scene=(Scene) registerform.getScene();
            scene.setRoot(root);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    public void backf(ActionEvent actionEvent) {
        Pane root = graphicmodel.getBacklist().get(graphicmodel.getBacklist().size()-1);
        graphicmodel.getBacklist().remove(graphicmodel.getBacklist().size()-1);
        Scene scene=(Scene) registerform.getScene();
        scene.setRoot(root);

    }
}
