package view.controllers;
import configs.config;
import events.view_to_logic.loginform_event;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import listeners.motherlistener;


import java.io.IOException;

public class Loginpage {
    graphicmodel graphicmodel;

    public view.controllers.graphicmodel getGraphicmodel() {
        return graphicmodel;
    }

    public void setGraphicmodel(view.controllers.graphicmodel graphicmodel) {
        this.graphicmodel = graphicmodel;
    }

    motherlistener motherlistener;

    public listeners.motherlistener getMotherlistener() {
        return motherlistener;
    }

    public void setMotherlistener(listeners.motherlistener motherlistener) {
        this.motherlistener = motherlistener;
    }

    public TextField getUsernamefield() {
        return usernamefield;
    }

    public void setUsernamefield(TextField usernamefield) {
        this.usernamefield = usernamefield;
    }




    @FXML
    private Pane ab;

    @FXML
    private TextField usernamefield;





    @FXML
    private Button enterbtn;

    @FXML
    private PasswordField passwordfiled;



    public void entbtn(javafx.event.ActionEvent actionEvent) {
        motherlistener.getBoolean_listener().setLoginpage(this);
        loginform_event loginformevent=new loginform_event(this,this.usernamefield.getText(),this.passwordfiled.getText());
        motherlistener.getForm_listener().getform(loginformevent);
    }
    public void change_to_mainpage(){
        FXMLLoader loader = new FXMLLoader(getClass().getResource(config.getProperty("mainpage")));



        try {
            Pane root = loader.load();
            Mainpage mainpage=loader.getController();
            graphicmodel.getBacklist().add((AnchorPane) root);
            mainpage.setMotherlistener(this.motherlistener);
            mainpage.setGraphicmodel(this.graphicmodel);
            mainpage.setConfig(config);
            Scene scene=(Scene) ab.getScene();
            scene.setRoot(root);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public configs.config getConfig() {
        return config;
    }

    public void setConfig(configs.config config) {
        this.config = config;
    }

    config config;

    public void backf(ActionEvent actionEvent) {
        Pane root = graphicmodel.getBacklist().get(graphicmodel.getBacklist().size()-1);
        graphicmodel.getBacklist().remove(graphicmodel.getBacklist().size()-1);
        Scene scene=(Scene) ab.getScene();
        scene.setRoot(root);

    }
}
