package view.controllers;

import configs.config;
import events.logic_to_view.send_own_tweets_event;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.control.Label;


public class owntweetbox {
    config config;

    public configs.config getConfig() {
        return config;
    }

    public void setConfig(configs.config config) {
        this.config = config;
    }

    listeners.motherlistener motherlistener ;
    graphicmodel graphicmodel;

    public listeners.motherlistener getMotherlistener() {
        return motherlistener;
    }

    public void setMotherlistener(listeners.motherlistener motherlistener) {
        this.motherlistener = motherlistener;
    }

    public view.controllers.graphicmodel getGraphicmodel() {
        return graphicmodel;
    }

    public void setGraphicmodel(view.controllers.graphicmodel graphicmodel) {
        this.graphicmodel = graphicmodel;
    }

    @FXML
    private AnchorPane anchorpane;

    @FXML
    void backf(ActionEvent event) {
        Pane root = graphicmodel.getBacklist().get(graphicmodel.getBacklist().size()-1);
        graphicmodel.getBacklist().remove(graphicmodel.getBacklist().size()-1);
        Scene scene=(Scene) anchorpane.getScene();
        scene.setRoot(root);

    }
    public void initilze(send_own_tweets_event e){
        vbox.getChildren().clear();
        for(String s:e.getTweets()){
            System.out.println(s);
            Label l=new Label(s);
            l.setStyle("-fx-background-color: #535e4f;");
            vbox.getChildren().add(l);
            vbox.setSpacing(10);
        }


    }

    @FXML
    private VBox vbox;
}
