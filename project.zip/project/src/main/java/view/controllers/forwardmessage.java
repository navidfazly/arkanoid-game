package view.controllers;

import configs.config;
import events.logic_to_view.initialize_forward_message_event;
import events.view_to_logic.forwardpage.send_users_to_logic_event;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import listeners.motherlistener;

import java.util.ArrayList;

public class forwardmessage {
    graphicmodel graphicmodel;
    motherlistener motherlistener;
    @FXML
    private AnchorPane anchorpane;
    @FXML
    void backf(ActionEvent event) {
        Pane root = graphicmodel.getBacklist().get(graphicmodel.getBacklist().size()-1);
        graphicmodel.getBacklist().remove(graphicmodel.getBacklist().size()-1);
        Scene scene=(Scene) anchorpane.getScene();
        scene.setRoot(root);

    }


    public listeners.motherlistener getMotherlistener() {
        return motherlistener;
    }

    public void setMotherlistener(listeners.motherlistener motherlistener) {
        this.motherlistener = motherlistener;
    }

    public view.controllers.graphicmodel getGraphicmodel() {
        return graphicmodel;
    }

    public void setGraphicmodel(view.controllers.graphicmodel graphicmodel) {
        this.graphicmodel = graphicmodel;
    }

    ArrayList<String> usernames=new ArrayList<>();

    public ArrayList<String> getUsernames() {
        return usernames;
    }

    public void setUsernames(ArrayList<String> usernames) {
        this.usernames = usernames;
    }

    @FXML
    private Label messagefield;
    String content;

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    @FXML
    private ScrollPane usersscroll;

    @FXML
    private VBox vbox;

    @FXML
    private TextField addfield;

    @FXML
    void addf(ActionEvent event) {
        usernames.add(addfield.getText());
        addfield.clear();


    }

    @FXML
    void forwardf(ActionEvent event) {
        send_users_to_logic_event  event1=new send_users_to_logic_event(this,usernames);
        event1.setNumber(number);
        motherlistener.getForm_listener().forward_content(event1);
    }
    public void initialize(initialize_forward_message_event event){
        messagefield.setText(event.getContent());
        Label label=new Label(event.getContactnames());
        vbox.getChildren().add(label);


    }
    int number;
    @FXML
    void exitf(ActionEvent event) {
        motherlistener.getVoid_request().exit();
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public configs.config getConfig() {
        return config;
    }

    public void setConfig(configs.config config) {
        this.config = config;
    }

    config config;
}
