package view.controllers;

import configs.config;
import events.view_to_logic.chatpage_e.select_mesg_event;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import listeners.motherlistener;

public class textmessage {
    public configs.config getConfig() {
        return config;
    }

    public void setConfig(configs.config config) {
        this.config = config;
    }

    config config;
    int messageid;
    listeners.motherlistener motherlistener;

    public motherlistener getMotherlistener() {
        return motherlistener;
    }

    public void setMotherlistener(motherlistener motherlistener) {
        this.motherlistener = motherlistener;
    }

    public int getMessageid() {
        return messageid;
    }

    public void setMessageid(int messageid) {
        this.messageid = messageid;
    }

    public Label getMsglabel() {
        return msglabel;
    }

    public void setMsglabel(Label msglabel) {
        this.msglabel = msglabel;
    }

    @FXML
    private Label msglabel;



    @FXML
    void select(MouseEvent event) {

        System.out.println(messageid);
        select_mesg_event  event1=new select_mesg_event(this,messageid);
        motherlistener.getForm_listener().select_mesg(event1);


    }


}
