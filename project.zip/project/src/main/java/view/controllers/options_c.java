package view.controllers;

import configs.config;
import events.view_to_logic.chatpage_e.go_to_chatpage_event;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import listeners.motherlistener;

public class options_c {
    public configs.config getConfig() {
        return config;
    }

    public void setConfig(configs.config config) {
        this.config = config;
    }

    config config;
    graphicmodel graphicmodel;


    public view.controllers.graphicmodel getGraphicmodel() {
        return graphicmodel;
    }

    public void setGraphicmodel(view.controllers.graphicmodel graphicmodel) {
        this.graphicmodel = graphicmodel;
    }

    public listeners.motherlistener getMotherlistener() {
        return motherlistener;
    }

    public void setMotherlistener(listeners.motherlistener motherlistener) {
        this.motherlistener = motherlistener;
    }

    motherlistener motherlistener;
    String number;
    String username;
    String id;

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Label getUsernamefield() {
        return usernamefield;
    }

    public void setUsernamefield(Label usernamefield) {
        this.usernamefield = usernamefield;
    }

    public Label getNumberfield() {
        return numberfield;
    }

    public void setNumberfield(Label numberfield) {
        this.numberfield = numberfield;
    }

    @FXML
    private Label usernamefield;

    @FXML
    private Label numberfield;

    @FXML
    void clicked(MouseEvent event) {
        go_to_chatpage_event go_to_chatpage_event=new go_to_chatpage_event(this,username) ;
        motherlistener.getString_listener().go_to_chatpage(go_to_chatpage_event);
    }

    @FXML
    void clicked1(MouseEvent event) {
        go_to_chatpage_event go_to_chatpage_event=new go_to_chatpage_event(this,username) ;
        motherlistener.getString_listener().go_to_chatpage(go_to_chatpage_event);
    }
}
