package view.controllers;

import configs.config;
import events.logic_to_view.send_chats_event;
import events.logic_to_view.send_viewed_user_datas_event;
import events.view_to_logic.userpage.block_event;
import events.view_to_logic.userpage.friend_request_send_event;
import events.view_to_logic.userpage.message_send_event;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import listeners.motherlistener;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

public class userpage {
    @FXML
    void exitf(ActionEvent event) {
        motherlistener.getVoid_request().exit();
    }
    graphicmodel graphicmodel;
    @FXML
    private AnchorPane anchorpane;
    @FXML
    void backf(ActionEvent event) {
        Pane root = graphicmodel.getBacklist().get(graphicmodel.getBacklist().size()-1);
        graphicmodel.getBacklist().remove(graphicmodel.getBacklist().size()-1);
        Scene scene=(Scene) anchorpane.getScene();
        scene.setRoot(root);

    }

    public view.controllers.graphicmodel getGraphicmodel() {
        return graphicmodel;
    }

    public void setGraphicmodel(view.controllers.graphicmodel graphicmodel) {
        this.graphicmodel = graphicmodel;
    }

    @FXML
    private ImageView img;

    motherlistener motherlistener;

    public motherlistener getMotherlistener() {
        return motherlistener;
    }

    public void setMotherlistener(motherlistener motherlistener) {
        this.motherlistener = motherlistener;
    }

    public Label getName() {
        return name;
    }

    public void setName(Label name) {
        this.name = name;
    }

    public Label getLastseen() {
        return lastseen;
    }

    public void setLastseen(Label lastseen) {
        this.lastseen = lastseen;
    }

    public Label getLastname() {
        return lastname;
    }

    public void setLastname(Label lastname) {
        this.lastname = lastname;
    }

    public Label getUsername() {
        return username;
    }

    public void setUsername(Label username) {
        this.username = username;
    }

    public Label getEmail() {
        return email;
    }

    public void setEmail(Label email) {
        this.email = email;
    }

    public Label getBio() {
        return bio;
    }

    public void setBio(Label bio) {
        this.bio = bio;
    }

    public Button getBlockbtn() {
        return blockbtn;
    }

    public void setBlockbtn(Button blockbtn) {
        this.blockbtn = blockbtn;
    }

    @FXML
    private Label name;

    @FXML
    private Label lastseen;

    @FXML
    private Label lastname;

    @FXML
    private Label username;

    @FXML
    private Label email;

    @FXML
    private Label bio;

    @FXML
    private Button blockbtn;


    @FXML
    void blockf(ActionEvent event) {
        block_event  event1=new block_event(this);
        motherlistener.getUserpage_listener().block_form_user_page(event1);

    }

    @FXML
    void sendf(ActionEvent event) {
        friend_request_send_event event1=new friend_request_send_event(this);
        motherlistener.getUserpage_listener().request_send_from_user_page(event1);
    }
    @FXML
    void sendmesgf(ActionEvent event) {
        message_send_event event1=new message_send_event(this);
        motherlistener.getUserpage_listener().send_mesg(event1);


    }
    public void initialize(send_viewed_user_datas_event event){
        this.name.setText(event.getName());
        this.lastname.setText(event.getLastname());
        this.bio.setText(event.getBio());
        this.email.setText(event.getEmail());
        this.lastseen.setText(event.getLastseen());
        this.username.setText(event.getUsername());
        InputStream inputStream = null;
        try {
            if(event.getImagepath()!=null) {
                inputStream = new FileInputStream(event.getImagepath());
                Image image = new Image(inputStream);
                img.setImage(image);
            }
        } catch (FileNotFoundException e) {

        }

    }
    public void show_chats_first_time(send_chats_event event){
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/configs/scenes/chatpage.fxml"));


        try {
            AnchorPane root = loader.load();
            chatpage chatpage=loader.getController();
            chatpage.setMotherlistener(motherlistener);
            chatpage.setGraphicmodel(this.graphicmodel);
            this.motherlistener.getString_listener().setChatpage(chatpage);
            this.graphicmodel.getBacklist().add(anchorpane);
            chatpage.makemessages(event.getMessages(),event.getUsernames(),event.getTypes(),event.getUsername(),event.getUserimagepath());
            this.motherlistener.getList_listener().setChatpage(chatpage);
            Scene scene1=(Scene)anchorpane.getScene();
            scene1.setRoot(root);

        } catch (IOException e) {

        }
    }

    public config getConfig() {
        return config;
    }

    public void setConfig(config config) {
        this.config = config;
    }

    config config;


}
