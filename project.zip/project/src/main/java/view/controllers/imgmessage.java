package view.controllers;

import events.view_to_logic.chatpage_e.delete_message_event;
import events.view_to_logic.chatpage_e.select_mesg_event;
import javafx.fxml.FXML;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseDragEvent;
import javafx.scene.input.MouseEvent;
import listeners.motherlistener;

public class imgmessage {
    graphicmodel graphicmodel;
    motherlistener motherlistener;

    public listeners.motherlistener getMotherlistener() {
        return motherlistener;
    }

    public void setMotherlistener(listeners.motherlistener motherlistener) {
        this.motherlistener = motherlistener;
    }

    public view.controllers.graphicmodel getGraphicmodel() {
        return graphicmodel;
    }

    public void setGraphicmodel(view.controllers.graphicmodel graphicmodel) {
        this.graphicmodel = graphicmodel;
    }

    int messageid;

    public int getMessageid() {
        return messageid;
    }

    public void setMessageid(int messageid) {
        this.messageid = messageid;
    }
    public ImageView getImg() {
        return img;
    }

    public void setImg(ImageView img) {
        this.img = img;
    }

    @FXML
    private ImageView img;

    @FXML
    void select(MouseEvent event) {
        System.out.println(this.messageid);
        select_mesg_event event1=new select_mesg_event(this,messageid);
        motherlistener.getForm_listener().select_mesg(event1);
    }


}
