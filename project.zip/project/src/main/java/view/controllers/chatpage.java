package view.controllers;

import configs.config;
import events.logic_to_view.send_chats_event;
import events.logic_to_view.set_mesg_in_editbox_event;
import events.view_to_logic.chatpage_e.add_message_event;
import events.view_to_logic.chatpage_e.delete_message_event;
import events.view_to_logic.chatpage_e.edit_content_msg_event;
import events.view_to_logic.chatpage_e.forward_message_event;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import listeners.motherlistener;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;

public class chatpage {
    graphicmodel graphicmodel;

    public view.controllers.graphicmodel getGraphicmodel() {
        return graphicmodel;
    }

    public void setGraphicmodel(view.controllers.graphicmodel graphicmodel) {
        this.graphicmodel = graphicmodel;
    }

    motherlistener motherlistener;

    public listeners.motherlistener getMotherlistener() {
        return motherlistener;
    }

    public void setMotherlistener(listeners.motherlistener motherlistener) {
        this.motherlistener = motherlistener;
    }

    ArrayList<String> messages=new ArrayList<>();
    ArrayList<String> usernames=new ArrayList<>();
    ArrayList<Integer> types=new ArrayList<>();
    String username;
    int currentmessageid;

    public int getCurrentmessageid() {
        return currentmessageid;
    }

    public void setCurrentmessageid(int currentmessageid) {
        this.currentmessageid = currentmessageid;
    }


    @FXML
    private TextField editfield;

    @FXML
    private Button editbtn;

    @FXML
    private TextField searchfield;

    @FXML
    private Button searchbtn;



    @FXML
    void editf(ActionEvent event) {
        String content=editfield.getText();
        edit_content_msg_event event1=new edit_content_msg_event(this,content,currentmessageid);
        System.out.println(currentmessageid);
        motherlistener.getForm_listener().edit_content(event1);
        editfield.clear();


    }




    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public ArrayList<String> getMessages() {
        return messages;
    }

    public void setMessages(ArrayList<String> messages) {
        this.messages = messages;
    }

    public ArrayList<String> getUsernames() {
        return usernames;
    }

    public void setUsernames(ArrayList<String> usernames) {
        this.usernames = usernames;
    }

    public ArrayList<Integer> getTypes() {
        return types;
    }

    public void setTypes(ArrayList<Integer> types) {
        this.types = types;
    }

    String attachment;

    public String getAttachment() {
        return attachment;
    }

    public void setAttachment(String attachment) {
        this.attachment = attachment;
    }

    public TextField getTextfiled() {
        return textfiled;
    }

    public void setTextfiled(TextField textfiled) {
        this.textfiled = textfiled;
    }

    @FXML
    private TextField textfiled;

    @FXML
    private Button sendbtn;

    @FXML
    private Button attachbtn;

    @FXML
    void attachf(ActionEvent event) {
        FileChooser fc=new FileChooser();
        fc.getExtensionFilters().add(new FileChooser.ExtensionFilter("Img Files","*.jpg"));
        File file=fc.showOpenDialog(null);

        if(file!=null){
            attachment=file.getPath();
        }

    }

    @FXML
    void sendf(ActionEvent event) {
        String content=textfiled.getText();

        if(attachment==null){
            messages.add(content);
            usernames.add(username);
            types.add(1);

        }
        else if(attachment!=null){
            content=attachment;
            messages.add(content);
            usernames.add(username);
            types.add(2);
            attachment=null;

        }
        add_message_event adm=new add_message_event(this,content,types.get(types.size()-1));
        motherlistener.getForm_listener().send_mesg(adm);
        textfiled.clear();



    }

    @FXML
    ArrayList<Label> labels;
    @FXML
    ArrayList<Label> ulabels;
    @FXML
    private AnchorPane pane;


    // private GridPane grid;
    @FXML
    private VBox vbox;


    @FXML
    private VBox uvbox;

    @FXML
    private TextField searchtextfield;

    @FXML
    private Button gobutton;
    public void set_in_edit_box(set_mesg_in_editbox_event e){



    }
    @FXML
    void exitf(ActionEvent event) {
        motherlistener.getVoid_request().exit();
    }

    public void makemessages(ArrayList<String> messagess,ArrayList<String> usernamess,ArrayList<Integer> typess,String usernamee,String imgagepath) {
        vbox.getChildren().clear();
        messages=messagess;
        username=usernamee;
        usernames=usernamess;
        types=typess;
        if(imgagepath!=null){
            try{
                FileInputStream inputStream=new FileInputStream(imgagepath);
                Image image=new Image(inputStream);
                userimg.setImage(image);

            } catch (FileNotFoundException e) {

            }
        }

        for (int i = 0; i < messages.size(); i++) {

            if (types.get(i) == 1) {
                FXMLLoader loader = new FXMLLoader(getClass().getResource(config.getProperty("textmessage")));


                try {
                    loader.load();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                textmessage payam =  loader.getController();
                payam.setMotherlistener(motherlistener);

                if (usernames.get(i).equals(username)) {

                    payam.getMsglabel().setText(usernames.get(i) + " : " + messages.get(i));
                    payam.setMessageid(i);

                    payam.getMsglabel().setStyle("-fx-background-color:blue; -fx-background-radius:20; -fx-background-border:black;");

                } else {
                    payam.getMsglabel().setText(usernames.get(i) + " : " + messages.get(i));
                    payam.setMessageid(i);

                    payam.getMsglabel().setStyle("-fx-background-color:white; -fx-background-radius:20; -fx-background-border:black;");

                }


                // label.setMinWidth(100.);
                payam.getMsglabel().setPrefWidth(Region.USE_COMPUTED_SIZE);
                payam.getMsglabel().setMaxWidth(Region.USE_COMPUTED_SIZE);


                payam.getMsglabel().setPrefHeight(Region.USE_COMPUTED_SIZE);
                payam.getMsglabel().setMaxHeight(Region.USE_COMPUTED_SIZE);
                vbox.setAlignment(Pos.CENTER_LEFT);


                vbox.getChildren().add(payam.getMsglabel());
                vbox.setSpacing(7);


            }
            else {
                FXMLLoader loader = new FXMLLoader(getClass().getResource(config.getProperty("imgmessage")));


                try {
                    loader.load();
                    imgmessage img=loader.getController();
                    img.setMotherlistener(motherlistener);
                    img.setMessageid(i);
                    FileInputStream inputStream= null;
                    try {
                        inputStream = new FileInputStream(messages.get(i));
                        Image image=new Image(inputStream);
                        img.getImg().setImage(image);
                        vbox.setAlignment(Pos.CENTER_LEFT);


                        vbox.getChildren().add(img.getImg());
                        vbox.setSpacing(7);
                    } catch (FileNotFoundException e) {

                    }

                } catch (IOException e) {
                    e.printStackTrace();
                }


            }


        }


    }
    public void show_messages_first_time(send_chats_event e1){
        vbox.getChildren().clear();
        messages=e1.getMessages();
        username=e1.getUsername();
        usernames=e1.getUsernames();
        types=e1.getTypes();
        if(e1.getUserimagepath()!=null){
            try{
                FileInputStream inputStream=new FileInputStream(e1.getUserimagepath());
                Image image=new Image(inputStream);
                userimg.setImage(image);

            } catch (FileNotFoundException e) {

            }
        }

        for (int i = 0; i < messages.size(); i++) {

            if (types.get(i) == 1) {
                FXMLLoader loader = new FXMLLoader(getClass().getResource(config.getProperty("textmessage")));


                try {
                    loader.load();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                textmessage payam =  loader.getController();

                if (usernames.get(i).equals(username)) {

                    payam.getMsglabel().setText(usernames.get(i) + " : " + messages.get(i));
                    payam.setMessageid(i);

                    payam.getMsglabel().setStyle("-fx-background-color:blue; -fx-background-radius:20; -fx-background-border:black;");

                } else {
                    payam.getMsglabel().setText(usernames.get(i) + " : " + messages.get(i));
                    payam.setMessageid(i);

                    payam.getMsglabel().setStyle("-fx-background-color:white; -fx-background-radius:20; -fx-background-border:black;");

                }


                // label.setMinWidth(100.);
                payam.getMsglabel().setPrefWidth(Region.USE_COMPUTED_SIZE);
                payam.getMsglabel().setMaxWidth(Region.USE_COMPUTED_SIZE);


                payam.getMsglabel().setPrefHeight(Region.USE_COMPUTED_SIZE);
                payam.getMsglabel().setMaxHeight(Region.USE_COMPUTED_SIZE);
                vbox.setAlignment(Pos.CENTER_LEFT);


                vbox.getChildren().add(payam.getMsglabel());
                vbox.setSpacing(7);


            }
            else {
                FXMLLoader loader = new FXMLLoader(getClass().getResource(config.getProperty("imgmessage")));


                try {
                    loader.load();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                imgmessage img=loader.getController();
                img.setMessageid(i);
                FileInputStream inputStream= null;
                try {
                    inputStream = new FileInputStream(messages.get(i));
                    Image image=new Image(inputStream);
                    img.getImg().setImage(image);
                    vbox.setAlignment(Pos.CENTER_LEFT);


                    vbox.getChildren().add(img.getImg());
                    vbox.setSpacing(7);
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }


            }


        }
    }
    @FXML
    void backf(ActionEvent event) {
        Pane root = graphicmodel.getBacklist().get(graphicmodel.getBacklist().size()-1);
        graphicmodel.getBacklist().remove(graphicmodel.getBacklist().size()-1);
        Scene scene1=(Scene) pane.getScene();
        scene1.setRoot(root);
    }
    @FXML
    void deletf(ActionEvent event) {
        delete_message_event  event1=new delete_message_event(this,currentmessageid);
        System.out.println(currentmessageid);
        motherlistener.getForm_listener().delete_mesg(event1);
    }


    @FXML
    void forwardf(ActionEvent event) {
        FXMLLoader loader = new FXMLLoader(getClass().getResource(config.getProperty("forwardmessage")));

        try {
            Pane root = loader.load();
            forwardmessage forwardmessage=loader.getController();
            forwardmessage.setNumber(1);
            motherlistener.getForm_listener().setForwardmessage(forwardmessage);
            forwardmessage.setMotherlistener(motherlistener);
            forwardmessage.setGraphicmodel(this.graphicmodel);
            forward_message_event event1=new forward_message_event(this,currentmessageid);
            forwardmessage.setConfig(config);

            motherlistener.getForm_listener().forward_mesg(event1);
            graphicmodel.getBacklist().add(pane);

            Scene scene1=(Scene) pane.getScene();
            scene1.setRoot(root);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public configs.config getConfig() {
        return config;
    }

    public void setConfig(configs.config config) {
        this.config = config;
    }

    config config;
    @FXML
    private ImageView userimg;
}
