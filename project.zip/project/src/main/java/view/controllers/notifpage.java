package view.controllers;

import configs.config;
import events.logic_to_view.send_usernames_to_notifpage_event;
import events.view_to_logic.requests.bullshit_event;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import listeners.motherlistener;

import javafx.scene.control.Label;
import java.io.IOException;
import java.util.ArrayList;

public class notifpage {
    public configs.config getConfig() {
        return config;
    }

    public void setConfig(configs.config config) {
        this.config = config;
    }

    config config;
    graphicmodel graphicmodel;
    @FXML
    private VBox notifsbox;@FXML

    private AnchorPane anchorpane;

    motherlistener motherlistener;
    @FXML
    void backf(ActionEvent event) {
        Pane root = graphicmodel.getBacklist().get(graphicmodel.getBacklist().size()-1);
        graphicmodel.getBacklist().remove(graphicmodel.getBacklist().size()-1);
        Scene scene=(Scene) anchorpane.getScene();
        scene.setRoot(root);
    }

    public listeners.motherlistener getMotherlistener() {
        return motherlistener;
    }

    public void setMotherlistener(listeners.motherlistener motherlistener) {
        this.motherlistener = motherlistener;
    }



    public view.controllers.graphicmodel getGraphicmodel() {
        return graphicmodel;
    }

    public void setGraphicmodel(view.controllers.graphicmodel graphicmodel) {
        this.graphicmodel = graphicmodel;
    }

    ArrayList<String> usernames;

    public ArrayList<String> getUsernames() {
        return usernames;
    }

    public void setUsernames(ArrayList<String> usernames) {
        this.usernames = usernames;
    }

    @FXML
    private VBox vbox;
    @FXML
    void exitf(ActionEvent event) {
        motherlistener.getVoid_request().exit();
    }

    public void initialize(send_usernames_to_notifpage_event event1) {
        vbox.getChildren().clear();
        usernames = event1.getUsernames();

        for (String s : usernames) {
            System.out.println(s);
            FXMLLoader loader = new FXMLLoader(getClass().getResource(config.getProperty("requests")));
            try {
                AnchorPane anchorPane = loader.load();
                request req = loader.getController();
                req.setMotherlistener(this.motherlistener);
                req.getNotiffield().setText(s);
                req.setUsername(s);
                vbox.getChildren().add(anchorPane);
                vbox.setSpacing(10);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
        public void firstnotifs(bullshit_event be){
        notifsbox.getChildren().clear();
            for(String s:be.getNotifs()){
                Label label=new Label(s);
                label.setMinWidth(Region.USE_COMPUTED_SIZE);
                label.setPrefWidth(Region.USE_COMPUTED_SIZE);
                label.setMaxWidth(Region.USE_PREF_SIZE);

                //set grid height
                label.setMinHeight(Region.USE_COMPUTED_SIZE);
               label.setPrefHeight(Region.USE_COMPUTED_SIZE);
                label.setMaxHeight(Region.USE_PREF_SIZE);
                label.setStyle("-fx-background-color: green;");
                notifsbox.getChildren().add(label);
                notifsbox.setSpacing(7);


        }



    }

}
