package view.controllers;

import Model.twitt;
import configs.config;
import events.logic_to_view.send_tweet_n_comments_event;
import events.view_to_logic.tweets_e.*;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import listeners.motherlistener;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;

public class tweetpage {

    @FXML
    void exitf(ActionEvent event) {
        motherlistener.getVoid_request().exit();
    }
    public config getConfig() {
        return config;
    }

    public void setConfig(config config) {
        this.config = config;
    }

    config config;
    graphicmodel graphicmodel;
    @FXML
    private ScrollPane tweetpane;


    public view.controllers.graphicmodel getGraphicmodel() {
        return graphicmodel;
    }

    public void setGraphicmodel(view.controllers.graphicmodel graphicmodel) {
        this.graphicmodel = graphicmodel;
    }

    twitt currenttwitt;
    ArrayList<twitt> comments;
    String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ArrayList<twitt> getComments() {
        return comments;
    }

    public void setComments(ArrayList<twitt> comments) {
        this.comments = comments;
    }

    public twitt getCurrenttwitt() {
        return currenttwitt;
    }

    public void setCurrenttwitt(twitt currenttwitt) {
        this.currenttwitt = currenttwitt;
    }

    public listeners.motherlistener getMotherlistener() {
        return motherlistener;
    }

    public void setMotherlistener(listeners.motherlistener motherlistener) {
        this.motherlistener = motherlistener;
    }
    String imgpath;
    String cimgpath;

    public String getCimgpath() {
        return cimgpath;
    }

    public void setCimgpath(String cimgpath) {
        this.cimgpath = cimgpath;
    }

    public String getImgpath() {
        return imgpath;
    }

    public void setImgpath(String imgpath) {
        this.imgpath = imgpath;
    }

    motherlistener motherlistener;
    @FXML
    private TextField addtweetfield;

    @FXML
    private Button addtweet;

    @FXML
    private VBox vboxc;

    @FXML
    private VBox vboxt;


    @FXML
    private AnchorPane tweetpane1;


    @FXML
    private AnchorPane savecommentsfield;

    @FXML
    private ScrollPane commentspane;

    @FXML
    private Button next;

    @FXML
    private Button previous;

    @FXML
    private Button like;

    @FXML
    private Button fowrward;

    @FXML
    private Button block;

    @FXML
    private Button mute;

    @FXML
    private Button writecomment;

    @FXML
    private Button showcomment;

    @FXML
    private Button savetweet;

    @FXML
    private Button gotowriter;

    @FXML
    private Button report;

    @FXML
    private Button sendbtn;

    @FXML
    private TextField commentfiled;

    @FXML
    private Button atchbtn;

    @FXML
    private Button atacht;

    @FXML
    private ImageView userimg;

    public void addtweetf(ActionEvent actionEvent) {
        String content=addtweetfield.getText();

        send_tweet_event event=new send_tweet_event(this,content,imgpath);
        motherlistener.getTweet_listener().send_tweet(event);

    }

    public void nextf(ActionEvent actionEvent) {
        next_tweet_event event =new next_tweet_event(this);
        motherlistener.getTweet_listener().next_tweet(event);

    }

    public void previousf(ActionEvent actionEvent) {
        previous_tweet_event event=new previous_tweet_event(this);
        motherlistener.getTweet_listener().previous_tweet(event);

    }

    public void likef(ActionEvent actionEvent) {
        like_tweet_event event=new like_tweet_event(this);
        motherlistener.getTweet_listener().like_tweet(event);
    }

    public void fowrwardf(ActionEvent actionEvent) {

        this.graphicmodel.getBacklist().add(tweetpane1);
        FXMLLoader loader = new FXMLLoader(getClass().getResource(config.getProperty("forwardmessage")));




        try {
            Pane root = loader.load();
            forwardmessage forwardmessage=loader.getController();
            forwardmessage.setNumber(2);
            this.motherlistener.getTweet_listener().setForwardmessage(forwardmessage);
            forward_tweet_event event=new forward_tweet_event(this,this.currenttwitt.getContent());
            this.motherlistener.getTweet_listener().forward_tweet(event);
          forwardmessage.setGraphicmodel(this.graphicmodel);
          forwardmessage.setMotherlistener(this.motherlistener);
          forwardmessage.setConfig(config);

            Scene scene=(Scene) tweetpane1.getScene();
            scene.setRoot(root);

        } catch (IOException e) {
            e.printStackTrace();
        }





    }

    public void blockf(ActionEvent actionEvent) {
        block_wrtiter_event event=new block_wrtiter_event(this);
        motherlistener.getTweet_listener().block_writer(event);
    }

    public void mutef(ActionEvent actionEvent) {
        block_wrtiter_event event=new block_wrtiter_event(this);
        motherlistener.getTweet_listener().block_writer(event);
    }

    @FXML
    void retweetf(ActionEvent event) {
        retweet_tweet_event e=new retweet_tweet_event(this);
        motherlistener.getTweet_listener().retweet(e);
    }






    public void gotowriterf(ActionEvent actionEvent) {
        go_to_writer_page_event event=new go_to_writer_page_event(this,currenttwitt.getId());
        this.graphicmodel.getBacklist().add(tweetpane1);
        FXMLLoader loader = new FXMLLoader(getClass().getResource(config.getProperty("userpage")));




        try {
            Pane root = loader.load();
            userpage userpage=loader.getController();
            userpage.setMotherlistener(motherlistener);
            userpage.setGraphicmodel(this.graphicmodel);
            motherlistener.getForm_listener().setUserpage(userpage);
            motherlistener.getUserpage_listener().setUserpage(userpage);
            Scene scene=(Scene) tweetpane1.getScene();
            scene.setRoot(root);

        } catch (IOException e) {
            e.printStackTrace();
        }
        motherlistener.getTweet_listener().go_to_writer_page(event);

    }

    public void reportf(ActionEvent actionEvent) {
        report_event event=new report_event(this);
        motherlistener.getTweet_listener().report_writer(event);
    }

    public void sendf(ActionEvent actionEvent) {

        add_comment_tweet event=new add_comment_tweet(this,commentfiled.getText(),cimgpath);
        motherlistener.getTweet_listener().add_comment(event);
    }


    @FXML
    void atachc(ActionEvent event) {
        FileChooser fc=new FileChooser();
        fc.getExtensionFilters().add(new FileChooser.ExtensionFilter("Img Files","*.jpg"));
        File file=fc.showOpenDialog(null);

        if(file!=null) {
            cimgpath=file.getPath();

        }

    }

    @FXML
    void atacht(ActionEvent event) {
        FileChooser fc=new FileChooser();
        fc.getExtensionFilters().add(new FileChooser.ExtensionFilter("Img Files","*.jpg"));
        File file=fc.showOpenDialog(null);

        if(file!=null) {
            imgpath=file.getPath();


        }
    }

    public void atactf(ActionEvent actionEvent) {

    }
    public void set_tweet_in_context(){
        vboxt.getChildren().clear();
        if(currenttwitt!=null){
            if(currenttwitt.getImgpath()!=null){
                FXMLLoader loader = new FXMLLoader(getClass().getResource(config.getProperty("fullcomment")));
                try {
                    AnchorPane pane=loader.load();
                    Fullcomment fullcomment=loader.getController();
                    fullcomment.imgpath=currenttwitt.getImgpath();
                    fullcomment.text=currenttwitt.getContent();
                    fullcomment.tweetid=currenttwitt.getId();
                    fullcomment.getLabel().setText(currenttwitt.getName()+" : "+"\n"+currenttwitt.getContent()+"\n"+"likes number: "+currenttwitt.getLikenum()+" reports number: "+currenttwitt.getReportsnum());
                    FileInputStream inputStream=new FileInputStream(currenttwitt.getImgpath());
                    Image image=new Image(inputStream);
                    fullcomment.getImgview().setImage(image);
                    fullcomment.setMotherlistener(this.motherlistener);
                    vboxt.getChildren().add(0,pane);
                } catch (IOException e) {

                }


            }
            else {
                FXMLLoader loader = new FXMLLoader(getClass().getResource(config.getProperty("textcomment")));
                try {
                    Label label=loader.load();
                    textcomment textcomment=loader.getController();
                    textcomment.tweetid=currenttwitt.getId();
                    textcomment.setMotherlistener(this.motherlistener);
                    textcomment.getLabel().setText(currenttwitt.getName()+" : "+"\n"+currenttwitt.getContent()+"\n"+"likes number: "+currenttwitt.getLikenum()+" reports number: "+currenttwitt.getReportsnum());
                    vboxt.getChildren().add(0,label);
                } catch (IOException e) {

                }

            }
        }




    }
    public void set_comments_in_context(){
        int ind=0;
        vboxc.getChildren().clear();
        for(twitt t:comments){
            System.out.println(t.getContent());
            if(t.getImgpath()!=null){
                FXMLLoader loader = new FXMLLoader(getClass().getResource(config.getProperty("fullcomment")));
                try {
                    AnchorPane pane=loader.load();
                    Fullcomment fullcomment=loader.getController();
                    fullcomment.imgpath=t.getImgpath();
                    fullcomment.text=t.getContent();
                    fullcomment.tweetid=t.getId();
                    fullcomment.getLabel().setText(t.getName()+" : "+"\n"+t.getContent()+"\n"+"likes number: "+t.getLikenum()+" reports number: "+t.getReportsnum());
                    FileInputStream inputStream=new FileInputStream(t.getImgpath());
                    Image image=new Image(inputStream);
                    fullcomment.getImgview().setImage(image);
                    fullcomment.setMotherlistener(motherlistener);
                    vboxc.getChildren().add(ind,pane);
                } catch (IOException e) {

                }


            }
            else {
                FXMLLoader loader = new FXMLLoader(getClass().getResource(config.getProperty("textcomment")));
                try {

                    Label label=loader.load();
                    textcomment textcomment=loader.getController();
                    textcomment.tweetid=t.getId();
                    textcomment.setMotherlistener(motherlistener);
                    textcomment.getLabel().setText(t.getName()+" : "+"\n"+t.getContent()+"\n"+"likes number: "+t.getLikenum()+" reports number: "+t.getReportsnum());
                    textcomment.setMotherlistener(this.motherlistener);

                    vboxc.getChildren().add(ind,label);
                } catch (IOException e) {

                }

            }
            ind++;
        }

    }
    public void show(send_tweet_n_comments_event event){
        currenttwitt=event.getCurrenttwitt();
        comments=event.getComments();
        if(event.getUserimgepath()!=null){
            try{
                FileInputStream inputStream=new FileInputStream(event.getUserimgepath());
                Image image=new Image(inputStream);
                userimg.setImage(image);

            } catch (FileNotFoundException e) {

            }
        }
        set_comments_in_context();
        set_tweet_in_context();
        System.out.println("done");

    }
    @FXML
    void backf(ActionEvent event) {
        go_to_parent_twitt_event event1=new go_to_parent_twitt_event(this);
        motherlistener.getTweet_listener().go_to_parent(event1);
    }

    @FXML
    void backtomain(ActionEvent event) {
        Pane root = graphicmodel.getBacklist().get(graphicmodel.getBacklist().size()-1);
        graphicmodel.getBacklist().remove(graphicmodel.getBacklist().size()-1);
        Scene scene=(Scene) tweetpane1.getScene();
        scene.setRoot(root);

    }

}
