package view.controllers;

import configs.config;
import events.view_to_logic.tweets_e.comment_clicked;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import listeners.motherlistener;

public class textcomment {
    public configs.config getConfig() {
        return config;
    }

    public void setConfig(configs.config config) {
        this.config = config;
    }

    config config;

    int tweetid;
    String text;
    listeners.motherlistener motherlistener;

    public motherlistener getMotherlistener() {
        return motherlistener;
    }

    public void setMotherlistener(motherlistener motherlistener) {
        this.motherlistener = motherlistener;
    }

    public int getTweetid() {
        return tweetid;
    }

    public void setTweetid(int tweetid) {
        this.tweetid = tweetid;
    }

    public Label getLabel() {
        return label;
    }

    public void setLabel(Label label) {
        this.label = label;
    }

    @FXML
    private Label label;

    @FXML
    void clicked(MouseEvent event) {
        comment_clicked e=new comment_clicked(this,tweetid);
        motherlistener.getTweet_listener().comment_clicked(e);

    }
}
