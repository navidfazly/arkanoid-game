package view.controllers;

import configs.config;
import events.view_to_logic.chatpage_e.get_notifs_event;
import events.view_to_logic.personalpage_e.go_to_personal_page_event;
import events.view_to_logic.requests.initialize_requests_event;
import events.view_to_logic.tweets_e.initiliaze_event;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import listeners.motherlistener;

import java.io.IOException;

public class Mainpage {
    graphicmodel graphicmodel;

    public view.controllers.graphicmodel getGraphicmodel() {
        return graphicmodel;
    }

    public void setGraphicmodel(view.controllers.graphicmodel graphicmodel) {
        this.graphicmodel = graphicmodel;
    }

    public listeners.motherlistener getMotherlistener() {
        return motherlistener;
    }

    public void setMotherlistener(listeners.motherlistener motherlistener) {
        this.motherlistener = motherlistener;
    }

    motherlistener motherlistener;
    @FXML
    private AnchorPane scene;

    @FXML
    private Button personalpage;

    @FXML
    private Button timeline;

    @FXML
    private Button explore;

    @FXML
    private Button chats;

    @FXML
    private Button settings;

    public void personalpagebtn(ActionEvent actionEvent) {

        FXMLLoader loader = new FXMLLoader(getClass().getResource(config.getProperty("personalpage")));



        try {
            AnchorPane root = loader.load();
            Personalpage personalpage=loader.getController();
            personalpage.setMotherlistener(this.motherlistener);
            this.graphicmodel.getBacklist().add(scene);
            this.graphicmodel.getBacklist().add(scene);
            personalpage.setGraphicmodel(this.graphicmodel);
            personalpage.setConfig(config);
            motherlistener.setPersonalpage( personalpage);
            motherlistener.getForm_listener().setPersonalpage(personalpage);
            Scene scene1=(Scene) scene.getScene();
            scene1.setRoot(root);
            go_to_personal_page_event  event=new go_to_personal_page_event(this);
            motherlistener.getVoid_request().change_to_personalpage(event);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void timelinebtn(ActionEvent actionEvent) {
        FXMLLoader loader = new FXMLLoader(getClass().getResource(config.getProperty("tweetpage")));
        try {
            AnchorPane root = loader.load();
            tweetpage  tweetpage=loader.getController();
            this.graphicmodel.getBacklist().add(scene);
            this.graphicmodel.getBacklist().add(scene);
            tweetpage.setGraphicmodel(this.graphicmodel);
            tweetpage.setMotherlistener(this.motherlistener);
            tweetpage.setConfig(config);
            motherlistener.getTweet_listener().setTweetpage(tweetpage);
            initiliaze_event event=new initiliaze_event(this);
            motherlistener.getTweet_listener().initialize(event);


            Scene scene1=(Scene) scene.getScene();
            scene1.setRoot(root);


        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void explorebtn(ActionEvent actionEvent) {
        FXMLLoader loader = new FXMLLoader(getClass().getResource(config.getProperty("explore")));
        try {
            AnchorPane root = loader.load();
            explore explore=loader.getController();
            this.graphicmodel.getBacklist().add(scene);
            this.graphicmodel.getBacklist().add(scene);
            explore.setGraphicmodel(this.graphicmodel);
            explore.setMotherlistener(this.motherlistener);
            explore.setConfig(config);
           motherlistener.getForm_listener().setExplore(explore);



            Scene scene1=(Scene) scene.getScene();
            scene1.setRoot(root);


        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void chatsbtn(ActionEvent actionEvent) {
        FXMLLoader loader = new FXMLLoader(getClass().getResource(config.getProperty("showoptions_c_page")));
        try {
            AnchorPane root = loader.load();
            this.graphicmodel.getBacklist().add(scene);

            Showoptions_c_page showoptionsCPage=loader.getController();
            showoptionsCPage.setMotherlistener(motherlistener);
            showoptionsCPage.setGraphicmodel(this.graphicmodel);
            showoptionsCPage.setConfig(config);
            motherlistener.getList_listener().setShowoptions_c_page(showoptionsCPage);
            get_notifs_event event =new get_notifs_event(this);
            motherlistener.getVoid_request().get_notifs(event);


            Scene scene1=(Scene) scene.getScene();
            scene1.setRoot(root);


        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void settingbtn(ActionEvent actionEvent) {
        FXMLLoader loader = new FXMLLoader(getClass().getResource(config.getProperty("settings")));
        try {
            AnchorPane root = loader.load();
            this.graphicmodel.getBacklist().add(scene);
            this.graphicmodel.getBacklist().add(scene);
            Settings settings=loader.getController();
            settings.setMotherlistener(motherlistener);
            settings.setGraphicmodel(this.graphicmodel);
            settings.setConfig(config);


            Scene scene1=(Scene) scene.getScene();
            scene1.setRoot(root);


        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    void notifsf(ActionEvent event) {
        FXMLLoader loader = new FXMLLoader(getClass().getResource(config.getProperty("notifpage")));

        try {
            Pane root = loader.load();
            notifpage notifpage=loader.getController();
            this.graphicmodel.getBacklist().add(scene);
            this.graphicmodel.getBacklist().add(scene);
            notifpage.setMotherlistener(motherlistener);
            notifpage.setGraphicmodel(this.graphicmodel);
            notifpage.setConfig(config);
            initialize_requests_event e=new initialize_requests_event(this);

            motherlistener.getString_listener().setNotifpage(notifpage);
            motherlistener.getString_listener().initialize_reqs(e);
            Scene scene1=(Scene)scene .getScene();
            scene1.setRoot(root);

        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public configs.config getConfig() {
        return config;
    }

    public void setConfig(configs.config config) {
        this.config = config;
    }

    config config;


}
