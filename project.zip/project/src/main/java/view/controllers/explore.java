package view.controllers;

import configs.config;
import events.logic_to_view.send_viewed_user_datas_event;
import events.view_to_logic.explore_e.go_to_user_page_event;
import events.view_to_logic.explore_e.make_hot_list_event;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;

import java.io.IOException;

public class explore {
    graphicmodel graphicmodel;
    listeners.motherlistener motherlistener;
    @FXML
    private AnchorPane anchorpane;
    @FXML
    void exitf(ActionEvent event) {
       motherlistener.getVoid_request().exit();
    }

    public listeners.motherlistener getMotherlistener() {
        return motherlistener;
    }

    public void setMotherlistener(listeners.motherlistener motherlistener) {
        this.motherlistener = motherlistener;
    }

    public view.controllers.graphicmodel getGraphicmodel() {
        return graphicmodel;
    }

    public void setGraphicmodel(view.controllers.graphicmodel graphicmodel) {
        this.graphicmodel = graphicmodel;
    }

    @FXML
    private TextField usernamefield;

    public void searchbtn(ActionEvent actionEvent) {
        go_to_user_page_event  event=new go_to_user_page_event(this,usernamefield.getText());
        motherlistener.getForm_listener().search_user_by_username(event);
    }

    public void showtweets(ActionEvent actionEvent) {

        FXMLLoader loader = new FXMLLoader(getClass().getResource(config.getProperty("tweetpage")));
        try {
            AnchorPane root = loader.load();
            tweetpage  tweetpage=loader.getController();
            this.graphicmodel.getBacklist().add(anchorpane);
            tweetpage.setGraphicmodel(this.graphicmodel);
            tweetpage.setMotherlistener(this.motherlistener);
            tweetpage.setConfig(config);
            motherlistener.getTweet_listener().setTweetpage(tweetpage);
            make_hot_list_event event=new make_hot_list_event(this);
            motherlistener.getForm_listener().make_tweets_hot_list(event);


            Scene scene1=(Scene) anchorpane.getScene();
            scene1.setRoot(root);


        } catch (IOException e) {
            e.printStackTrace();
        }


    }
    public void go_to_user_page(send_viewed_user_datas_event e){
        FXMLLoader loader = new FXMLLoader(getClass().getResource(config.getProperty("userpage")));

        try {
            Pane root = loader.load();
            userpage userpage=loader.getController();
            userpage.setMotherlistener(motherlistener);
            userpage.setGraphicmodel(this.graphicmodel);
            userpage.initialize(e);
            userpage.setConfig(config);
            motherlistener.getUserpage_listener().setUserpage(userpage);
            Scene scene=(Scene) anchorpane.getScene();
            scene.setRoot(root);

        } catch (IOException ioException) {
            ioException.printStackTrace();
        }
    }
    @FXML
    void backf(ActionEvent event) {
        Pane root = graphicmodel.getBacklist().get(graphicmodel.getBacklist().size()-1);
        graphicmodel.getBacklist().remove(graphicmodel.getBacklist().size()-1);
        Scene scene=(Scene) anchorpane.getScene();
        scene.setRoot(root);
    }

    public configs.config getConfig() {
        return config;
    }

    public void setConfig(configs.config config) {
        this.config = config;
    }

    config config;

}
