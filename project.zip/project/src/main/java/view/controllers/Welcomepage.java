package view.controllers;

import configs.config;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import listeners.motherlistener;

import java.io.IOException;

public class Welcomepage {
    motherlistener motherlistener;
    graphicmodel graphicmodel;
    config config;

    public config getConfig() {
        return config;
    }

    public void setConfig(config config) {
        this.config = config;
    }

    public view.controllers.graphicmodel getGraphicmodel() {
        return graphicmodel;
    }

    public void setGraphicmodel(view.controllers.graphicmodel graphicmodel) {
        this.graphicmodel = graphicmodel;
    }

    public listeners.motherlistener getMotherlistener() {
        return motherlistener;
    }

    public void setMotherlistener(listeners.motherlistener motherlistener) {
        this.motherlistener = motherlistener;
    }

    public Pane a;
    public void handleButtonAction(ActionEvent actionEvent) {
        FXMLLoader loader = new FXMLLoader(getClass().getResource(config.getProperty("registrationpage")));


        try {
            Pane root = loader.load();
            Registrationpage registrationpage=loader.getController();
            graphicmodel.getBacklist().add((AnchorPane) a);
            registrationpage.setMotherlistener(motherlistener);
            registrationpage.setGraphicmodel(this.graphicmodel);
            registrationpage.setConfig(config);
            Scene scene=(Scene) a.getScene();
            scene.setRoot(root);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void loginbtn(ActionEvent actionEvent) {
        FXMLLoader loader = new FXMLLoader(getClass().getResource(config.getProperty("loginpage")));

        try {
            Pane root = loader.load();
            graphicmodel.getBacklist().add((AnchorPane) a);
            Loginpage loginpage=loader.getController();
            loginpage.setMotherlistener(motherlistener);
            loginpage.setGraphicmodel(this.graphicmodel);
            loginpage.setConfig(config);
            Scene scene=(Scene) a.getScene();
            scene.setRoot(root);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
