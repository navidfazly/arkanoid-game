package view.controllers;

import configs.config;
import events.logic_to_view.send_chats_event;
import events.logic_to_view.send_notifs_event;
import events.view_to_logic.chatpage_e.add_user_to_group_event;
import events.view_to_logic.groupmakingpage.set_datas_perm_event;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Region;
import listeners.motherlistener;

import java.io.IOException;
import java.util.ArrayList;

public class Showoptions_c_page {
    graphicmodel graphicmodel;

    public view.controllers.graphicmodel getGraphicmodel() {
        return graphicmodel;
    }

    public void setGraphicmodel(view.controllers.graphicmodel graphicmodel) {
        this.graphicmodel = graphicmodel;
    }

    motherlistener motherlistener;

    public listeners.motherlistener getMotherlistener() {
        return motherlistener;
    }

    public void setMotherlistener(listeners.motherlistener motherlistener) {
        this.motherlistener = motherlistener;
    }

    @FXML
    private ScrollPane scroll;
    @FXML
    private AnchorPane scene;

    @FXML
    private GridPane grid;
    @FXML
    void make_new_groupf(ActionEvent event) {
        FXMLLoader loader = new FXMLLoader(getClass().getResource(config.getProperty("groupmaker")));


        try {
            Pane root = loader.load();
            groupmaker groupmaker=loader.getController();
            groupmaker.setMotherlistener(motherlistener);
            motherlistener.getList_listener().setGroupmaker(groupmaker);
            set_datas_perm_event event1=new set_datas_perm_event(this);
            motherlistener.getVoid_request().set_datas_perm(event1);
            this.graphicmodel.getBacklist().add(scene);
            groupmaker.setGraphicmodel(this.graphicmodel);
            groupmaker.setConfig(config);
            Scene scene1=(Scene) scene.getScene();
            scene1.setRoot(root);

        } catch (IOException e) {
            e.printStackTrace();
        }

    }
    public void make_notifs(send_notifs_event send_notifs_event){
        ArrayList<String> usernames=send_notifs_event.getUsernames();
        ArrayList<Integer> messagenums=send_notifs_event.getMessagenums();
        int row=0;
        int column=0;
        for(int i=0;i<usernames.size();i++){
            if(column==4){
                row++;
                column=0;
            }

            FXMLLoader loader = new FXMLLoader(getClass().getResource(config.getProperty("options_c")));

            try {
               AnchorPane anchorPane = loader.load();
               options_c option=loader.getController();
               option.setMotherlistener(this.motherlistener);
               option.getNumberfield().setText(String.valueOf(messagenums.get(i)));
               option.getUsernamefield().setText(usernames.get(i));
               option.setUsername(usernames.get(i));
               option.setConfig(config);
              //  AnchorPane root = loader1.load();
              //  chatpage chatpage=loader1.getController();
              //  chatpage.setMotherlistener(motherlistener);
              //  chatpage.setGraphicmodel(this.graphicmodel);
             //   this.motherlistener.getList_listener().setChatpage(chatpage);
             //   this.motherlistener.getString_listener().setChatpage(chatpage);

                grid.add(anchorPane, column++, row); //(child,column,row)
                //set grid width
                grid.setMinWidth(Region.USE_COMPUTED_SIZE);
                grid.setPrefWidth(Region.USE_COMPUTED_SIZE);
                grid.setMaxWidth(Region.USE_PREF_SIZE);

                //set grid height
                grid.setMinHeight(Region.USE_COMPUTED_SIZE);
                grid.setPrefHeight(Region.USE_COMPUTED_SIZE);
                grid.setMaxHeight(Region.USE_PREF_SIZE);

                GridPane.setMargin(anchorPane, new Insets(10));
            } catch (IOException e) {
                e.printStackTrace();
            }








        }

    }
    public void show_chats_first_time(send_chats_event event){
        FXMLLoader loader = new FXMLLoader(getClass().getResource(config.getProperty("chatpage")));


        try {
            AnchorPane root = loader.load();
            chatpage chatpage=loader.getController();
            chatpage.setMotherlistener(motherlistener);
            chatpage.setGraphicmodel(this.graphicmodel);chatpage.setConfig(config);
            this.motherlistener.getString_listener().setChatpage(chatpage);
            this.graphicmodel.getBacklist().add(scene);
            chatpage.makemessages(event.getMessages(),event.getUsernames(),event.getTypes(),event.getUsername(),event.getUserimagepath());
            this.motherlistener.getList_listener().setChatpage(chatpage);

            Scene scene1=(Scene) scene.getScene();
            scene1.setRoot(root);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    @FXML
    void exitf(ActionEvent event) {
        motherlistener.getVoid_request().exit();
    }

    @FXML
    void backf(ActionEvent event) {
        Pane root = graphicmodel.getBacklist().get(graphicmodel.getBacklist().size()-1);
        graphicmodel.getBacklist().remove(graphicmodel.getBacklist().size()-1);
        Scene scene1=(Scene) scene.getScene();
        scene1.setRoot(root);
    }

    public configs.config getConfig() {
        return config;
    }

    public void setConfig(configs.config config) {
        this.config = config;
    }

    config config;
    @FXML
    private TextField usernamefield;

    @FXML
    private TextField grounnamefield;
    @FXML
    void adduser(ActionEvent event) {
        if(usernamefield!=null && grounnamefield!=null){
            add_user_to_group_event e=new add_user_to_group_event(this,grounnamefield.getText(),usernamefield.getText());
            grounnamefield.clear();
            usernamefield.clear();
            motherlistener.getString_listener().add_user_to_group(e);
        }

    }

}
