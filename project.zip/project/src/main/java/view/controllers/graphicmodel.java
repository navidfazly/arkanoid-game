package view.controllers;

import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;

import java.util.ArrayList;

public class graphicmodel {
    ArrayList<AnchorPane> backlist=new ArrayList<>();

    public ArrayList<AnchorPane> getBacklist() {
        return backlist;
    }

    public void setBacklist(ArrayList<AnchorPane> backlist) {
        this.backlist = backlist;
    }
}
