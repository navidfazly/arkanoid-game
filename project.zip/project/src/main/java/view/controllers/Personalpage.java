package view.controllers;

import configs.config;
import events.logic_to_view.send_personal_datas_event;
import events.view_to_logic.personalpage_e.*;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.stage.FileChooser;
import listeners.motherlistener;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class Personalpage {
    public configs.config getConfig() {
        return config;
    }

    public void setConfig(configs.config config) {
        this.config = config;
    }

    config config;
    @FXML
    private AnchorPane personalpane;

    graphicmodel graphicmodel;

    public view.controllers.graphicmodel getGraphicmodel() {
        return graphicmodel;
    }

    public void setGraphicmodel(view.controllers.graphicmodel graphicmodel) {
        this.graphicmodel = graphicmodel;
    }

    motherlistener motherlistener;

    public listeners.motherlistener getMotherlistener() {
        return motherlistener;
    }

    public void setMotherlistener(listeners.motherlistener motherlistener) {
        this.motherlistener = motherlistener;
    }

    String imgpath;

    public String getImgpath() {
        return imgpath;
    }

    public void setImgpath(String imgpath) {
        this.imgpath = imgpath;
    }

    @FXML
    private TextField namefiled;

    @FXML
    private TextField lastnamefield;

    @FXML
    private TextField emailfield;

    @FXML
    private TextField phonenumfiled;

    @FXML
    private TextField biofield;

    @FXML
    private TextField usernamefield;

    @FXML
    private ImageView imageview;
    @FXML
    private Button savebtn;

    @FXML
    private Label blacklist;

    @FXML
    private Label followerslist;

    @FXML
    private Label followingslist;

    @FXML
    private TextField blisttext;

    @FXML
    private TextField followerslisttext;

    @FXML
    private TextField followingslisttext;

    @FXML
    private Button blistremove;

    @FXML
    private Button followerslistremove;

    @FXML
    private Button followinglistadd;

    @FXML
    private Button blistadd;

    @FXML
    private Label categorylist;

    @FXML
    private Button addcategory;

    @FXML
    private Button removecategory;

    @FXML
    private Button addusertocat;

    @FXML
    private Button removeuserfromcat;
    @FXML
    private TextField categoryfiled;

    @FXML
    private TextField userfiled;

    @FXML
    private TextField catuserfiled;

    @FXML
    void setimg(ActionEvent event) {
        FileChooser fc = new FileChooser();
        fc.getExtensionFilters().add(new FileChooser.ExtensionFilter("Img Files", "*.jpg"));
        File file = fc.showOpenDialog(null);

        if (file != null) {

            try {
                FileInputStream inputStream = new FileInputStream(file.getPath());
                Image image = new Image(inputStream);
                imageview.setImage(image);
                imgpath = file.getPath();
            } catch (FileNotFoundException e) {

            }


        }
    }
    @FXML
    void addcategoryf(ActionEvent event) {
        add_category_event e=new add_category_event(this,categoryfiled.getText());
        motherlistener.getString_listener().add_category(e);


    }

    @FXML
    void addusertocatf(ActionEvent event) {
        add_user_to_cat_event e=new add_user_to_cat_event(this,catuserfiled.getText(),userfiled.getText());

        motherlistener.getString_listener().add_user_category(e);

    }

    @FXML
    void blistaddf(ActionEvent event) {

        blacklist_add_event blacklisttadd_event =new blacklist_add_event(this,this.blisttext.getText());
        blisttext.clear();
        motherlistener.getString_listener().addblacklist(blacklisttadd_event);
    }

    @FXML
    void blistremovef(ActionEvent event) {
        blacklist_remove_event blacklistremove_event= new blacklist_remove_event(this,this.blisttext.getText());
        blisttext.clear();
        motherlistener.getString_listener().removeblacklist(blacklistremove_event);

    }

    @FXML
    void followerslistremovef(ActionEvent event) {

        followers_remove_event followerlistremove_event=new followers_remove_event(this,this.followerslisttext.getText());
        followerslisttext.clear();
        motherlistener.getString_listener().removefollower(followerlistremove_event);
    }

    @FXML
    void followinglistaddf(ActionEvent event) {
        followings_remove_event followinglistremove_event =new followings_remove_event(this,this.followingslisttext.getText());
        followingslisttext.clear();
        motherlistener.getString_listener().removefollowing(followinglistremove_event);
    }

    @FXML
    void removecaegoryf(ActionEvent event) {
        remove_category_event e=new remove_category_event(this,categoryfiled.getText());
        motherlistener.getString_listener().remove_category(e);


    }

    @FXML
    void removeuserfromcatf(ActionEvent event) {
        remove_user_from_cat_event e=new remove_user_from_cat_event(this,catuserfiled.getText(),userfiled.getText());
        motherlistener.getString_listener().remove_user_category(e);

    }

    @FXML
    void savef(ActionEvent event) {
        edit_user_datas_event edituserdatasevent=new edit_user_datas_event(this,this.namefiled.getText(),this.lastnamefield.getText(),this.usernamefield.getText(),this.emailfield.getText(),this.phonenumfiled.getText(),this.biofield.getText(),this.imgpath);
        motherlistener.getForm_listener().getform(edituserdatasevent);





    }
    public void make_all_labels(send_personal_datas_event e){
        namefiled.setText(e.getName());
        lastnamefield.setText(e.getLastname());
        usernamefield.setText(e.getUsername());
        emailfield.setText(e.getEmail());
        phonenumfiled.setText(e.getPhonenum());
        biofield.setText(e.getBio());
        followingslist.setText(e.getFollowinglist());
        followerslist.setText(e.getFollowerslist());
        blacklist.setText(e.getBlacklist());
        categorylist.setText(e.getCategories());
        if(e.getImgpath()!=null){
            FileInputStream inputStream= null;
            try {
                inputStream = new FileInputStream(e.getImgpath());
                Image image=new Image(inputStream);
                imageview.setImage(image);

            } catch (FileNotFoundException fileNotFoundException) {
            }

        }
    }
    @FXML
    void backf(ActionEvent event) {
        Pane root = graphicmodel.getBacklist().get(graphicmodel.getBacklist().size()-1);
        graphicmodel.getBacklist().remove(graphicmodel.getBacklist().size()-1);
        Scene scene=(Scene) personalpane.getScene();
        scene.setRoot(root);


    }
    @FXML
    void exitf(ActionEvent event) {
        motherlistener.getVoid_request().exit();
    }
    @FXML
    void showtweetsf(ActionEvent event) {

        FXMLLoader loader = new FXMLLoader(getClass().getResource(config.getProperty("owntweetbox")));

        try {
            Pane root = loader.load();
            owntweetbox owntweetbox=loader.getController();
            motherlistener.getTweet_listener().setOwntweetbox(owntweetbox);
            owntweetbox.setMotherlistener(motherlistener);
            owntweetbox.setGraphicmodel(this.graphicmodel);
            motherlistener.getTweet_listener().setOwntweetbox(owntweetbox);
            Scene scene=(Scene) personalpane.getScene();
            scene.setRoot(root);
            motherlistener.getTweet_listener().get_own_tweets_permission();

        } catch (IOException e) {

        }
    }

}


