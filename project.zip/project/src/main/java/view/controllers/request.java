package view.controllers;

import configs.config;
import events.view_to_logic.requests.accepted_req_event;
import events.view_to_logic.requests.rejected_req_event;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import listeners.motherlistener;

public class request {
    public configs.config getConfig() {
        return config;
    }

    public void setConfig(configs.config config) {
        this.config = config;
    }

    config config;
    graphicmodel graphicmodel;
    motherlistener motherlistener;

    public listeners.motherlistener getMotherlistener() {
        return motherlistener;
    }

    public void setMotherlistener(listeners.motherlistener motherlistener) {
        this.motherlistener = motherlistener;
    }

    public view.controllers.graphicmodel getGraphicmodel() {
        return graphicmodel;
    }

    public void setGraphicmodel(view.controllers.graphicmodel graphicmodel) {
        this.graphicmodel = graphicmodel;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    String username;



    @FXML
    private Label notiffield;

    public Label getNotiffield() {
        return notiffield;
    }

    public void setNotiffield(Label notiffield) {
        this.notiffield = notiffield;
    }

    @FXML
    void acceptf(ActionEvent event) {
        accepted_req_event event1= new accepted_req_event(this,username);
        System.out.println(username);
        motherlistener.getString_listener().accepted_req(event1);

    }

    @FXML
    void rejectf(ActionEvent event) {
        rejected_req_event event1=new rejected_req_event(this,username);
        motherlistener.getString_listener().rejected_req(event1);

    }
}
