package view.controllers;

import configs.config;
import events.view_to_logic.settings_e.*;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import listeners.motherlistener;

import java.io.IOException;

public class Settings {
    public configs.config getConfig() {
        return config;
    }

    public void setConfig(configs.config config) {
        this.config = config;
    }

    config config;
    @FXML
    private AnchorPane settingpane;
    graphicmodel graphicmodel;

    public view.controllers.graphicmodel getGraphicmodel() {
        return graphicmodel;
    }

    public void setGraphicmodel(view.controllers.graphicmodel graphicmodel) {
        this.graphicmodel = graphicmodel;
    }

    @FXML
    private TextField passwordfiled;
    motherlistener motherlistener;

    public listeners.motherlistener getMotherlistener() {
        return motherlistener;
    }

    public void setMotherlistener(listeners.motherlistener motherlistener) {
        this.motherlistener = motherlistener;
    }

    public void deleteaccf(ActionEvent actionEvent) {
        delete_acc_event event=new delete_acc_event(this);
        motherlistener.getVoid_request().delete_acc(event);
        FXMLLoader loader = new FXMLLoader(getClass().getResource(config.getProperty("welcomepage_path")));

        try {
            Pane root = loader.load();
            Welcomepage welcomepage=loader.getController();
            welcomepage.setMotherlistener(motherlistener);
            welcomepage.setGraphicmodel(graphicmodel);
            welcomepage.setConfig(config);
            Scene scene=(Scene) settingpane.getScene();
            scene.setRoot(root);

        } catch (IOException e) {
            e.printStackTrace();
        }


    }
    @FXML
    void exitf(ActionEvent event) {
        motherlistener.getVoid_request().exit();
    }
    public void logoutf(ActionEvent actionEvent) {
        FXMLLoader loader = new FXMLLoader(getClass().getResource(config.getProperty("welcomepage_path")));

        try {
            Pane root = loader.load();
            Welcomepage welcomepage=loader.getController();
            welcomepage.setMotherlistener(motherlistener);
            welcomepage.setGraphicmodel(graphicmodel);
            welcomepage.setConfig(config);

            Scene scene=(Scene) settingpane.getScene();
            scene.setRoot(root);

        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public void allusersf(ActionEvent actionEvent) {
        change_last_seen_event event=new change_last_seen_event(this,1);
        motherlistener.getVoid_request().last_seen_mode(event);
    }

    public void myfollowingsf(ActionEvent actionEvent) {
        change_last_seen_event event=new change_last_seen_event(this,2);
        motherlistener.getVoid_request().last_seen_mode(event);
    }

    public void nobodyf(ActionEvent actionEvent) {
        change_last_seen_event event=new change_last_seen_event(this,3);
        motherlistener.getVoid_request().last_seen_mode(event);
    }

    public void publicf(ActionEvent actionEvent) {
        change_privmode_event  event =new change_privmode_event(this,1);
        motherlistener.getVoid_request().change_priv_mode(event);
    }

    public void privatef(ActionEvent actionEvent) {
        change_privmode_event  event =new change_privmode_event(this,2);
        motherlistener.getVoid_request().change_priv_mode(event);
    }

    public void inactivatef(ActionEvent actionEvent) {
        change_accmode_active_event event=new change_accmode_active_event(this);
        motherlistener.getVoid_request().acc_mode(event);
    }

    public void activatef(ActionEvent actionEvent) {
        change_accmode_active_event event=new change_accmode_active_event(this);
        motherlistener.getVoid_request().acc_mode(event);
    }

    public void savef(ActionEvent actionEvent) {
        pass_change_event event= new pass_change_event(this,this.passwordfiled.getText());
        motherlistener.getVoid_request().pass_change(event);
    }
    @FXML
    void backf(ActionEvent event) {
        Pane root = graphicmodel.getBacklist().get(graphicmodel.getBacklist().size()-1);
        graphicmodel.getBacklist().remove(graphicmodel.getBacklist().size()-1);
        Scene scene=(Scene) settingpane.getScene();
        scene.setRoot(root);




    }
}
