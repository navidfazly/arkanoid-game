package view.controllers;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import listeners.motherlistener;

public class Fullcomment {
    String imgpath;
    int tweetid;
    String text;
    motherlistener motherlistener;

    public listeners.motherlistener getMotherlistener() {
        return motherlistener;
    }

    public void setMotherlistener(listeners.motherlistener motherlistener) {
        this.motherlistener = motherlistener;
    }

    public String getImgpath() {
        return imgpath;
    }

    public void setImgpath(String imgpath) {
        this.imgpath = imgpath;
    }



    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public ImageView getImgview() {
        return imgview;
    }

    public void setImgview(ImageView imgview) {
        this.imgview = imgview;
    }

    public Label getLabel() {
        return label;
    }

    public void setLabel(Label label) {
        this.label = label;
    }

    @FXML
    private ImageView imgview;

    @FXML
    private Label label;

    @FXML
    void clicked(MouseEvent event) {

    }

    @FXML
    void clik1(MouseEvent event) {

    }
}
