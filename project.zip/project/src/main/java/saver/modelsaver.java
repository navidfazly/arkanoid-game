package saver;

import Model.User;
import Model.group;
import Model.model;
import Model.twitt;
import com.google.gson.Gson;

import java.io.*;
import java.util.ArrayList;

public class modelsaver {
    model model;
   public modelsaver(model model){
       this.model=model;
   }
    public void set_twiits_in_directory(){
        Gson gg= new Gson();

        for(twitt tweet:this.model.getTwitts()) {

            File file = new File("database/tweets/" + String.valueOf(tweet.getId()));
            if (tweet.getUserid() != -1) {
                if (!file.exists()) {
                    try {
                        file.createNewFile();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }

                try {
                    PrintStream printStream = new PrintStream(new FileOutputStream(file, false));

                    printStream.println(gg.toJson(tweet));
                    printStream.flush();
                    printStream.close();


                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }
            }
        }
    }


    public void set_users_in_file(){
        Gson gg=new Gson();
        File file=new File("database/users/usersdirectory.txt");

        try {
            PrintStream printStream = new PrintStream(new FileOutputStream(file,false));
            for(User user:this.model.getUsers()){
                printStream.println(gg.toJson(user));
            }
            printStream.flush();
            printStream.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }
    public void initialize(){
        if(this.model!=null) {
            set_twiits_in_directory();
            set_users_in_file();
        }
    }
    public void set_groups_in_directory(){
       Gson gg=new Gson();
        File file = new File("database/groupchats/" );
        ArrayList<String> names=new ArrayList<>();
        for(File f:file.listFiles()) {
            names.add(f.getName());
        }
        for(group g:this.model.getGroups()){
            if(!names.contains(g.getName())){
                File file1=new File("database/groupchats/"+g.getName());
                try {
                    file1.createNewFile();
                    PrintStream printStream = new PrintStream(new FileOutputStream(file1, false));

                    printStream.println(gg.toJson(g));
                    printStream.flush();
                    printStream.close();

                } catch (IOException e) {
                    e.printStackTrace();
                }
            }


        }
    }
}
