package Model;

import java.util.ArrayList;

public class group {
    ArrayList<Integer> userids=new ArrayList<>();
    Integer groupid;
    ArrayList<String> messages=new ArrayList<>();
    ArrayList<Integer> types=new ArrayList<>();
    ArrayList<String> usernames=new ArrayList<>();
    String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ArrayList<String> getMessages() {
        return messages;
    }

    public void setMessages(ArrayList<String> messages) {
        this.messages = messages;
    }

    public ArrayList<Integer> getTypes() {
        return types;
    }

    public void setTypes(ArrayList<Integer> types) {
        this.types = types;
    }

    public ArrayList<String> getUsernames() {
        return usernames;
    }

    public void setUsernames(ArrayList<String> usernames) {
        this.usernames = usernames;
    }

    public Integer getGroupid() {
        return groupid;
    }

    public void setGroupid(Integer groupid) {
        this.groupid = groupid;
    }

    public ArrayList<Integer> getUserids() {
        return userids;
    }

    public void setUserids(ArrayList<Integer> userids) {
        this.userids = userids;
    }
}
