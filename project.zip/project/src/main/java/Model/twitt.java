package Model;

import java.time.LocalTime;
import java.util.ArrayList;

public class twitt {
    ArrayList<Integer> commentsid =new ArrayList<>();
    String content;
    int likenum;
    int id ;

    public boolean isIsreported() {
        return isreported;
    }

    public void setIsreported(boolean isreported) {
        this.isreported = isreported;
    }

    boolean isreported;
    String name;
    boolean isactive;
    int userid;
    boolean iscomment;
    LocalTime localTime;
    int reportsnum;
    String imgpath;
    String username;

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    ArrayList<Integer> who_has_liked=new ArrayList<>();

    public ArrayList<Integer> getWho_has_reported() {
        return who_has_reported;
    }

    public void setWho_has_reported(ArrayList<Integer> who_has_reported) {
        this.who_has_reported = who_has_reported;
    }

    ArrayList<Integer> who_has_reported=new ArrayList<>();

    public ArrayList<Integer> getWho_has_liked() {
        return who_has_liked;
    }

    public void setWho_has_liked(ArrayList<Integer> who_has_liked) {
        this.who_has_liked = who_has_liked;
    }

    public String getImgpath() {
        return imgpath;
    }

    public void setImgpath(String imgpath) {
        this.imgpath = imgpath;
    }

    public ArrayList<Integer> getCommentsid() {
        return commentsid;
    }

    public void setCommentsid(ArrayList<Integer> commentsid) {
        this.commentsid = commentsid;
    }

    public int getReportsnum() {
        return reportsnum;
    }

    public void setReportsnum(int reportsnum) {
        this.reportsnum = reportsnum;
    }



    public boolean isIsactive() {
        return isactive;
    }

    public void setIsactive(boolean isactive) {
        this.isactive = isactive;
    }

    public boolean isIscomment() {
        return iscomment;
    }

    public void setIscomment(boolean iscomment) {
        this.iscomment = iscomment;
    }


    public int getUserid() {
        return userid;
    }
    public void setUserid(int userid) {
        this.userid = userid;
    }
    public twitt(int id){
        this.id=id;

    }

    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


    public LocalTime getLocalTime() {
        return localTime;
    }

    public void setLocalTime(LocalTime localTime) {
        this.localTime = localTime;
    }
    public twitt() {

    }

    public void addcommentid(twitt t){
        this.commentsid.add(t.getId());
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public int getLikenum() {
        return likenum;
    }

    public void setLikenum(int likenum) {
        this.likenum = likenum;
    }


}
