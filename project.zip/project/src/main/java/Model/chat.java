package Model;

import java.util.ArrayList;

public class chat {
    ArrayList<String> messages=new ArrayList<>();
    ArrayList<String> usernames=new ArrayList<>();
    ArrayList<Integer> types=new ArrayList<>();

    public ArrayList<String> getMessages() {
        return messages;
    }

    public void setMessages(ArrayList<String> messages) {
        this.messages = messages;
    }

    public ArrayList<String> getUsernames() {
        return usernames;
    }

    public void setUsernames(ArrayList<String> usernames) {
        this.usernames = usernames;
    }

    public ArrayList<Integer> getTypes() {
        return types;
    }

    public chat(ArrayList<String> messages, ArrayList<String> usernames, ArrayList<Integer> types) {
        this.messages = messages;
        this.usernames = usernames;
        this.types = types;
    }

    public void setTypes(ArrayList<Integer> types) {
        this.types = types;
    }

    public chat() {
    }
}
