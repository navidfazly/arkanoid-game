import Model.model;
import configs.config;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import listeners.motherlistener;
import logic.Maincontroller;
import saver.modelsaver;
import view.controllers.Welcomepage;
import view.controllers.graphicmodel;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class main extends Application {
    public static void main(String args[]){




        //maincontroller.initilize();
     launch(args);

    }

    @Override

    public void start(Stage primaryStage) throws Exception{
        config config=new config();
        File file=new File("configfile");
        FileReader fileReader=new FileReader(file);
        config.load(fileReader);
          FXMLLoader loader = new FXMLLoader(getClass().getResource(config.getProperty("welcomepage_path")));
        Pane root = loader.load();
        graphicmodel gr=new graphicmodel();
        model model=new model();


        modelsaver modelsaver=new modelsaver(model);
      Maincontroller maincontroller=new Maincontroller(model,modelsaver);

        motherlistener  motherlistener=new motherlistener(maincontroller);
       motherlistener.initialize();
       maincontroller.setMotherlistener(motherlistener);

        Welcomepage welcomepage=loader.getController();
      welcomepage.setMotherlistener(motherlistener);
      welcomepage.setGraphicmodel(gr);
      welcomepage.setConfig(config);
        gr.getBacklist().add((AnchorPane) root);







       primaryStage.setTitle("Hello World");
      primaryStage.setScene(new Scene(root, 650, 450));
    primaryStage.show();

    }
}
