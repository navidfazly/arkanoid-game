package configs;

import java.util.Properties;

public class config extends Properties {
    String welcompage_path;
    String chatpage;
    String explore;
    String forwardmessage;
    String fullcomment;
    String groupmaker;
    String imgmessage;
    String loginpage;
    String mainpage;
    String notifpage;
    String options_c;
    String owntweetbox;
    String personalpage;
    String registrationpage;
    String requests;
    String settings;
    String showoptions_c_page;
    String textcomment;
    String textmessage;
    String tweetpage;
    String userpage;




    public void loadpath(){


    }

}
