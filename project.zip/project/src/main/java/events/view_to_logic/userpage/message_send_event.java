package events.view_to_logic.userpage;

import java.util.EventObject;

public class message_send_event extends EventObject {
    /**
     * Constructs a prototypical Event.
     *
     * @param source the object on which the Event initially occurred
     * @throws IllegalArgumentException if source is null
     */
    public message_send_event(Object source) {
        super(source);
    }
}
