package events.view_to_logic.groupmakingpage;

import java.util.ArrayList;
import java.util.EventObject;

public class make_group_event extends EventObject {
    ArrayList<String > names;

    String name;

    public make_group_event(Object source, ArrayList<String> names, String name) {
        super(source);
        this.names = names;
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public make_group_event(Object source, ArrayList<String> names) {
        super(source);
        this.names = names;
    }

    public ArrayList<String> getNames() {
        return names;
    }

    public void setNames(ArrayList<String> names) {
        this.names = names;
    }

    /**
     * Constructs a prototypical Event.
     *
     * @param source the object on which the Event initially occurred
     * @throws IllegalArgumentException if source is null
     */
    public make_group_event(Object source) {
        super(source);
    }
}
