package events.view_to_logic.groupmakingpage;

import java.util.EventObject;

public class set_datas_perm_event extends EventObject {
    /**
     * Constructs a prototypical Event.
     *
     * @param source the object on which the Event initially occurred
     * @throws IllegalArgumentException if source is null
     */
    public set_datas_perm_event(Object source) {
        super(source);
    }
}
