package events.view_to_logic.settings_e;

import java.util.EventObject;

public class delete_acc_event extends EventObject {
    /**
     * Constructs a prototypical Event.
     *
     * @param source the object on which the Event initially occurred
     * @throws IllegalArgumentException if source is null
     */
    public delete_acc_event(Object source) {
        super(source);
    }
}
