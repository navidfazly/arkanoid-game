package events.view_to_logic.settings_e;

import java.util.EventObject;

public class change_privmode_event extends EventObject {
    int i=-1;

    public change_privmode_event(Object source, int i) {
        super(source);
        this.i = i;
    }

    /**
     * Constructs a prototypical Event.
     *
     * @param source the object on which the Event initially occurred
     * @throws IllegalArgumentException if source is null
     */
    public change_privmode_event(Object source) {
        super(source);
    }

    public int getI() {
        return i;
    }

    public void setI(int i) {
        this.i = i;
    }
    /**
     * Constructs a prototypical Event.
     *
     * @param source The object on which the Event initially occurred.
     * @throws IllegalArgumentException if source is null.
     */

}
