package events.view_to_logic.settings_e;

import java.util.EventObject;

public class pass_change_event extends EventObject {
    String password;

    public pass_change_event(Object source, String password) {
        super(source);
        this.password = password;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
