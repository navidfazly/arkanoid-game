package events.view_to_logic.settings_e;

import java.util.EventObject;

public class change_accmode_active_event extends EventObject {
    public change_accmode_active_event(Object source, int i) {
        super(source);
        this.i = i;
    }

    int i=-1;

    public int getI() {
        return i;
    }

    public void setI(int i) {
        this.i = i;
    }
    /**
     * Constructs a prototypical Event.
     *
     * @param source The object on which the Event initially occurred.
     * @throws IllegalArgumentException if source is null.
     */
    public change_accmode_active_event(Object source) {
        super(source);
    }
}

