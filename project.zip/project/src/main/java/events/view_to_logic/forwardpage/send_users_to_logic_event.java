package events.view_to_logic.forwardpage;

import java.util.ArrayList;
import java.util.EventObject;

public class send_users_to_logic_event extends EventObject {
    ArrayList<String> contactnames;
    int number;

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public send_users_to_logic_event(Object source, ArrayList<String> contactnames) {
        super(source);
        this.contactnames = contactnames;
    }

    public ArrayList<String> getContactnames() {
        return contactnames;
    }

    public void setContactnames(ArrayList<String> contactnames) {
        this.contactnames = contactnames;
    }

    /**
     * Constructs a prototypical Event.
     *
     * @param source the object on which the Event initially occurred
     * @throws IllegalArgumentException if source is null
     */
    public send_users_to_logic_event(Object source) {
        super(source);
    }

}
