package events.view_to_logic.chatpage_e;

import java.util.EventObject;

public class edit_content_msg_event extends EventObject {
    String content;
    int msgid;

    public edit_content_msg_event(Object source, String content, int msgid) {
        super(source);
        this.content = content;
        this.msgid = msgid;
    }

    public int getMsgid() {
        return msgid;
    }

    public void setMsgid(int msgid) {
        this.msgid = msgid;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
}
