package events.view_to_logic.chatpage_e;

import java.util.EventObject;

public class add_message_event extends EventObject {
    String content;
    int type;
    String username;

    public add_message_event(Object source, String content, int type) {
        super(source);
        this.content = content;
        this.type = type;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }
}
