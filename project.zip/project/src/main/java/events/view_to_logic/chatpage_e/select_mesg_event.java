package events.view_to_logic.chatpage_e;

import java.util.EventObject;

public class select_mesg_event extends EventObject {
    int messageid;

    public select_mesg_event(Object source, int messageid) {
        super(source);
        this.messageid = messageid;
    }

    public int getMessageid() {
        return messageid;
    }

    public void setMessageid(int messageid) {
        this.messageid = messageid;
    }
}
