package events.view_to_logic.chatpage_e;

import java.util.EventObject;

public class forward_message_event extends EventObject {
    int messageid;



    public forward_message_event(Object source, int messageid) {
        super(source);
        this.messageid = messageid;
    }

    /**
     * Constructs a prototypical Event.
     *
     * @throws IllegalArgumentException if source is null
     */



    public int getMessageid() {
        return messageid;
    }
}
