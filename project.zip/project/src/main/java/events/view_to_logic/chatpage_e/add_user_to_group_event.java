package events.view_to_logic.chatpage_e;

import java.util.EventObject;

public class add_user_to_group_event extends EventObject {
    String groupname;
    String username;

    public add_user_to_group_event(Object source, String groupname, String username) {
        super(source);
        this.groupname = groupname;
        this.username = username;
    }

    /**
     * Constructs a prototypical Event.
     *
     * @param source the object on which the Event initially occurred
     * @throws IllegalArgumentException if source is null
     */


    public String getGroupname() {
        return groupname;
    }

    public void setGroupname(String groupname) {
        this.groupname = groupname;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
}
