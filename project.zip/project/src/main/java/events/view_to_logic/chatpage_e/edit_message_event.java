package events.view_to_logic.chatpage_e;

import java.util.EventObject;

public class edit_message_event extends EventObject {
    int messageid;

    public edit_message_event(Object source, int messageid) {
        super(source);
        this.messageid = messageid;
    }

    /**
     * Constructs a prototypical Event.
     *
     * @param source the object on which the Event initially occurred
     * @throws IllegalArgumentException if source is null
     */



    public int getMessageid() {
        return messageid;
    }
}
