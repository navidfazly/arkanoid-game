package events.view_to_logic.chatpage_e;

import java.util.EventObject;

public class go_to_chatpage_event extends EventObject {
    String username;

    public go_to_chatpage_event(Object source, String username) {
        super(source);
        this.username = username;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
}
