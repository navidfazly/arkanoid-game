package events.view_to_logic.requests;

import jdk.jfr.Event;

import java.util.EventObject;

public class initialize_requests_event extends EventObject {
    /**
     * Constructs a prototypical Event.
     *
     * @param source the object on which the Event initially occurred
     * @throws IllegalArgumentException if source is null
     */
    public initialize_requests_event(Object source) {
        super(source);
    }
}
