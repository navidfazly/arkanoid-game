package events.view_to_logic.requests;

import java.util.EventObject;

public class accepted_req_event extends EventObject {
    String username;

    public accepted_req_event(Object source, String username) {
        super(source);
        this.username = username;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
}
