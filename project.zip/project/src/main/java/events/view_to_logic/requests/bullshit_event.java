package events.view_to_logic.requests;

import java.util.ArrayList;
import java.util.EventObject;

public class bullshit_event extends EventObject {
    ArrayList<String> notifs=new ArrayList<>();

    public bullshit_event(Object source, ArrayList<String> notifs) {
        super(source);
        this.notifs = notifs;
    }

    public ArrayList<String> getNotifs() {
        return notifs;
    }

    public void setNotifs(ArrayList<String> notifs) {
        this.notifs = notifs;
    }
}
