package events.view_to_logic;

import java.util.EventObject;

public class registrationform_event extends EventObject {
    public String name;
    public String lastname;
    public String username;
    public String email;
    public String bio;
    public String phonenum;
    public String img;

    public String getImg() {
        return img;
    }

    public void setImg(String img) {
        this.img = img;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getBio() {
        return bio;
    }

    public void setBio(String bio) {
        this.bio = bio;
    }

    public String getPhonenum() {
        return phonenum;
    }

    public void setPhonenum(String phonenum) {
        this.phonenum = phonenum;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String password;
    /**
     * Constructs a prototypical Event.
     *
     * @param source The object on which the Event initially occurred.
     * @throws IllegalArgumentException if source is null.
     */
    public registrationform_event(Object source, String name, String lastname, String username, String password, String email, String phonenum, String bio,String img) {
        super(source);
        this.name=name;
        this.lastname=lastname;
        this.username=username;
        this.password=password;
        this.email=email;
        this.bio=bio;
        this.phonenum=phonenum;
        this.img=img;
    }
}
