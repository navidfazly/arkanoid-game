package events.view_to_logic.tweets_e;

import jdk.jfr.Event;

import java.util.EventObject;

public class go_to_writer_page_event extends EventObject {
    int tweetid;

    public go_to_writer_page_event(Object source, int tweetid) {
        super(source);
        this.tweetid = tweetid;
    }

    public int getTweetid() {
        return tweetid;
    }

    public void setTweetid(int tweetid) {
        this.tweetid = tweetid;
    }

    /**
     * Constructs a prototypical Event.
     *
     * @param source the object on which the Event initially occurred
     * @throws IllegalArgumentException if source is null
     */
    public go_to_writer_page_event(Object source) {
        super(source);
    }
}
