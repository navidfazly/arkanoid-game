package events.view_to_logic.tweets_e;

import java.util.EventObject;

public class add_comment_tweet  extends EventObject {
    String content;

    public add_comment_tweet(Object source, String content, String imgpath) {
        super(source);
        this.content = content;
        this.imgpath = imgpath;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getImgpath() {
        return imgpath;
    }

    public void setImgpath(String imgpath) {
        this.imgpath = imgpath;
    }

    String imgpath;
}
