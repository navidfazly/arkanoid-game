package events.view_to_logic.tweets_e;

import java.util.EventObject;

public class comment_clicked extends EventObject {
    public comment_clicked(Object source, int id) {
        super(source);
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    int id;
}
