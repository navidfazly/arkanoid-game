package events.view_to_logic.tweets_e;

import java.util.EventObject;

public class retweet_tweet_event extends EventObject {
    /**
     * Constructs a prototypical Event.
     *
     * @param source the object on which the Event initially occurred
     * @throws IllegalArgumentException if source is null
     */
    public retweet_tweet_event(Object source) {
        super(source);
    }
}
