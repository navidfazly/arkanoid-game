package events.view_to_logic.tweets_e;

import java.util.EventObject;

public class initiliaze_event extends EventObject {
    /**
     * Constructs a prototypical Event.
     *
     * @param source the object on which the Event initially occurred
     * @throws IllegalArgumentException if source is null
     */
    public initiliaze_event(Object source) {
        super(source);
    }
}
