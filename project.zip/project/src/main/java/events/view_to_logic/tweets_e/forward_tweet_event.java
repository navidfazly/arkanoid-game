package events.view_to_logic.tweets_e;

import java.util.EventObject;

public class forward_tweet_event extends EventObject {
    String content;

    public forward_tweet_event(Object source, String content) {
        super(source);
        this.content = content;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    /**
     * Constructs a prototypical Event.
     *
     * @param source the object on which the Event initially occurred
     * @throws IllegalArgumentException if source is null
     */
    public forward_tweet_event(Object source) {
        super(source);
    }
}
