package events.view_to_logic.tweets_e;

import java.util.EventObject;

public class block_wrtiter_event  extends EventObject {
    /**
     * Constructs a prototypical Event.
     *
     * @param source the object on which the Event initially occurred
     * @throws IllegalArgumentException if source is null
     */
    public block_wrtiter_event(Object source) {
        super(source);
    }
}
