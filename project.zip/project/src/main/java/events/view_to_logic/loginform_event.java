package events.view_to_logic;

import java.util.EventObject;

public class loginform_event extends EventObject {
    public  String username;
    public  String password;
    /**
     * Constructs a prototypical Event.
     *
     * @param source The object on which the Event initially occurred.
     * @throws IllegalArgumentException if source is null.
     */
    public loginform_event(Object source,String username,String password) {
        super(source);
        this.password=password;
        this.username=username;
    }


}
