package events.view_to_logic.explore_e;

import java.util.EventObject;

public class make_hot_list_event extends EventObject {
    /**
     * Constructs a prototypical Event.
     *
     * @param source the object on which the Event initially occurred
     * @throws IllegalArgumentException if source is null
     */
    public make_hot_list_event(Object source) {
        super(source);
    }
}
