package events.view_to_logic.personalpage_e;

import java.util.EventObject;

public class blacklist_remove_event  extends EventObject {
    String username;

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public blacklist_remove_event(Object source, String username) {
        super(source);
        this.username = username;
    }
}
