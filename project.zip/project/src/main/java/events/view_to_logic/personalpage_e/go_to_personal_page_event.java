package events.view_to_logic.personalpage_e;

import jdk.jfr.Event;

import java.util.EventObject;

public class go_to_personal_page_event extends EventObject {
    /**
     * Constructs a prototypical Event.
     *
     * @param source the object on which the Event initially occurred
     * @throws IllegalArgumentException if source is null
     */
    public go_to_personal_page_event(Object source) {
        super(source);
    }
}
