package events.view_to_logic.personalpage_e;

import java.util.EventObject;

public class remove_user_from_cat_event extends EventObject {
    String category;
    String username;

    public remove_user_from_cat_event(Object source, String category, String username) {
        super(source);
        this.category = category;
        this.username = username;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
}
