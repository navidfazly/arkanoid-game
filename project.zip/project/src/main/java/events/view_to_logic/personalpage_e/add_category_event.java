package events.view_to_logic.personalpage_e;

import java.util.EventObject;

public class add_category_event extends EventObject {
    String category;

    public add_category_event(Object source, String category) {
        super(source);
        this.category = category;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }
}
