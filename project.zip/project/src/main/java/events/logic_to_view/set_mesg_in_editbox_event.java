package events.logic_to_view;

import java.util.EventObject;

public class set_mesg_in_editbox_event extends EventObject {
    int messageid;
    String content;

    public set_mesg_in_editbox_event(Object source, int messageid, String content) {
        super(source);
        this.messageid = messageid;
        this.content = content;
    }

    public int getMessageid() {
        return messageid;
    }

    public void setMessageid(int messageid) {
        this.messageid = messageid;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
}
