package events.logic_to_view;

import java.util.ArrayList;
import java.util.EventObject;

public class send_chats_event extends EventObject {


    public String getUserimagepath() {
        return userimagepath;
    }

    public void setUserimagepath(String userimagepath) {
        this.userimagepath = userimagepath;
    }


    ArrayList<String> messages=new ArrayList<>();
    ArrayList<String> usernames=new ArrayList<>();
    ArrayList<Integer> types=new ArrayList<>();
    String username;


    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public ArrayList<String> getMessages() {
        return messages;
    }

    public void setMessages(ArrayList<String> messages) {
        this.messages = messages;
    }

    public ArrayList<String> getUsernames() {
        return usernames;
    }

    public void setUsernames(ArrayList<String> usernames) {
        this.usernames = usernames;
    }

    public ArrayList<Integer> getTypes() {
        return types;
    }

    public void setTypes(ArrayList<Integer> types) {
        this.types = types;
    }
    String userimagepath;

    public send_chats_event(Object source, ArrayList<String> messages, ArrayList<String> usernames, ArrayList<Integer> types, String username, String userimagepath) {
        super(source);
        this.messages = messages;
        this.usernames = usernames;
        this.types = types;
        this.username = username;
        this.userimagepath = userimagepath;
    }
}
