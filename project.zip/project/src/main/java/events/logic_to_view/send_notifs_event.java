package events.logic_to_view;

import jdk.jfr.Event;

import java.util.ArrayList;
import java.util.EventObject;

public class send_notifs_event extends EventObject {
    /**
     * Constructs a prototypical Event.
     *
     * @param source the object on which the Event initially occurred
     * @throws IllegalArgumentException if source is null
     */
    ArrayList<String> usernames =new ArrayList<>();

    public ArrayList<String> getUsernames() {
        return usernames;
    }

    public void setUsernames(ArrayList<String> usernames) {
        this.usernames = usernames;
    }

    public ArrayList<Integer> getMessagenums() {
        return messagenums;
    }

    public void setMessagenums(ArrayList<Integer> messagenums) {
        this.messagenums = messagenums;
    }

    ArrayList<Integer> messagenums=new ArrayList<>();
    /**
     * Constructs a prototypical Event.
     *
     * @param source The object on which the Event initially occurred.
     * @throws IllegalArgumentException if source is null.
     */
    public send_notifs_event(Object source) {
        super(source);
    }

    public send_notifs_event(Object source, ArrayList<String> usernames, ArrayList<Integer> messagenums) {
        super(source);
        this.usernames = usernames;
        this.messagenums = messagenums;
    }
}
