package events.logic_to_view;

import java.util.EventObject;

public class send_list_of_follower_event  extends EventObject {
    String contactnames;

    public String getContactnames() {
        return contactnames;
    }

    public void setContactnames(String contactnames) {
        this.contactnames = contactnames;
    }

    public send_list_of_follower_event(Object source, String contactnames) {
        super(source);
        this.contactnames = contactnames;
    }

    /**
     * Constructs a prototypical Event.
     *
     * @param source the object on which the Event initially occurred
     * @throws IllegalArgumentException if source is null
     */
    public send_list_of_follower_event(Object source) {
        super(source);
    }
}
