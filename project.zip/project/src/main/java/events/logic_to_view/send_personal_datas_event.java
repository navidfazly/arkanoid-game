package events.logic_to_view;

import java.util.EventObject;

public class send_personal_datas_event  extends EventObject {
    String name;
    String lastname;
    String username;
    String email;
    String phonenum;
    String bio;
    String imgpath="1";
    String followerslist;
    String followinglist;
    String blacklist;
    String categories;

    public send_personal_datas_event(Object source, String name, String lastname, String username, String email, String phonenum, String bio, String imgpath, String followerslist, String followinglist, String blacklist, String categories) {
        super(source);
        this.name = name;
        this.lastname = lastname;
        this.username = username;
        this.email = email;
        this.phonenum = phonenum;
        this.bio = bio;
        this.imgpath = imgpath;
        this.followerslist = followerslist;
        this.followinglist = followinglist;
        this.blacklist = blacklist;
        this.categories = categories;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhonenum() {
        return phonenum;
    }

    public void setPhonenum(String phonenum) {
        this.phonenum = phonenum;
    }

    public String getBio() {
        return bio;
    }

    public void setBio(String bio) {
        this.bio = bio;
    }

    public String getImgpath() {
        return imgpath;
    }

    public void setImgpath(String imgpath) {
        this.imgpath = imgpath;
    }

    public String getFollowerslist() {
        return followerslist;
    }

    public void setFollowerslist(String followerslist) {
        this.followerslist = followerslist;
    }

    public String getFollowinglist() {
        return followinglist;
    }

    public void setFollowinglist(String followinglist) {
        this.followinglist = followinglist;
    }

    public String getBlacklist() {
        return blacklist;
    }

    public void setBlacklist(String blacklist) {
        this.blacklist = blacklist;
    }

    public String getCategories() {
        return categories;
    }

    public void setCategories(String categories) {
        this.categories = categories;
    }

    /**
     * Constructs a prototypical Event.
     *
     * @param source the object on which the Event initially occurred
     * @throws IllegalArgumentException if source is null
     */
    public send_personal_datas_event(Object source) {
        super(source);
    }
}
