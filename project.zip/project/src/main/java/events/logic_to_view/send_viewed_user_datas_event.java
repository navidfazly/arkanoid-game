package events.logic_to_view;

import jdk.jfr.Event;

import java.util.EventObject;

public class send_viewed_user_datas_event extends EventObject {
    String name;
    String lastname;
    String username;
    String email;
    String lastseen;
    String bio;
    String imagepath;

    public send_viewed_user_datas_event(Object source, String name, String lastname, String username, String email, String lastseen, String bio, String imagepath) {
        super(source);
        this.name = name;
        this.lastname = lastname;
        this.username = username;
        this.email = email;
        this.lastseen = lastseen;
        this.bio = bio;
        this.imagepath = imagepath;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getLastseen() {
        return lastseen;
    }

    public void setLastseen(String lastseen) {
        this.lastseen = lastseen;
    }

    public String getBio() {
        return bio;
    }

    public void setBio(String bio) {
        this.bio = bio;
    }

    public String getImagepath() {
        return imagepath;
    }

    public void setImagepath(String imagepath) {
        this.imagepath = imagepath;
    }

    /**
     * Constructs a prototypical Event.
     *
     * @param source the object on which the Event initially occurred
     * @throws IllegalArgumentException if source is null
     */
    public send_viewed_user_datas_event(Object source) {
        super(source);
    }
}
