package events.logic_to_view;

import java.util.ArrayList;
import java.util.EventObject;

public class send_own_tweets_event extends EventObject {
    ArrayList<String> tweets;

    public ArrayList<String> getTweets() {
        return tweets;
    }

    public void setTweets(ArrayList<String> tweets) {
        this.tweets = tweets;
    }

    public send_own_tweets_event(Object source, ArrayList<String> tweets) {
        super(source);
        this.tweets = tweets;
    }
}
