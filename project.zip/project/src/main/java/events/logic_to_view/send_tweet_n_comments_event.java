package events.logic_to_view;

import Model.twitt;

import java.util.ArrayList;
import java.util.EventObject;

public class send_tweet_n_comments_event  extends EventObject {
    String userimgepath;

    public String getUserimgepath() {
        return userimgepath;
    }

    public void setUserimgepath(String userimgepath) {
        this.userimgepath = userimgepath;
    }

    String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public send_tweet_n_comments_event(Object source, String userimgepath, String name, twitt currenttwitt, ArrayList<twitt> comments) {
        super(source);
        this.userimgepath = userimgepath;
        this.name = name;
        this.currenttwitt = currenttwitt;
        this.comments = comments;
    }

    public twitt getCurrenttwitt() {
        return currenttwitt;
    }

    public void setCurrenttwitt(twitt currenttwitt) {
        this.currenttwitt = currenttwitt;
    }

    public ArrayList<twitt> getComments() {
        return comments;
    }

    public void setComments(ArrayList<twitt> comments) {
        this.comments = comments;
    }

    twitt currenttwitt;
    ArrayList<twitt> comments;
}
