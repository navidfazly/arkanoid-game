package events.logic_to_view;

import jdk.jfr.Event;

import java.util.ArrayList;
import java.util.EventObject;

public class send_usernames_to_notifpage_event extends EventObject {
    ArrayList<String> usernames;

    public send_usernames_to_notifpage_event(Object source, ArrayList<String> usernames) {
        super(source);
        this.usernames = usernames;
    }

    public ArrayList<String> getUsernames() {
        return usernames;
    }

    public void setUsernames(ArrayList<String> usernames) {
        this.usernames = usernames;
    }

    /**
     * Constructs a prototypical Event.
     *
     * @param source the object on which the Event initially occurred
     * @throws IllegalArgumentException if source is null
     */
    public send_usernames_to_notifpage_event(Object source) {
        super(source);
    }
}
