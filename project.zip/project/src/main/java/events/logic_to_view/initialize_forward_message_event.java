package events.logic_to_view;

import java.util.EventObject;

public class initialize_forward_message_event extends EventObject {
    String content;
    String contactnames;

    public initialize_forward_message_event(Object source, String content, String contactnames) {
        super(source);
        this.content = content;
        this.contactnames = contactnames;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getContactnames() {
        return contactnames;
    }

    public void setContactnames(String contactnames) {
        this.contactnames = contactnames;
    }

}
