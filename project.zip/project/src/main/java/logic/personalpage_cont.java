package logic;

public class personalpage_cont {
}
