package logic;

public class setting_cont {
}
