package logic;

public class explore_cont {
}
