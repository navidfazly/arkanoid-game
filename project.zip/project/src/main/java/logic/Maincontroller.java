package logic;

import Model.*;
import com.google.gson.Gson;
import events.logic_to_view.*;
import events.view_to_logic.chatpage_e.*;
import events.view_to_logic.explore_e.go_to_user_page_event;
import events.view_to_logic.forwardpage.send_users_to_logic_event;
import events.view_to_logic.groupmakingpage.make_group_event;
import events.view_to_logic.groupmakingpage.set_datas_perm_event;
import events.view_to_logic.personalpage_e.*;
import events.view_to_logic.loginform_event;
import events.view_to_logic.registrationform_event;
import events.view_to_logic.requests.accepted_req_event;
import events.view_to_logic.requests.bullshit_event;
import events.view_to_logic.requests.rejected_req_event;
import events.view_to_logic.settings_e.*;
import events.view_to_logic.tweets_e.*;
import events.view_to_logic.userpage.block_event;
import events.view_to_logic.userpage.friend_request_send_event;
import events.view_to_logic.userpage.message_send_event;
import listeners.motherlistener;
import log.logger;
import saver.modelsaver;

import java.io.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Scanner;

public class Maincontroller {

    public String username2;
    public User showeduser;
    public String current_content;
    public ArrayList<String> who_can_forward_list=new ArrayList<>();
    log.logger logger=new logger();

    public log.logger getLogger() {
        return logger;
    }

    public void setLogger(log.logger logger) {
        this.logger = logger;
    }

    public ArrayList<String> getWho_can_forward_list() {
        return who_can_forward_list;
    }

    public void setWho_can_forward_list(ArrayList<String> who_can_forward_list) {
        this.who_can_forward_list = who_can_forward_list;
    }

    public String getCurrent_content() {
        return current_content;
    }

    public void setCurrent_content(String current_content) {
        this.current_content = current_content;
    }

    public User getShoweduser() {
        return showeduser;
    }

    public void setShoweduser(User showeduser) {
        this.showeduser = showeduser;
    }

    public String getUsername2() {
        return username2;
    }

    public void setUsername2(String username2) {
        this.username2 = username2;
    }

    private model model;
    private modelsaver modelsaver;
    public motherlistener motherlistener;

    public listeners.motherlistener getMotherlistener() {
        return motherlistener;
    }

    public void setMotherlistener(listeners.motherlistener motherlistener) {
        this.motherlistener = motherlistener;
    }

    public Maincontroller(model model, modelsaver modelsaver) {
        this.model = model;
        this.modelsaver = modelsaver;

    }


    private User currentuser;


    private ArrayList<String> messages = new ArrayList<>();
    private ArrayList<String> usernames = new ArrayList<>();
    private ArrayList<Integer> types = new ArrayList<>();
    private int currentmsgid;
    private ArrayList<twitt> parents = new ArrayList<>();
    public  ArrayList<Integer> indexes=new ArrayList<>();

    public Model.model getModel() {
        return model;
    }

    public void setModel(Model.model model) {
        this.model = model;
    }

    public saver.modelsaver getModelsaver() {
        return modelsaver;
    }

    public void setModelsaver(saver.modelsaver modelsaver) {
        this.modelsaver = modelsaver;
    }

    public User getCurrentuser() {
        return currentuser;
    }

    public void setCurrentuser(User currentuser) {
        this.currentuser = currentuser;
    }

    public ArrayList<String> getMessages() {
        return messages;
    }

    public void setMessages(ArrayList<String> messages) {
        this.messages = messages;
    }

    public ArrayList<String> getUsernames() {
        return usernames;
    }

    public void setUsernames(ArrayList<String> usernames) {
        this.usernames = usernames;
    }

    public ArrayList<Integer> getTypes() {
        return types;
    }

    public void setTypes(ArrayList<Integer> types) {
        this.types = types;
    }

    public int getCurrentmsgid() {
        return currentmsgid;
    }

    public void setCurrentmsgid(int currentmsgid) {
        this.currentmsgid = currentmsgid;
    }

    public ArrayList<Integer> getIndexes() {
        return indexes;
    }

    public void setIndexes(ArrayList<Integer> indexes) {
        this.indexes = indexes;
    }

    public ArrayList<twitt> getCurrenttwittlist() {
        return currenttwittlist;
    }

    public void setCurrenttwittlist(ArrayList<twitt> currenttwittlist) {
        this.currenttwittlist = currenttwittlist;
    }

    public ArrayList<twitt> getComments() {
        return comments;
    }

    public void setComments(ArrayList<twitt> comments) {
        this.comments = comments;
    }

    public twitt getCurrenttwitt() {
        return currenttwitt;
    }

    public void setCurrenttwitt(twitt currenttwitt) {
        this.currenttwitt = currenttwitt;
    }

    public ArrayList<twitt> getDefaultlist() {
        return defaultlist;
    }

    public void setDefaultlist(ArrayList<twitt> defaultlist) {
        this.defaultlist = defaultlist;
    }

    public int getTweetindex() {
        return tweetindex;
    }

    public void setTweetindex(int tweetindex) {
        this.tweetindex = tweetindex;
    }

    public ArrayList<twitt> getParents() {
        return parents;
    }

    public void setParents(ArrayList<twitt> parents) {
        this.parents = parents;
    }

    private ArrayList<twitt> currenttwittlist = new ArrayList<>();
    private ArrayList<twitt> comments = new ArrayList<>();
    private twitt currenttwitt;
    private ArrayList<twitt> defaultlist = new ArrayList<>();
    private int tweetindex;
    public group currentgroup;

    public group getCurrentgroup() {
        return currentgroup;
    }

    public void setCurrentgroup(group currentgroup) {
        this.currentgroup = currentgroup;
    }

    public void check_valid_login(loginform_event loginformevent) {
        String username = loginformevent.username;
        String password = loginformevent.password;

        User user = this.model.get_user_by_username(username);
        if(user!=null) {
            if (user.getPassword().equals(password)) {
                login(loginformevent);

            }
        }


    }

    public void check_valid_registration(registrationform_event registrationformevent) {
        System.out.println(1);
        boolean flag = true;
        for (User u : this.model.getUsers()) {
            if (u.getUsername().equals(registrationformevent.username) || u.getEmail().equals(registrationformevent.email) || u.getPhonenum().equals(registrationformevent.phonenum)) {
                flag = false;
            }
        }
        if (flag) {
            register(registrationformevent);
            update();
        } else {


        }

    }

    public void login(loginform_event loginformevent) {
        User user = this.model.get_user_by_username(loginformevent.username);
        this.currentuser = user;
        update();
        logger.info("user : "+ this.currentuser.getUsername()+ " logged in ");
        motherlistener.getBoolean_listener().change_to_main_page_l(true);

    }

    public void register(registrationform_event registrationformevent) {
        System.out.println(2);
        User user = new User(registrationformevent.name, registrationformevent.lastname, registrationformevent.username, registrationformevent.password, registrationformevent.email, registrationformevent.phonenum, registrationformevent.bio, this.model.get_max_id() + 1);
        user.setImgpath(registrationformevent.getImg());
        this.currentuser = user;
        this.model.getUsers().add(currentuser);
        logger.info("user : "+ this.currentuser.getUsername()+ " signed up ");
        update();
        motherlistener.getBoolean_listener().change_to_main_page_r(true);
    }

    public void update() {
        modelsaver.initialize();
        update_last_seen(this.currentuser);
    }

    public void edituserpersonaldatas(edit_user_datas_event edituserdatasevent) {
        this.currentuser.setFirstname(edituserdatasevent.name);
        this.currentuser.setLastname(edituserdatasevent.lastname);

        this.currentuser.setPhonenum(edituserdatasevent.phonemum);
        this.currentuser.setEmail(edituserdatasevent.email);
        this.currentuser.setBio(edituserdatasevent.bio);
        this.currentuser.setImgpath(edituserdatasevent.imgpath);
        logger.info("user : "+ this.currentuser.getUsername()+ " edited personal datas ");
        update();
    }

    public void send_datas_to_personal_page() {
        String followers = "";
        String followings = "";
        String blacklist = "";
        String category = "";
        for (int i : this.currentuser.getFollowers()) {
            if(this.model.get_user_by_id(i).getUsername()!=null) {
                followers = followers + " - " + this.model.get_user_by_id(i).getUsername();
            }
        }
        for (int i : this.currentuser.getFollowings()) {
            if (this.model.get_user_by_id(i).getUsername() != null) {
                followings = followings + " - " + this.model.get_user_by_id(i).getUsername();
            }
        }
        for (int i : this.currentuser.getBlacklist()) {
            if(this.model.get_user_by_id(i).getUsername()!=null) {

                blacklist = blacklist + " - " + this.model.get_user_by_id(i).getUsername();
            }
        }
        for (String s : this.currentuser.getGroups().keySet()) {
            category = category + s + " : ";
            for (int s1 : this.currentuser.getGroups().get(s)) {
                if(this.model.get_user_by_id(s1).getUsername()!=null) {
                    category = category + this.model.get_user_by_id(s1).getUsername() + " - ";
                }
            }
            category = category + "    /    ";
        }
        send_personal_datas_event event = new send_personal_datas_event(this, this.currentuser.getFirstname(), this.currentuser.getLastname(), this.currentuser.getUsername(), this.currentuser.getEmail(), this.currentuser.getPhonenum(), this.currentuser.getBio(), this.currentuser.getImgpath(), followers, followings, blacklist, category);
        motherlistener.getForm_listener().sendform(event);
    }

    public void add_to_blacklist(blacklist_add_event blacklisttadd_event) {
        System.out.println(10002);
        System.out.println(blacklisttadd_event.getUsername());
        if (is_valid_user(blacklisttadd_event.getUsername())) {
            System.out.println(-1);
            if (!this.currentuser.getBlacklist().contains(this.model.get_user_by_username(blacklisttadd_event.getUsername()).getId())) {
                this.currentuser.getBlacklist().add(this.model.get_user_by_username(blacklisttadd_event.getUsername()).getId());
                if(this.currentuser.getFollowers().contains(this.model.get_user_by_username(blacklisttadd_event.getUsername()).getId())){
                    this.currentuser.getFollowers().remove((Object)this.model.get_user_by_username(blacklisttadd_event.getUsername()).getId());
                }
                if(this.currentuser.getFollowings().contains(this.model.get_user_by_username(blacklisttadd_event.getUsername()).getId())){
                    this.currentuser.getFollowings().remove((Object)this.model.get_user_by_username(blacklisttadd_event.getUsername()).getId());
                }

            }
        }
        logger.info("user : "+ this.currentuser.getUsername()+ " changed his/her blacklist");
        update();

    }

    public void remove_from_blacklist(blacklist_remove_event blacklistremove_event) {
        if (is_valid_user(blacklistremove_event.getUsername())) {
            System.out.println("first");
            if (this.currentuser.getBlacklist().contains(this.model.get_user_by_username(blacklistremove_event.getUsername()).getId())) {
                System.out.println("second");
                this.currentuser.getBlacklist().remove((Object) this.model.get_user_by_username(blacklistremove_event.getUsername()).getId());
            }
        }
        logger.info("user : "+ this.currentuser.getUsername()+ " changed his/her blacklist");
        update();

    }

    public void remove_from_followings(followings_remove_event followinglistremove_event) {
        if (is_valid_user(followinglistremove_event.getUsername())) {
            if (this.currentuser.getFollowings().contains(this.model.get_user_by_username(followinglistremove_event.getUsername()).getId())) {
                this.currentuser.getFollowings().remove((Object) this.model.get_user_by_username(followinglistremove_event.getUsername()).getId());
                this.model.get_user_by_username(followinglistremove_event.getUsername()).getRemove_from_followings().add(this.currentuser.getId());
            }
        }
        logger.info("user : "+ this.currentuser.getUsername()+ " changed his/her followings");
        update();
    }

    public void remove_from_followers(followers_remove_event followerlistremove_event) {
        if (is_valid_user(followerlistremove_event.getUsername())) {
            System.out.println("first");
            if (this.currentuser.getFollowers().contains(this.model.get_user_by_username(followerlistremove_event.getUsername()).getId())) {
                this.currentuser.getFollowers().remove((Object) this.model.get_user_by_username(followerlistremove_event.getUsername()).getId());
                this.model.get_user_by_username(followerlistremove_event.getUsername()).getRemove_from_followers().add(this.currentuser.getId());
            }
        }
        logger.info("user : "+ this.currentuser.getUsername()+ " changed his/her followers");
        update();
    }

    public boolean is_valid_user(String username) {
        if (this.model.get_user_by_username(username) != null) {
            return true;
        }
        return false;
    }

    public void add_user_to_cat(add_user_to_cat_event e) {
        if (is_valid_cat(e.getCategory())) {
            if (is_valid_user(e.getUsername())) {
                this.currentuser.getGroups().get(e.getCategory()).add(this.model.get_user_by_username(e.getUsername()).getId());
            }
        }
        logger.info("user : "+ this.currentuser.getUsername()+ " changed his/her friends");
        update();
    }

    public void remove_user_from_cat(remove_user_from_cat_event e) {
        if (is_valid_cat(e.getCategory())) {
            if (is_valid_user(e.getUsername())) {
                this.currentuser.getGroups().get(e.getCategory()).remove(this.model.get_user_by_username(e.getUsername()).getId());
            }
        }
        logger.info("user : "+ this.currentuser.getUsername()+ " changed his/her friends");
        update();

    }

    public void add_cat(add_category_event e) {
        String name = e.getCategory();
        ArrayList<Integer> newgroup = new ArrayList<>();
        this.currentuser.getGroups().put(name, newgroup);
        logger.info("user : "+ this.currentuser.getUsername()+ " changed his/her friends");
        update();

    }

    public void remove_cat(remove_category_event e) {
        String name = e.getCategory();
        this.currentuser.getGroups().remove(e.getCategory());
        logger.info("user : "+ this.currentuser.getUsername()+ " changed his/her friends");
        update();
    }

    public boolean is_valid_cat(String name) {
        for (String s : this.currentuser.getGroups().keySet()) {
            if (name.equals(s)) {
                return true;
            }
        }
        return false;
    }

    public void change_last_seen(change_last_seen_event e) {
        if (e.getI() == 1) {
            this.currentuser.setLastseentype(1);
        } else if (e.getI() == 2) {
            this.currentuser.setLastseentype(2);
        } else if (e.getI() == 3) {
            this.currentuser.setLastseentype(3);
        }
        logger.info("user : "+ this.currentuser.getUsername()+ " changed his/her lastseen type");
        update();

    }

    public void change_acc_mode(change_accmode_active_event e) {
        if (e.getI() == 1) {
            this.currentuser.setIsactive(true);
        } else {
            this.currentuser.setIsactive(false);
        }
        logger.info("user : "+ this.currentuser.getUsername()+ " changed account type");
        update();
    }

    public void change_prive_mode(change_privmode_event e) {
        if (e.getI() == 1) {
            this.currentuser.setPrivacytype(1);
        } else {
            this.currentuser.setPrivacytype(2);
        }
        logger.info("user : "+ this.currentuser.getUsername()+ " changed his/her privacy type");
        update();

    }

    public void delete_acc(delete_acc_event e) {
        logger.info("user : "+ this.currentuser.getUsername()+ " deleted account");
        this.model.getUsers().remove(this.currentuser);
        int id=this.currentuser.getId();
        String username=this.currentuser.getUsername();
        //delete chat files of user
        File file=new File("database/chats");
        for(File file1:file.listFiles()){
            if(file1.getName().contains(username)){
                file1.delete();
            }
        }

        //delete tweets of user
        for(twitt t:this.model.getTwitts()){
            if(t.getUserid()==id){
                t.setUserid(-1);
            }
        }

        //delete directory of chats_notifs
        File file_dir=new File("database/chat_notifs");
        for(File file1_dir:file_dir.listFiles()){
            if(file1_dir.getName().equals(username)){
                file1_dir.delete();
            }
        }
        //delete saved message


        update();
    }

    public void logout(logout_event e) {
        logger.info("user : "+ this.currentuser.getUsername()+ " logged out");


        update();

    }


    public void pass_change(pass_change_event e) {
        logger.info("user : "+ this.currentuser.getUsername()+ " changed his/her password");
        this.currentuser.setPassword(e.getPassword());
        update();
    }

    public void initial_notifs(get_notifs_event event) {

        File file = new File("database/chat_notifs");
        if (!file.exists()) {
            try {
                file.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        ArrayList<String> usernamess = new ArrayList<>();
        ArrayList<Integer> messagenum = new ArrayList<>();


        int ind = 0;
        for (File file1 : file.listFiles()) {
            String[] usernames = new String[file1.listFiles().length];
            int[] message_nums = new int[file1.listFiles().length];
            if (file1.getName().equals(this.currentuser.getUsername())) {
                try {
                    for (File file2 : file1.listFiles()) {
                        Scanner sc = new Scanner(file2);
                        message_nums[ind] = sc.nextInt();
                        usernames[ind] = file2.getName();
                        ind++;

                    }
                    for (int i = 0; i < file1.listFiles().length; i++) {
                        for (int j = 0; j < file1.listFiles().length - 1; j++) {
                            if (message_nums[j] > message_nums[j + 1]) {
                                int x = message_nums[j + 1];
                                message_nums[j + 1] = message_nums[j];
                                message_nums[j] = x;
                                String s = usernames[j + 1];
                                usernames[j + 1] = usernames[j];
                                usernames[j] = s;
                            }
                        }
                    }

                    for (int i = 0; i < usernames.length; i++) {
                        usernamess.add(usernames[i]);
                        messagenum.add(message_nums[i]);
                    }



                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }

            }


        }
        for (int i : this.currentuser.getFollowers()) {
            if (this.model.get_user_by_id(i)!=null && !usernamess.contains(this.model.get_user_by_id(i).getUsername())) {
                usernamess.add(this.model.get_user_by_id(i).getUsername());
                messagenum.add(0);
            }
        }
        for (int i : this.currentuser.getFollowings()) {
            if (this.model.get_user_by_id(i)!=null && !usernamess.contains(this.model.get_user_by_id(i).getUsername())) {
                usernamess.add(this.model.get_user_by_id(i).getUsername());
                messagenum.add(0);
            }
        }
        for(int i:this.currentuser.getEngaged_groups()){
            if ( this.model.get_group_by_id(i)!=null) {
                usernamess.add(this.model.get_group_by_id(i).getName());
                messagenum.add(0);
            }
        }
        usernamess.add(this.currentuser.getUsername());
        messagenum.add(0);

        who_can_forward_list=usernamess;
        send_notifs_event send_notifs_event = new send_notifs_event(this, usernamess, messagenum);
        motherlistener.getList_listener().send_notifs(send_notifs_event);

    }

    public void load_chats(go_to_chatpage_event event) {
        logger.info("user : "+ this.currentuser.getUsername()+ " loaded chats");
        Gson gg=new Gson();
        if (is_valid_user(event.getUsername())) {
            currentgroup=null;

            username2=this.model.get_user_by_username(event.getUsername()).getUsername();
            if(username2==this.currentuser.getUsername()){
                File file=new File("database/savedmessages/"+username2);
                if(!file.exists()){
                    try {
                        file.createNewFile();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    send_chats_event load_chats_event = new send_chats_event(this, this.messages, this.usernames, this.types, currentuser.getUsername(),this.currentuser.getImgpath());
                    motherlistener.getList_listener().send_chats(load_chats_event);
                }
                else {
                    Scanner scanner = null;
                    try {
                        scanner = new Scanner(file);
                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                    }


                    chat chat = gg.fromJson(scanner.nextLine(), chat.class);
                    usernames = chat.getUsernames();
                    messages = chat.getMessages();
                    types = chat.getTypes();
                    for(int i=0;i<usernames.size();i++){
                        System.out.println(usernames.get(i));
                        System.out.println(types.get(i));
                        System.out.println(messages.get(i));
                    }
                    send_chats_event load_chats_event = new send_chats_event(this, this.messages, this.usernames, this.types, currentuser.getUsername(),this.currentuser.getImgpath());
                    motherlistener.getList_listener().send_chats(load_chats_event);
                }

            }
            else {
            User user2 = this.model.get_user_by_username(event.getUsername());
            String path1 = "database/chats/" + this.currentuser.getUsername() + "_" + user2.getUsername();
            String path2 = "database/chats/" + user2.getUsername() + "_" + this.currentuser.getUsername();
            File file1 = new File(path1);
            File file2 = new File(path2);
            if (file1.exists()) {
                Scanner scanner = null;
                try {
                    scanner = new Scanner(file1);
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }



                chat chat= gg.fromJson(scanner.nextLine(),chat.class);
                usernames=chat.getUsernames();
                messages=chat.getMessages();
                types=chat.getTypes();
                for(int i=0;i<usernames.size();i++){
                    System.out.println(usernames.get(i));
                    System.out.println(types.get(i));
                    System.out.println(messages.get(i));
                }
                String userimagepath=user2.getImgpath();


                send_chats_event load_chats_event = new send_chats_event(this,this.messages,this.usernames,this.types, currentuser.getUsername(),userimagepath);
                motherlistener.getList_listener().send_chats(load_chats_event);

                File file3 = new File("database/chat_notifs/" + this.currentuser.getUsername());
                if (!file3.exists()) {
                    file3.mkdirs();

                } else {
                    File file4 = new File("database/chat_notifs/" + this.currentuser.getUsername() + "/" + user2.getUsername());
                    if (!file4.exists()) {

                    } else {
                        PrintStream printStream = null;
                        try {
                            printStream = new PrintStream(new FileOutputStream(file4, false));
                        } catch (FileNotFoundException e) {
                            e.printStackTrace();
                        }
                        printStream.println(0);
                    }

                }


            } else if (file2.exists()) {
                Scanner scanner = null;
                try {
                    scanner = new Scanner(file2);
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }


                chat chat= gg.fromJson(scanner.nextLine(),chat.class);
                usernames=chat.getUsernames();
                messages=chat.getMessages();
                types=chat.getTypes();
                String userimagepath=user2.getImgpath();


                send_chats_event load_chats_event = new send_chats_event(this,this.messages,this.usernames,this.types, currentuser.getUsername(),userimagepath);
                motherlistener.getList_listener().send_chats(load_chats_event);


                File file3 = new File("database/chat_notifs/" + this.currentuser.getUsername());
                if (!file3.exists()) {
                    file3.mkdirs();

                } else {
                    File file4 = new File("database/chat_notifs/" + this.currentuser.getUsername() + "/" + user2.getUsername());
                    if (!file4.exists()) {

                    } else {
                        PrintStream printStream = null;
                        try {
                            printStream = new PrintStream(new FileOutputStream(file4, false));
                        } catch (FileNotFoundException e) {
                            e.printStackTrace();
                        }
                        printStream.println(0);
                    }

                }
            } else {
                String userimagepath=user2.getImgpath();


                send_chats_event load_chats_event = new send_chats_event(this,this.messages,this.usernames,this.types, currentuser.getUsername(),userimagepath);
                motherlistener.getList_listener().send_chats(load_chats_event);


            }

        }} else {
            group gr = null;
            username2 = null;
            for (group g : this.model.getGroups()) {
                if (g != null && g.getName()!=null) {
                    if (g.getName().equals(event.getUsername())) {
                        usernames = g.getUsernames();

                        types = g.getTypes();
                        messages = g.getMessages();
                        for(int i=0;i<usernames.size();i++){
                            System.out.println(usernames.get(i));
                            System.out.println(types.get(i));
                            System.out.println(messages.get(i));
                        }
                        currentgroup = g;
                        send_chats_event load_chats_event = new send_chats_event(this, this.messages, this.usernames, this.types, currentuser.getUsername(),"000");
                        motherlistener.getList_listener().send_chats(load_chats_event);
                        File file3 = new File("database/chat_notifs/" + this.currentuser.getUsername());
                        if (!file3.exists()) {
                            file3.mkdirs();

                        } else {
                            File file4 = new File("database/chat_notifs/" + this.currentuser.getUsername() + "/" + g.getName());
                            if (!file4.exists()) {

                            } else {
                                PrintStream printStream = null;
                                try {
                                    printStream = new PrintStream(new FileOutputStream(file4, false));
                                } catch (FileNotFoundException e) {
                                    e.printStackTrace();
                                }
                                printStream.println(0);
                            }

                        }


                    }
                }

            }
        }
    }

    public void add_message(add_message_event e){
      //  usernames.add(this.currentuser.getUsername());
      //  messages.add(e.getContent());
      //  types.add(e.getType());
        logger.info("user : "+ this.currentuser.getUsername()+ "  added a message");

        if(username2==null){
            update_chats_event load_chats_event = new update_chats_event(this,messages,usernames,types,this.currentuser.getUsername(),"000");
            motherlistener.getList_listener().update_chats(load_chats_event);
            this.currentgroup.setUsernames(usernames);
            this.currentgroup.setTypes(types);
            this.currentgroup.setMessages(messages);
            save_g_chats();
        }
        else{
            update_chats_event load_chats_event = new update_chats_event(this,messages,usernames,types,this.currentuser.getUsername(),this.model.get_user_by_username(username2).getImgpath());
            motherlistener.getList_listener().update_chats(load_chats_event);
            save_2_chats();
        }



    }
    public void delete_message(delete_message_event e){
        logger.info("user : "+ this.currentuser.getUsername()+ " deleted message");
        if(usernames.get(currentmsgid).equals(this.currentuser.getUsername())) {
            messages.remove(currentmsgid);
            usernames.remove(currentmsgid);
            types.remove(currentmsgid);
            if (username2 == null) {
                this.currentgroup.setUsernames(usernames);
                this.currentgroup.setTypes(types);
                this.currentgroup.setMessages(messages);
                save_g_chats();
            } else {
                save_2_chats();
            }
        }

        update_chats_event load_chats_event = new update_chats_event(this,messages,usernames,types,this.currentuser.getUsername());
        motherlistener.getList_listener().update_chats(load_chats_event);
    }

    public void edit_content_of_msg(edit_content_msg_event e){
        logger.info("user : "+ this.currentuser.getUsername()+ " edited a message");
        if(usernames.get(currentmsgid).equals(this.currentuser.getUsername())) {
            messages.set(currentmsgid, e.getContent());
            update_chats_event load_chats_event = new update_chats_event(this, messages, usernames, types, this.currentuser.getUsername());
            motherlistener.getList_listener().update_chats(load_chats_event);
            if (username2 == null) {
                this.currentgroup.setUsernames(usernames);
                this.currentgroup.setTypes(types);
                this.currentgroup.setMessages(messages);
                save_g_chats();
            } else {
                save_2_chats();
            }
        }

    }
   // public void forward_mesg()
    public void save_2_chats(){

        if(username2.equals(currentuser.getUsername())){
            File file=new File("database/savedmessages/"+username2);
            if(!file.exists()){
                try {
                    file.createNewFile();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            Gson gg=new Gson();
            try {
                PrintStream printStream=new PrintStream(new FileOutputStream(file,false));
                chat c = new chat();
                c.setMessages(messages);
                c.setTypes(types);
                c.setUsernames(usernames);
                printStream.println(gg.toJson(c));


                printStream.flush();
                printStream.close();

            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }


        }
        else {
            String path1 = "database/chats/" + this.currentuser.getUsername() + "_" + username2;
            String path2 = "database/chats/" + username2 + "_" + this.currentuser.getUsername();
            File file1 = new File(path1);
            File file2 = new File(path2);
            PrintStream printStream = null;

            if (file1.exists()) {
                try {
                    printStream = new PrintStream(new FileOutputStream(file1, false));
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }

            } else if (file2.exists()) {
                try {
                    printStream = new PrintStream(new FileOutputStream(file2, false));
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }
            } else {


                try {
                    file1.createNewFile();
                    printStream = new PrintStream(new FileOutputStream(file1, false));
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            Gson gg = new Gson();

            chat c = new chat();
            c.setMessages(messages);
            c.setTypes(types);
            c.setUsernames(usernames);
            printStream.println(gg.toJson(c));


            printStream.flush();
            printStream.close();
            File file3 = new File("database/chat_notifs/" + username2);
            int flag = 0;
            if (!file3.exists()) {

                file3.mkdirs();

                flag = 1;


            } else {
                try {
                    File file4 = new File("database/chat_notifs/" + username2 + "/" + this.currentuser.getUsername());
                    if (!file4.exists()) {
                        try {
                            file4.createNewFile();
                            PrintStream printStream1 = new PrintStream(new FileOutputStream(file4, false));
                            printStream1.println(1);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    } else {
                        Scanner scanner1 = new Scanner(file4);
                        int i = scanner1.nextInt();
                        PrintStream printStream1 = new PrintStream(new FileOutputStream(file4, false));
                        printStream1.println(i + 1);
                    }


                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }
            }
            if (flag == 1) {
                File file4 = new File("database/chat_notifs/" + username2 + "/" + this.currentuser.getUsername());
                if (!file4.exists()) {
                    try {
                        file4.createNewFile();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }

                }

                try {
                    PrintStream printStream1 = new PrintStream(new FileOutputStream(file4, false));
                    printStream1.println(1);
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }

            }
        }
    }
    public void save_g_chats(){
        Gson gg=new Gson();
        File file=new File("database/groupchats/"+currentgroup.getName());
        PrintStream printStream = null;
        try {
            printStream = new PrintStream(new FileOutputStream(file, false));
            printStream.println(gg.toJson(currentgroup));
            printStream.flush();
            printStream.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }




    }
    public void intitialize_tweets_list(initiliaze_event event1){
        for(int i:this.currentuser.getFollowings()){

            User u1=this.model.get_user_by_id(i);
            if(u1.getIsactive() ) {
                for (int j : u1.getTwitts()) {
                    if(this.model.get_twitt_by_id(j).getReportsnum()<10) {
                        currenttwittlist.add(this.model.get_twitt_by_id(j));
                    }
                }
            }
        }

        for(int i:this.currentuser.getFollowings()){

            User u1=this.model.get_user_by_id(i);
            if(u1.getIsactive()) {
                for (int j : u1.getWhichliked()) {
                    if(this.model.get_twitt_by_id(j).getReportsnum()<10) {
                        currenttwittlist.add(this.model.get_twitt_by_id(j));
                    }
                }
            }
        }

        defaultlist.addAll(currenttwittlist);
        if(defaultlist.size()>0){
            currenttwitt=defaultlist.get(0);
            tweetindex=0;
            for(int i=0;i<currenttwitt.getCommentsid().size();i++){
                if(this.model.get_twitt_by_id(currenttwitt.getCommentsid().get(i)).getReportsnum()<10) {
                    comments.add(this.model.get_twitt_by_id(currenttwitt.getCommentsid().get(i)));

                }
            }
            if(this.model.get_user_by_id(currenttwitt.getUserid())!=null) {
                send_tweet_n_comments_event event = new send_tweet_n_comments_event(this,this.model.get_user_by_id(currenttwitt.getUserid()).getImgpath(),this.model.get_user_by_id(currenttwitt.getUserid()).getUsername(),currenttwitt,comments);
                motherlistener.getTweet_listener().show_tweet(event);
            }
        }




    }
    public void go_to_parent_twitt(){ if(this.currenttwitt!=null) {
        if(parents.size()>0) {
            currenttwitt = parents.get(parents.size() - 1);
            parents.remove(parents.size() - 1);
            comments.clear();
            for (int i = 0; i < currenttwitt.getCommentsid().size(); i++) {
                if(this.model.get_twitt_by_id(currenttwitt.getCommentsid().get(i)).getReportsnum()<10) {

                    comments.add(this.model.get_twitt_by_id(currenttwitt.getCommentsid().get(i)));
                }
            }
            if(parents.size()>0) {
                for (int i = 0; i < parents.get(parents.size() - 1).getCommentsid().size(); i++) {
                    currenttwittlist.clear();
                    if(this.model.get_twitt_by_id(parents.get(parents.size() - 1).getCommentsid().get(i)).getReportsnum()<10) {
                    currenttwittlist.add(this.model.get_twitt_by_id(parents.get(parents.size() - 1).getCommentsid().get(i)));
                }}
            }
            else {
                currenttwittlist=defaultlist;
            } if(this.model.get_user_by_id(currenttwitt.getUserid())!=null) {
                send_tweet_n_comments_event event = new send_tweet_n_comments_event(this,this.model.get_user_by_id(currenttwitt.getUserid()).getImgpath(),this.model.get_user_by_id(currenttwitt.getUserid()).getUsername(),currenttwitt,comments);
            motherlistener.getTweet_listener().show_tweet(event);
        }}}
    }
    public void go_to_next_tweet(){ if(this.currenttwitt!=null) {
        if (tweetindex + 1 < currenttwittlist.size()) {
            tweetindex++;
            currenttwitt = currenttwittlist.get(tweetindex);
            comments.clear();
            for (int i = 0; i < currenttwitt.getCommentsid().size(); i++) {
                if (this.model.get_twitt_by_id(currenttwitt.getCommentsid().get(i)).getReportsnum() < 10) {
                    comments.add(this.model.get_twitt_by_id(currenttwitt.getCommentsid().get(i)));
                }
            }
        }
        if (this.model.get_user_by_id(currenttwitt.getUserid()) != null) {
            send_tweet_n_comments_event event = new send_tweet_n_comments_event(this,this.model.get_user_by_id(currenttwitt.getUserid()).getImgpath(),this.model.get_user_by_id(currenttwitt.getUserid()).getUsername(),currenttwitt,comments);
            motherlistener.getTweet_listener().show_tweet(event);
        }
    }
    }
    public void go_to_previous_tweet(){ if(this.currenttwitt!=null) {
        if (tweetindex - 1 >= 0) {
            tweetindex--;
            currenttwitt = currenttwittlist.get(tweetindex);
            comments.clear();
            for (int i = 0; i < currenttwitt.getCommentsid().size(); i++) {
                if (this.model.get_twitt_by_id(currenttwitt.getCommentsid().get(i)).getReportsnum() < 10) {
                    comments.add(this.model.get_twitt_by_id(currenttwitt.getCommentsid().get(i)));
                }
            }
        }
        if (this.model.get_user_by_id(currenttwitt.getUserid()) != null) {
            send_tweet_n_comments_event event = new send_tweet_n_comments_event(this,this.model.get_user_by_id(currenttwitt.getUserid()).getImgpath(),this.model.get_user_by_id(currenttwitt.getUserid()).getUsername(),currenttwitt,comments);
            motherlistener.getTweet_listener().show_tweet(event);
        }
    }
    }
    public void report_tweet(){ if(this.currenttwitt!=null) {
        logger.info("user : "+ this.currentuser.getUsername()+ " reported a tweet");
        if (!currenttwitt.getWho_has_reported().contains(this.currentuser.getId())) {

            currenttwitt.setReportsnum(currenttwitt.getReportsnum() + 1);
            currenttwitt.getWho_has_reported().add(this.currentuser.getId());
        }
        modelsaver.set_twiits_in_directory();
    }
    }
    public void block_wrtier(){ if(this.currenttwitt!=null) {
        int id=currenttwitt.getUserid(); // must be changed
        this.currentuser.getBlacklist().add(id)
        ;
        if(this.currentuser.getFollowers().contains(id)){
            this.currentuser.getFollowers().remove((Object)id);
        }
        if(this.currentuser.getFollowings().contains(id)){
            this.currentuser.getFollowings().remove((Object)id);
        }
        update();}

    }
    public void like_tweet(){
        logger.info("user : "+ this.currentuser.getUsername()+ " likked a tweet");
        if(this.currenttwitt!=null) {
        if(!this.currenttwitt.getWho_has_liked().contains(this.currentuser.getId())) {
            this.currenttwitt.setLikenum(this.currenttwitt.getLikenum() + 1);
            this.currenttwitt.getWho_has_liked().add(this.currentuser.getId());
            currentuser.getWhichliked().add(this.currenttwitt.getId());
        }
       update();}
    }
    public void retweet_tweet(){ if(this.currenttwitt!=null) {
        logger.info("user : "+ this.currentuser.getUsername()+ " retweet a tweet");
        twitt t=new twitt();
        t.setContent(currenttwitt.getContent());
        t.setUserid(currentuser.getId());
        t.setId(this.model.getTwitts().size()+1);
        t.setLikenum(0);
        t.setImgpath(currenttwitt.getImgpath());
        t.setName(this.currentuser.getUsername());
        this.model.getTwitts().add(t);
        this.currentuser.getTwitts().add(t.getId());
        update();}
    }

    public void add_comment(add_comment_tweet event){
        logger.info("user : "+ this.currentuser.getUsername()+ " added a comment");
        twitt t=new twitt();
        t.setContent(currenttwitt.getContent());
        t.setUserid(currentuser.getId());
        t.setId(this.model.getTwitts().size()+1);
        t.setLikenum(0);
        t.setName(this.currentuser.getUsername());
        t.setImgpath(event.getImgpath());
        t.setUsername(currentuser.getUsername());
        this.model.getTwitts().add(t);
        this.currentuser.getTwitts().add(t.getId());
        if(this.currenttwitt!=null) {
            this.currenttwitt.getCommentsid().add(t.getId());
            if (this.model.get_user_by_id(currenttwitt.getUserid()) != null) {
                send_tweet_n_comments_event event1 = new send_tweet_n_comments_event(this,this.model.get_user_by_id(currenttwitt.getUserid()).getImgpath(),this.model.get_user_by_id(currenttwitt.getUserid()).getUsername(),currenttwitt,comments);
                motherlistener.getTweet_listener().show_tweet(event1);
            }
        }
        update();


    }
    public void send_tweet(send_tweet_event event){
        logger.info("user : "+ this.currentuser.getUsername()+ " send a tweet");
        twitt tweet=new twitt();
        tweet.setId(this.model.getTwitts().size()+1);
        tweet.setUserid(currentuser.getId());
        tweet.setContent(event.getContent());
        tweet.setName(this.currentuser.getUsername());
        tweet.setImgpath(event.getImgpath());
        this.model.getTwitts().add(tweet);
        this.currentuser.getTwitts().add(tweet.getId());
        if(this.currenttwitt!=null) {
            if(this.model.get_user_by_id(currenttwitt.getUserid())!=null) {
                send_tweet_n_comments_event event1 = new send_tweet_n_comments_event(this,this.model.get_user_by_id(currenttwitt.getUserid()).getImgpath(),this.model.get_user_by_id(currenttwitt.getUserid()).getUsername(),currenttwitt,comments);
                motherlistener.getTweet_listener().show_tweet(event1);
            }

        }
        update();

    }
    public void go_to_child(comment_clicked event){
        if(this.currenttwitt!=null) {
            int twiitid = event.getId();
            parents.add(currenttwitt);
            indexes.add(tweetindex);
            currenttwitt = this.model.get_twitt_by_id(twiitid);
            comments.clear();
            for (int i = 0; i < currenttwitt.getCommentsid().size(); i++) {
                if (this.model.get_twitt_by_id(currenttwitt.getCommentsid().get(i)).getReportsnum()<10) {
                    comments.add(this.model.get_twitt_by_id(currenttwitt.getCommentsid().get(i)));
                }
            }
            if(this.model.get_user_by_id(currenttwitt.getUserid())!=null) {
                send_tweet_n_comments_event event1 = new send_tweet_n_comments_event(this,this.model.get_user_by_id(currenttwitt.getUserid()).getImgpath(),this.model.get_user_by_id(currenttwitt.getUserid()).getUsername(),currenttwitt,comments);
                motherlistener.getTweet_listener().show_tweet(event1);
            }
        }

    }
    public void go_to_writer_page_event(go_to_writer_page_event event){
        if(this.currenttwitt!=null) {
            User user = this.model.get_user_by_id(this.model.get_twitt_by_id(event.getTweetid()).getUserid());
            showeduser = user;
            String name = user.getFirstname();
            String lastname = user.getLastname();
            String username = user.getUsername();
            String email = user.getEmail();
            String bio = user.getBio();
            String lastseen = "";
            String imagepath = user.getImgpath();
            if (user.getLastseentype() == 1) {
                lastseen = "last seen : " + user.getDate() + " : " + user.getTime();
            } else if (user.getLastseentype() == 2 && this.currentuser.getFollowers().contains(user.getId())) {
                lastseen = "last seen : " + user.getDate() + " : " + user.getTime();
            } else {
                lastseen = "last seen recently";
            }
            send_viewed_user_datas_event e = new send_viewed_user_datas_event(this, name, lastname, username, email, lastseen, bio, imagepath);
            motherlistener.getForm_listener().send_other_user_datas(e);
        }



    }
    public void update_last_seen(User user){
        LocalDate ld=LocalDate.now();
        LocalTime lt=LocalTime.now();
        String time=lt.getHour()+" : "+lt.getMinute();
        user.setDate(ld.toString());
        user.setTime(time);

    }
    public void block_viewed_user(block_event event){
        this.currentuser.getBlacklist().add(showeduser.getId());
        if (this.currentuser.getFollowers().contains(showeduser.getId())) {
            this.currentuser.getFollowers().remove((Object) showeduser.getId());

        }
        if (this.currentuser.getFollowings().contains(showeduser.getId())) {
            this.currentuser.getFollowings().remove((Object) showeduser.getId());
        }
        update();
    }
    public void send_request(friend_request_send_event event) {
        logger.info("user : "+ this.currentuser.getUsername()+ " sent a request");
        if (!showeduser.getBlacklist().contains(this.currentuser.getId()) && !this.currentuser.getBlacklist().contains(showeduser.getId())) {
            if (showeduser.getPrivacytype() == 1) {
                System.out.println("done!!!");
                this.currentuser.addfollowings(showeduser.getId());
                showeduser.addfollower(this.currentuser.getId());

            }
            if (showeduser.getPrivacytype() == 2) {
                System.out.println("request sent!!");
                showeduser.getFriend_req_lists().add(this.currentuser.getId());
                this.currentuser.getPending_req().add(showeduser.getId());



            }
            update();

        }
    }
    public void send_message_userpage(message_send_event event){
        username2=showeduser.getUsername();
        User user2 = showeduser;
        if(this.currentuser.getFollowers().contains(this.model.get_user_by_username(username2).getId()) || this.currentuser.getFollowings().contains(this.model.get_user_by_username(username2).getId())){
               Gson gg=new Gson();



                String path1 = "database/chats/" + this.currentuser.getUsername() + "_" + user2.getUsername();
                String path2 = "database/chats/" + user2.getUsername() + "_" + this.currentuser.getUsername();
                File file1 = new File(path1);
                File file2 = new File(path2);
                if (file1.exists()) {
                    Scanner scanner = null;
                    try {
                        scanner = new Scanner(file1);
                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                    }



                    chat chat= gg.fromJson(scanner.nextLine(),chat.class);
                    usernames=chat.getUsernames();
                    messages=chat.getMessages();
                    types=chat.getTypes();
                    send_chats_event load_chats_event = new send_chats_event(this,this.messages,this.usernames,this.types, currentuser.getUsername(),user2.getImgpath());
                    motherlistener.getUserpage_listener().show_chats(load_chats_event);

                    File file3 = new File("database/chat_notifs/" + this.currentuser.getUsername());
                    if (!file3.exists()) {
                        file3.mkdirs();

                    } else {
                        File file4 = new File("database/chat_notifs/" + this.currentuser.getUsername() + "/" + user2.getUsername());
                        if (!file4.exists()) {

                        } else {
                            PrintStream printStream = null;
                            try {
                                printStream = new PrintStream(new FileOutputStream(file4, false));
                            } catch (FileNotFoundException e) {
                                e.printStackTrace();
                            }
                            printStream.println(0);
                        }

                    }


                } else if (file2.exists()) {
                    Scanner scanner = null;
                    try {
                        scanner = new Scanner(file2);
                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                    }


                    chat chat= gg.fromJson(scanner.nextLine(),chat.class);
                    usernames=chat.getUsernames();
                    messages=chat.getMessages();
                    types=chat.getTypes();
                    send_chats_event load_chats_event = new send_chats_event(this,this.messages,this.usernames,this.types, currentuser.getUsername(),user2.getImgpath());
                    motherlistener.getUserpage_listener().show_chats(load_chats_event);

                    File file3 = new File("database/chat_notifs/" + this.currentuser.getUsername());
                    if (!file3.exists()) {
                        file3.mkdirs();

                    } else {
                        File file4 = new File("database/chat_notifs/" + this.currentuser.getUsername() + "/" + user2.getUsername());
                        if (!file4.exists()) {

                        } else {
                            PrintStream printStream = null;
                            try {
                                printStream = new PrintStream(new FileOutputStream(file4, false));
                            } catch (FileNotFoundException e) {
                                e.printStackTrace();
                            }
                            printStream.println(0);
                        }

                    }
                } else {
                    send_chats_event load_chats_event = new send_chats_event(this,this.messages,this.usernames,this.types, currentuser.getUsername(),user2.getImgpath());
                    motherlistener.getUserpage_listener().show_chats(load_chats_event);


                }}



            }
    public void go_forward_page_t(forward_tweet_event event ){
        if(this.currenttwitt!=null) {
            for (int i = 0; i < this.currentuser.getFollowings().size(); i++) {
                if (!who_can_forward_list.contains(this.model.get_user_by_id(this.currentuser.getFollowings().get(i)).getUsername())) {
                    who_can_forward_list.add(this.model.get_user_by_id(this.currentuser.getFollowings().get(i)).getUsername());
                }
            }
            for (int i = 0; i < this.currentuser.getFollowers().size(); i++) {
                if (!who_can_forward_list.contains(this.model.get_user_by_id(this.currentuser.getFollowers().get(i)).getUsername())) {
                    who_can_forward_list.add(this.model.get_user_by_id(this.currentuser.getFollowers().get(i)).getUsername());
                }
            }
            for(String s:this.currentuser.getGroups().keySet()){
                who_can_forward_list.add(s);
            }
            String content = event.getContent();
            String contactnames = "you can forward to:     ";
            for (int i = 0; i < who_can_forward_list.size(); i++) {
                contactnames = contactnames + who_can_forward_list.get(i) + " - ";
            }
            initialize_forward_message_event event1 = new initialize_forward_message_event(this, content, contactnames);
            motherlistener.getTweet_listener().go_to_forward_page(event1);
        }
    }
    public void go_forward_page_c(forward_message_event event){
        for (int i = 0; i < this.currentuser.getFollowings().size(); i++) {
            if (!who_can_forward_list.contains(this.model.get_user_by_id(this.currentuser.getFollowings().get(i)).getUsername())) {
                who_can_forward_list.add(this.model.get_user_by_id(this.currentuser.getFollowings().get(i)).getUsername());
            }
        }
        for (int i = 0; i < this.currentuser.getFollowers().size(); i++) {
            if (!who_can_forward_list.contains(this.model.get_user_by_id(this.currentuser.getFollowers().get(i)).getUsername())) {
                who_can_forward_list.add(this.model.get_user_by_id(this.currentuser.getFollowers().get(i)).getUsername());
            }
        }
        for(String s:this.currentuser.getGroups().keySet()){
            who_can_forward_list.add(s);
        }
        for(int i:this.currentuser.getEngaged_groups()){
            if(this.model.get_group_by_id(i)!=null &&this.model.get_group_by_id(i).getName()!=null){
            who_can_forward_list.add(this.model.get_group_by_id(i).getName());}
        }
        String content=messages.get(currentmsgid);
        String contactnames="you can forward to:     ";
        for(int i=0;i<who_can_forward_list.size();i++){
            contactnames=contactnames+who_can_forward_list.get(i)+" - ";
        }
        initialize_forward_message_event event1=new initialize_forward_message_event(this,content,contactnames);
        motherlistener.getForm_listener().initialize_forward_page(event1);

    }
    public void forward_to_users(send_users_to_logic_event event) {
        logger.info("user : "+ this.currentuser.getUsername()+ " forwarded a message");
        if (event.getNumber() == 1) {
            for (String name : event.getContactnames()) {
                System.out.println("dodolll");
                System.out.println(name);
                if (this.model.get_user_by_username(name) != null) {

                    String mes = messages.get(currentmsgid);
                    int type = types.get(currentmsgid);

                    easy_load_chats(name);
                    System.out.println(name);
                    usernames.add(this.currentuser.getUsername());
                    types.add(type);
                    messages.add(mes);
                    username2 = name;
                    save_2_chats();
                } else if (this.model.get_group_by_name(name) != null) {
                    currentgroup = this.model.get_group_by_name(name);
                    String mes = messages.get(currentmsgid);
                    int type = types.get(currentmsgid);

                    easy_load_chats(name);
                    usernames.add(this.currentuser.getUsername());
                    types.add(type);
                    messages.add(mes);

                    currentgroup.setMessages(messages);
                    currentgroup.setTypes(types);
                    currentgroup.setUsernames(usernames);
                    save_g_chats();
                }

                else if (this.currentuser.getGroups().get(name)!=null) {

                    System.out.println("yes");
                    for (int i : this.currentuser.getGroups().get(name)) {
                        String mes = messages.get(currentmsgid);
                        int type = types.get(currentmsgid);

                        username2 = this.model.get_user_by_id(i).getUsername();
                        System.out.println(username2);
                        easy_load_chats(username2);
                        usernames.add(this.currentuser.getUsername());
                        types.add(type);
                        messages.add(mes);


                        save_2_chats();
                    }
                }
                System.out.println(this.currentuser.getGroups().containsKey(name));

            }

        }
        else { for (String name : event.getContactnames()) {
            if (currenttwitt.getImgpath()==null) {


                if (this.model.get_user_by_username(name) != null) {
                    int type = 0;
                    String mes = currenttwitt.getContent();

                    type = 1;


                    easy_load_chats(name);
                    System.out.println(name);
                    usernames.add(this.currentuser.getUsername());
                    types.add(type);
                    messages.add(mes);
                    username2 = name;
                    save_2_chats();
                } else if (this.model.get_group_by_name(name) != null) {
                    currentgroup = this.model.get_group_by_name(name);
                    int type = 0;
                    String mes = currenttwitt.getContent();

                    type = 1;

                    easy_load_chats(name);
                    usernames.add(this.currentuser.getUsername());
                    types.add(type);
                    messages.add(mes);

                    currentgroup.setMessages(messages);
                    currentgroup.setTypes(types);
                    currentgroup.setUsernames(usernames);
                    save_g_chats();
                } else if (this.currentuser.getGroups().containsKey(name)) {


                    for (int i : this.currentuser.getGroups().get(name)) {
                        int type = 0;
                        String mes = currenttwitt.getContent();

                        type = 1;

                        easy_load_chats(name);
                        usernames.add(this.currentuser.getUsername());
                        types.add(type);
                        messages.add(mes);

                        username2 = this.model.get_user_by_id(i).getUsername();
                        save_2_chats();
                    }
                }

            }
            else {
                if (this.model.get_user_by_username(name) != null) {
                    int type = 0;
                    String mes = currenttwitt.getContent();

                    type = 1;


                    easy_load_chats(name);
                    System.out.println(name);
                    usernames.add(this.currentuser.getUsername());
                    types.add(type);
                    messages.add(mes);
                    username2 = name;
                    save_2_chats();
                    type=2;
                    mes=currenttwitt.getImgpath();
                    easy_load_chats(name);
                    System.out.println(name);
                    usernames.add(this.currentuser.getUsername());
                    types.add(type);
                    messages.add(mes);
                    username2 = name;
                    save_2_chats();
                }
                else if (this.model.get_group_by_name(name) != null) {
                    currentgroup = this.model.get_group_by_name(name);
                    int type = 0;
                    String mes = currenttwitt.getContent();

                    type = 1;

                    easy_load_chats(name);
                    usernames.add(this.currentuser.getUsername());
                    types.add(type);
                    messages.add(mes);
                    currentgroup.setMessages(messages);
                    currentgroup.setTypes(types);
                    currentgroup.setUsernames(usernames);
                    save_g_chats();
                    type=2;
                    mes=currenttwitt.getImgpath();
                    easy_load_chats(name);
                    usernames.add(this.currentuser.getUsername());
                    types.add(type);
                    messages.add(mes);

                    currentgroup.setMessages(messages);
                    currentgroup.setTypes(types);
                    currentgroup.setUsernames(usernames);
                    save_g_chats();
                }else if (this.currentuser.getGroups().containsKey(name)) {


                    for (int i : this.currentuser.getGroups().get(name)) {
                        int type = 0;
                        String mes = currenttwitt.getContent();

                        type = 1;

                        easy_load_chats(name);
                        usernames.add(this.currentuser.getUsername());
                        types.add(type);
                        messages.add(mes);

                        username2 = this.model.get_user_by_id(i).getUsername();
                        save_2_chats();
                        type=2;
                        mes=currenttwitt.getImgpath();
                        easy_load_chats(name);
                        usernames.add(this.currentuser.getUsername());
                        types.add(type);
                        messages.add(mes);
                        save_2_chats();
                    }
                }

            }
        }


        }
    }
    public void send_datas_to_group_page(set_datas_perm_event e){
        String contactnames="you can make group with: ";
        for(int i:this.currentuser.getFollowings()){
            contactnames=contactnames+this.model.get_user_by_id(i).getUsername()+" - ";
        }
        send_list_of_follower_event event1=new send_list_of_follower_event(this,contactnames);
        motherlistener.getList_listener().send_list_of_group_makes(event1);
    }
    public void make_new_group(make_group_event e){
        logger.info("user : "+ this.currentuser.getUsername()+ " maked a new group");
        group g=new group();
        g.setName(e.getName());
        g.setGroupid(this.model.getGroups().size()+1);
        for(int i=0;i<e.getNames().size();i++){
            System.out.println(e.getNames().get(i));
            if(this.model.get_user_by_username(e.getNames().get(i))!=null){
            int j=this.model.get_user_by_username(e.getNames().get(i)).getId();
                this.model.get_user_by_username(e.getNames().get(i)).getEngaged_groups().add(g.getGroupid());
            g.getUserids().add(j);}
        }
        this.currentuser.getEngaged_groups().add(g.getGroupid());
        g.getUserids().add(currentuser.getId());
        g.setGroupid(this.model.getGroups().size()+1);
        this.model.getGroups().add(g);
       update();

    }
    public void make_request_list(){
        ArrayList<String> requsernames=new ArrayList<>();
        for(int i:this.currentuser.getFriend_req_lists()){
            requsernames.add(this.model.get_user_by_id(i).getUsername());
        }
        firstnotifs();
        send_usernames_to_notifpage_event event1=new send_usernames_to_notifpage_event(this,requsernames);
        motherlistener.getString_listener().initiale_notif_page(event1);
        update();
    }
    public void accepted_request(accepted_req_event e){
        logger.info("user : "+ this.currentuser.getUsername()+ " accepted a request");
        int id=this.model.get_user_by_username(e.getUsername()).getId();
        this.currentuser.getFriend_req_lists().remove((Object)id);
        this.currentuser.getFollowers().add(id);
        this.model.get_user_by_username(e.getUsername()).getFollowings().add(this.currentuser.getId());
        this.model.get_user_by_username(e.getUsername()).getAccepted_reqs().add(this.currentuser.getId());
        this.model.get_user_by_username(e.getUsername()).getPending_req().remove((Object)this.currentuser.getId());
        ArrayList<String> requsernames=new ArrayList<>();
        for(int i:this.currentuser.getFriend_req_lists()){
            requsernames.add(this.model.get_user_by_id(i).getUsername());
        }
        send_usernames_to_notifpage_event event1=new send_usernames_to_notifpage_event(this,requsernames);
        motherlistener.getString_listener().initiale_notif_page(event1);
        update();


    }
    public void rejected_request(rejected_req_event e){ logger.info("user : "+ this.currentuser.getUsername()+ " rejected a request");
        int id=this.model.get_user_by_username(e.getUsername()).getId();
        this.currentuser.getFriend_req_lists().remove((Object)id);
        this.model.get_user_by_username(e.getUsername()).getRejected_reqs().add(this.currentuser.getId());
        this.model.get_user_by_username(e.getUsername()).getPending_req().remove((Object)this.currentuser.getId());
        ArrayList<String> requsernames=new ArrayList<>();
        for(int i:this.currentuser.getFriend_req_lists()){
            requsernames.add(this.model.get_user_by_id(i).getUsername());
        }
        send_usernames_to_notifpage_event event1=new send_usernames_to_notifpage_event(this,requsernames);
        motherlistener.getString_listener().initiale_notif_page(event1);
        update();

    }
    public void select_mesg(select_mesg_event e){

        this.currentmsgid=e.getMessageid();

    }
    public void go_to_search_userpage(go_to_user_page_event event){

            User user = this.model.get_user_by_username(event.getUsername());
            if(user!=null) {
                showeduser = user;
                String name = user.getFirstname();
                String lastname = user.getLastname();
                String username = user.getUsername();
                String email = user.getEmail();
                String bio = user.getBio();
                String lastseen = "";
                String imagepath = user.getImgpath();
                if (user.getLastseentype() == 1) {
                    lastseen = "last seen : " + user.getDate() + " : " + user.getTime();
                } else if (user.getLastseentype() == 2 && this.currentuser.getFollowers().contains(user.getId())) {
                    lastseen = "last seen : " + user.getDate() + " : " + user.getTime();
                } else {
                    lastseen = "last seen recently";
                }
                send_viewed_user_datas_event e = new send_viewed_user_datas_event(this, name, lastname, username, email, lastseen, bio, imagepath);
                motherlistener.getForm_listener().get_ready_to_go_touser_page(e);
            }
        }
        public void make_hot_list_tweet(){
            ArrayList<twitt> hotlist=new ArrayList<>();
            this.model.sort_tweets_by_like();
            for(twitt t:this.model.getTwitts()){
                User u=this.model.get_user_by_id(t.getUserid());
                if(u!=null && u.getIsactive() &&t.getReportsnum()<10) {

                        hotlist.add(t);
               }
            }
            if(hotlist.size()>0){
                System.out.println(hotlist.size());
                currenttwitt=hotlist.get(0);
                currenttwittlist=hotlist;
                defaultlist=hotlist;
                send_tweet_n_comments_event event1=new send_tweet_n_comments_event(this,this.model.get_user_by_id(currenttwitt.getUserid()).getImgpath(),this.model.get_user_by_id(currenttwitt.getUserid()).getUsername(),currenttwitt,comments);
                motherlistener.getTweet_listener().show_tweet(event1);}

            }
            public void firstnotifs(){
                ArrayList<String> notifs=new ArrayList<>();
                for(int j:this.currentuser.getRejected_reqs()){
                    notifs.add(this.model.get_user_by_id(j).getUsername()+"  has rejected your request");
                }
                for(int j:this.currentuser.getAccepted_reqs()){
                    notifs.add(this.model.get_user_by_id(j).getUsername()+ " has accepted your request");
                }
                for(int j:this.currentuser.getPending_req()){
                    notifs.add(" your friend request to " +this.model.get_user_by_id(j).getUsername()+ " is on pending ");
                }
                for(int j:this.currentuser.getRemove_from_followings()){
                    notifs.add(this.model.get_user_by_id(j).getUsername()+ " removed you from his followers");
                }
                for(int j:this.currentuser.getRemove_from_followers()){
                    notifs.add(this.model.get_user_by_id(j).getUsername()+ " removed you from his followings");
                }
                this.currentuser.getRemove_from_followers().clear();
                this.currentuser.getRemove_from_followings().clear();
                this.currentuser.getAccepted_reqs().clear();
                this.currentuser.getPending_req().clear();
                this.currentuser.getRejected_reqs().clear();
                bullshit_event b=new bullshit_event(this,notifs);
                motherlistener.getString_listener().initalie_notifs(b);
            }
            public void block_from_userpage(block_event e){

                if(this.currentuser.getFollowers().contains(showeduser.getId())){
                    this.currentuser.getFollowers().remove((Object) showeduser.getId());
                }
                if(this.currentuser.getFollowings().contains(showeduser.getId())){
                    this.currentuser.getFollowings().remove((Object) showeduser.getId());
                }
                this.currentuser.getBlacklist().add(showeduser.getId());
                update();
            }

            public void easy_load_chats(String name){
                Gson gg=new Gson();
                if (is_valid_user(name)) {
                    currentgroup=null;
                    username2=name;
                    User user2 = this.model.get_user_by_username(name);
                    String path1 = "database/chats/" + this.currentuser.getUsername() + "_" + user2.getUsername();
                    String path2 = "database/chats/" + user2.getUsername() + "_" + this.currentuser.getUsername();
                    File file1 = new File(path1);
                    File file2 = new File(path2);
                    if (file1.exists()) {
                        Scanner scanner = null;
                        try {
                            scanner = new Scanner(file1);
                        } catch (FileNotFoundException e) {
                            e.printStackTrace();
                        }



                        chat chat= gg.fromJson(scanner.nextLine(),chat.class);
                        usernames=chat.getUsernames();
                        messages=chat.getMessages();
                        types=chat.getTypes();

                        File file3 = new File("database/chat_notifs/" + this.currentuser.getUsername());
                        if (!file3.exists()) {
                            file3.mkdirs();

                        } else {
                            File file4 = new File("database/chat_notifs/" + this.currentuser.getUsername() + "/" + user2.getUsername());
                            if (!file4.exists()) {

                            } else {
                                PrintStream printStream = null;
                                try {
                                    printStream = new PrintStream(new FileOutputStream(file4, false));
                                } catch (FileNotFoundException e) {
                                    e.printStackTrace();
                                }
                                printStream.println(0);
                            }

                        }


                    } else if (file2.exists()) {
                        Scanner scanner = null;
                        try {
                            scanner = new Scanner(file2);
                        } catch (FileNotFoundException e) {
                            e.printStackTrace();
                        }


                        chat chat= gg.fromJson(scanner.nextLine(),chat.class);
                        usernames=chat.getUsernames();
                        messages=chat.getMessages();
                        types=chat.getTypes();


                        File file3 = new File("database/chat_notifs/" + this.currentuser.getUsername());
                        if (!file3.exists()) {
                            file3.mkdirs();

                        } else {
                            File file4 = new File("database/chat_notifs/" + this.currentuser.getUsername() + "/" + user2.getUsername());
                            if (!file4.exists()) {

                            } else {
                                PrintStream printStream = null;
                                try {
                                    printStream = new PrintStream(new FileOutputStream(file4, false));
                                } catch (FileNotFoundException e) {
                                    e.printStackTrace();
                                }
                                printStream.println(0);
                            }

                        }
                    } else {



                    }

                } else {
                    group gr = null;
                    username2 = null;
                    for (group g : this.model.getGroups()) {
                        if (g != null && g.getName()!=null) {
                            if (g.getName().equals(name)) {
                                usernames = g.getUsernames();

                                types = g.getTypes();
                                messages = g.getMessages();
                                currentgroup = g;

                                File file3 = new File("database/chat_notifs/" + this.currentuser.getUsername());
                                if (!file3.exists()) {
                                    file3.mkdirs();

                                } else {
                                    File file4 = new File("database/chat_notifs/" + this.currentuser.getUsername() + "/" + g.getName());
                                    if (!file4.exists()) {

                                    } else {
                                        PrintStream printStream = null;
                                        try {
                                            printStream = new PrintStream(new FileOutputStream(file4, false));
                                        } catch (FileNotFoundException e) {
                                            e.printStackTrace();
                                        }
                                        printStream.println(0);
                                    }

                                }


                            }
                        }

                    }
                }
            }
            public void show_own_tweets(){
                ArrayList<String> own_tweets=new ArrayList<>();
                for(twitt t:this.model.getTwitts()){
                    System.out.println("r");
                    if(t.getUserid()==currentuser.getId()){
                        System.out.println();
                        own_tweets.add(t.getContent()+"\n"+"like num:"+t.getLikenum()+"\n"+"reports num:"+t.getReportsnum());
                    }
                }
                send_own_tweets_event event=new send_own_tweets_event(this,own_tweets);
                motherlistener.getTweet_listener().send_own_tweets(event);

            }
            public void exit(){
        logger.info("user :"+this.currentuser.getUsername()+"exit from the program");
        update_last_seen(this.currentuser);
        update();
        System.exit(0);
            }
            public void add_user_to_group(String groupname,String username){
                System.out.println("enterd method");
                System.out.println(groupname+ "              "+username);
                if(this.model.get_group_by_name(groupname)!=null && this.model.get_group_by_name(groupname).getUserids().contains(this.currentuser.getId())){
                    System.out.println("first if");
                    if(this.model.get_user_by_username(username)!=null){
                        System.out.println("seconde if");
                        this.model.get_group_by_name(groupname).getUserids().add(this.model.get_user_by_username(username).getId());
                        this.model.get_user_by_username(username).getEngaged_groups().add( this.model.get_group_by_name(groupname).getGroupid());

                    }
                }
                update();
            }



        }





