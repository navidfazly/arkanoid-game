package logic;

public class chatpage_cont {
}
