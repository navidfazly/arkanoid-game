package logic;

import model.User;
import model.notification;
import model.twitt;

import java.io.*;
import java.util.*;
public class timeline {
    User user;
    modelloader md;
    public timeline(User user1,modelloader modelloader){
        this.user=user1;
        this.md=modelloader;
    }
    public void main(){
        modelsaver msaver= new modelsaver(this.md);
        ArrayList<twitt> twitts=new ArrayList<>();
        for(int i:this.user.getFollowings()){

            User u1=this.md.get_user_by_id(i);
            if(u1.getIsactive()) {
                for (int j : u1.getTwitts()) {
                    twitts.add(this.md.get_twitt_by_id(j));
                }
            }
        }
        for(int i:this.user.getFollowings()){

            User u1=this.md.get_user_by_id(i);
            if(u1.getIsactive()) {
                for (int j : u1.getWhichliked()) {
                    twitts.add(this.md.get_twitt_by_id(j));
                }
            }
        }
        int index=0;
        if(twitts.size()!=0) {
            tweetoptions(twitts,index);
        }



    }
    public void tweetoptions( ArrayList<twitt> twitts , int index){
        twitt tt=twitts.get(index);
        if(this.md.get_user_by_id(tt.getUserid())!=null) {
            show_each_tweet(tt);
            int i = inputLoop(0, 11);
            while (i != 0) {


                modelsaver msaver = new modelsaver(this.md);
                msaver.initialize();

                if (i == 1) {
                    if (index < twitts.size() - 1) {
                        tweetoptions(twitts, index++);
                    } else {
                        System.out.println("no more tweet to show");
                    }
                } else if (i == 2) {
                    if (index > 1) {
                        tweetoptions(twitts, index--);
                    } else {
                        System.out.println("no more tweet to show");
                    }
                } else if (i == 3) {
                    tt.setLikenum(tt.getLikenum() + 1);
                    this.user.add_whichliked(tt.getId());


                    System.out.println("post was liked!!");
                } else if (i == 4) {

                    this.user.getTwitts().add(tt.getId());




                    System.out.println("post was retweeted!!");
                } else if (i == 5) {
                    chatpage c = new chatpage(this.md, this.user);
                    System.out.println("to who you want to forward?");
                    System.out.println("1. search by username");
                    System.out.println("2. my friends");
                    int input = inputLoop(1, 2);
                    if (input == 1) {
                        User u = c.getUser();
                        try {
                            c.forwardmessage(u, tt);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                    if (input == 2) {
                        c.forwardall(tt.getContent());
                    }

                } else if (i == 6) {
                    if(this.user.getFollowings().contains(tt.getUserid())){
                        this.user.getFollowings().remove(tt.getUserid());
                    }
                    if(this.user.getFollowers().contains(tt.getUserid())){
                        this.user.getFollowers().remove(tt.getUserid());
                    }
                    this.user.getBlacklist().add(tt.getUserid());
                    System.out.println("user blocked!!!");
                } else if (i == 7) {
                    if (this.user.getFollowings().contains(this.md.get_user_by_id(tt.getUserid()))) {
                        this.user.getFollowings().remove(tt.getUserid());
                    }
                    System.out.println("user muted!!!");

                } else if (i == 8) {
                    User us = this.md.get_user_by_id(tt.getUserid());
                    otherprofile otherprofile = new otherprofile(this.md, this.user);
                    otherprofile.show_datas(us);


                } else if (i == 9) {
                    twitt tweet = new twitt();
                    File file = new File("out/db/tweets");

                    Scanner sc = new Scanner(System.in);
                    System.out.println("enter your comment");
                    String content = sc.nextLine();
                    tweet.setName(this.user.getFirstname());
                    tweet.setContent(content);
                    tweet.setId(file.listFiles().length + 1);
                    tweet.setUserid(this.user.getId());
                    tt.getCommentsids().add(tweet.getId());


                    this.user.getTwitts().add(tweet.getId());
                    this.md.twitts.add(tweet);
                    System.out.println("comment posted successfully");


                } else if (i == 10) {
                    ArrayList<twitt> twitts_comment = new ArrayList<>();
                    for (int j : tt.getCommentsids()) {
                        twitt tweet = this.md.get_twitt_by_id(j);
                        twitts_comment.add(tweet);
                    }
                    tweetoptions(twitts_comment, 0);

                } else if (i == 11) {
                    File file = new File("out/db/savedmessages/" + String.valueOf(this.user.getUsername()));
                    if (!file.exists()) {
                        try {
                            file.createNewFile();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                    try {
                        PrintStream printStream = new PrintStream(new FileOutputStream(file, true));
                        printStream.println(tt.getContent());
                        printStream.println("***********");
                        printStream.flush();
                        printStream.close();
                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                    }
                }
                System.out.println("1. next tweet");
                System.out.println("2. previous tweet");
                System.out.println("3. like tweet");
                System.out.println("4. retweet tweet");
                System.out.println("5. forward tweet");
                System.out.println("6. block writer");
                System.out.println("7. mute writer");
                System.out.println("8. go to wrtiter page");
                System.out.println("9. write comment");
                System.out.println("10. read comments of the tweet");
                System.out.println("11. add tweet to saved messages");
                System.out.println("0.  back");
                i = inputLoop(0, 11);
            }
        }





    }
    public void show_each_tweet(twitt t){

        System.out.println(t.getName()+" : ");
        System.out.println(t.getContent());
        System.out.println("number of likes :"+t.getLikenum());
        System.out.println();
        

        System.out.println("1. next tweet");
        System.out.println("2. previous tweet");
        System.out.println("3. like tweet");
        System.out.println("4. retweet tweet");
        System.out.println("5. forward tweet");
        System.out.println("6. block writer");
        System.out.println("7. mute writer");
        System.out.println("8. go to wrtiter page");
        System.out.println("9. write comment");
        System.out.println("10. read comments of the tweet");
        System.out.println("11. add tweet to saved messages");
        System.out.println("0.  back");


    }

    public static int inputLoop(int start, int end){
        Scanner scanner = new Scanner(System.in);
        while (true){
            try {
                int input = scanner.nextInt();
                if (start <= input && input <= end) {
                    return input;
                }
            } catch (Exception ignored) {
                System.out.println("Invalid command! try again.");
            }
        }
    }


}
