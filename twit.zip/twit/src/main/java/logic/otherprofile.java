package logic;

import model.User;

import java.io.*;
import java.util.*;
public class otherprofile {
    modelloader md;
    User user;
    public otherprofile(modelloader modelloader,User u){
        this.user=u;
        this.md=modelloader;
    }


    public User enter_user_name(){
        System.out.println("enter user name of the user you want to find");
        Scanner scanner= new Scanner(System.in);
        String username=scanner.next();
        User user=this.md.get_user_by_username(username);
        while (user==null){
            System.out.println("no user found");
            System.out.println("#########");
            System.out.println("enter user name of the user you want to find");
            username=scanner.next();
            user=this.md.get_user_by_username(username);
        }
        return user;
    }
    public void show_datas(User user){
        System.out.println("name: "+user.getFirstname());
        System.out.println("family: "+user.getLastname());
        System.out.println("username: "+user.getUsername());
        System.out.println("bio: "+user.getBio());
        System.out.println("birthdate: "+user.getBirthdate());
        if(user.getLastseentype()==1){
            System.out.println("last seen : "+user.getDate()+" : "+ user.getTime());
        }
        else if(user.getLastseentype()==2 && this.user.getFollowers().contains(user.getId())){
            System.out.println("last seen : "+user.getDate()+" : "+ user.getTime());
        }
        else {
            System.out.println("last seen recently");
        }
        if(this.user.getFollowings().contains(user.getId())){

            System.out.println("you have followed this user");




        }
        else {

            System.out.println("you have not followed this user");
            System.out.println("do you want to follow this user?");
            System.out.println("1. yes");
            System.out.println("2. no");
            int j=inputLoop(1,2);
            if(j==1) {
                if (!user.getBlacklist().contains(this.user.getId()) && !this.user.getBlacklist().contains(user.getId())) {
                    if (user.getPrivacytype() == 1) {
                        System.out.println("done!!!");
                        this.user.addfollowings(user.getId());
                        user.addfollower(this.user.getId());

                    }
                    if (user.getPrivacytype() == 2) {
                        System.out.println("request sent!!");
                        user.getFriend_req_lists().add(this.user.getId());
                        this.user.getPending_req().add(user.getId());


                    }
                }
            }
        }
        if(!this.user.getBlacklist().contains(user.getId()) && !this.user.getFollowings().contains(user.getId())) {
            System.out.println("Do you want to block this user?");
            System.out.println("1. yes ");
            System.out.println("2. no");
            System.out.println("0. back ");
            int i = inputLoop(1, 2);

            if (i == 1) {
                this.user.getBlacklist().add(user.getId());
                System.out.println("user get blocked");
            }
        }
        System.out.println("do you want to report user?");
        System.out.println("1. yes");
        System.out.println("2. no");
        int op=inputLoop(1,2);
        while (op!=2){
            if(op==1){
                System.out.println("user was reported !!!");
            }

        }
        chatpage chatpage=new chatpage(this.md,this.user);
        if(chatpage.is_valid_chat(user,this.user) ){
            System.out.println("do you want to send message to this user?");
            System.out.println("1. yes");
            System.out.println("2. no");
            System.out.println("0. back");
            int x=inputLoop(0,2);
            if(x==1){

                chatpage.sendmessage(user);

            }

        }




    }
    public void intialiaze(){
        User u=enter_user_name();
        if(u.getIsactive()){
            show_datas(u);
        }
        else {

        }

    }

    public static int inputLoop(int start, int end){
        Scanner scanner = new Scanner(System.in);
        while (true){
            try {
                int input = scanner.nextInt();
                if (start <= input && input <= end) {
                    return input;
                }
            } catch (Exception ignored){ }
            System.out.println("Invalid command! try again.");
        }
    }
}
