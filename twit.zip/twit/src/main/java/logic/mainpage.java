package logic;

import logger.logger;
import model.User;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.*;

public class mainpage {
    User user;
    modelloader md;
    public mainpage(User user1,modelloader md1){
        this.user=user1;
        this.md=md1;
    }
    public void intialize(){
        logger log= new logger();
        log.info(this.user.getUsername()+" entered in the program");
        Thread th= new Thread();
        update_last_seen(this.user);
        System.out.println("choose what to do!");
        System.out.println("1. your own page");
        System.out.println("2. timeline page");
        System.out.println("3. explore");
        System.out.println("4. chat page");
        System.out.println("5. settings");
        System.out.println("0.  back");
        int i=inputLoop(0,5);
        while (i!=0){
                update_last_seen(this.user);



            if(i==1){
                ownpage ownpage= new ownpage(this.user,this.md);
                ownpage.intialize();
            }
            else if(i==2){
                timeline timeline=new timeline(this.user,this.md);
                timeline.main();
            }
            else if(i==3){
                explore explore= new explore(this.md,this.user);
                explore.show_options();
            }
            else if(i==4){
                chatpage chatpage= new chatpage(this.md,this.user);
                chatpage.initialize();

            }
            else if(i==5){
                settings settings =new settings(this.md,this.user);
                settings.initialize();
            }
            modelsaver msaver= new modelsaver(this.md);
            msaver.initialize();
            System.out.println("choose what to do!");
            System.out.println("1. your own page");
            System.out.println("2. timeline page");
            System.out.println("3. explore");
            System.out.println("4. chat page");
            System.out.println("5. settings");
            System.out.println("0.  back");
            i=inputLoop(0,5);
        }
    }
    public static int inputLoop(int start, int end){
        Scanner scanner = new Scanner(System.in);
        while (true){
            try {
                int input = scanner.nextInt();
                if (start <= input && input <= end) {
                    return input;
                }
            } catch (Exception ignored){ }
            System.out.println("invalid command! try again.");
        }
    }
    public void update_last_seen(User user){
        LocalDate ld=LocalDate.now();
        LocalTime lt=LocalTime.now();
        String time=lt.getHour()+" : "+lt.getMinute();
        user.setDate(ld.toString());
        user.setTime(time);

    }




}
