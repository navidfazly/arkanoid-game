package logic;

import model.User;
import model.notification;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;

public class notificationpage {
    User user;
    modelloader modelloader;
    public notificationpage(modelloader modelloader ,User user){
        this.modelloader=modelloader;
        this.user=user;

    }
    public void show_requests(){
        for(int i:this.user.getFriend_req_lists()){
            User u=this.modelloader.get_user_by_id(i);
            System.out.println(u.getUsername()+ " sent friend request to you");
            System.out.println("**********");
            System.out.println("1. accept");
            System.out.println("2. reject and inform user");
            System.out.println("3. reject and not inform user");
            int input=inputLoop(1,3);
            if(input==1){
                this.user.addfollower(u.getId());
                u.getAccepted_reqs().add(this.user.getId());
                this.user.getFriend_req_lists().remove((Object)i);
                u.addfollowings(this.user.getId());

            }
            if(input==2){
                u.getRejected_reqs().add(this.user.getId());
                this.user.getFriend_req_lists().remove((Object)i);
            }
            if(input==3){
                this.user.getFriend_req_lists().remove((Object)i);
            }

        }

    }
    public void check_sent_reqs_states(){
        for(int j:this.user.getRejected_reqs()){
            System.out.println(this.modelloader.get_user_by_id(j).getUsername()+"  has rejected your request");
        }
        for(int j:this.user.getAccepted_reqs()){
            System.out.println(this.modelloader.get_user_by_id(j).getUsername()+ " has accepted your request");
        }
        for(int j:this.user.getPending_req()){
            System.out.println(" your friend request to " +this.modelloader.get_user_by_id(j).getUsername()+ " is on pending ");
        }
        for(int j:this.user.getRemove_from_followings()){
            System.out.println(this.modelloader.get_user_by_id(j).getUsername()+ " removed you from his followers");
        }
        for(int j:this.user.getRemove_from_followers()){
            System.out.println(this.modelloader.get_user_by_id(j).getUsername()+ " removed you from his followings");
        }
        this.user.getRemove_from_followers().clear();
        this.user.getRemove_from_followings().clear();
        this.user.getAccepted_reqs().clear();
        this.user.getPending_req().clear();
        this.user.getRejected_reqs().clear();
    }
    public void initialize(){
        System.out.println("1. show sent requests state");
        System.out.println("2. show recieved requests");
        System.out.println("0. back");
        int j=inputLoop(0,2);
        while (j!=0){
            if(j==1){
                check_sent_reqs_states();
            }
            if(j==2){
                show_requests();
            }
            System.out.println("1. show sent requests state");
            System.out.println("2. show recieved requests");
            System.out.println("0. back");
             j=inputLoop(0,2);
        }
    }






    public static int inputLoop(int start, int end){
        Scanner scanner = new Scanner(System.in);
        while (true){
            try {
                int input = scanner.nextInt();
                if (start <= input && input <= end) {
                    return input;
                }
            } catch (Exception ignored){ }
            System.out.println("invalid command! try again.");
        }
    }


}
