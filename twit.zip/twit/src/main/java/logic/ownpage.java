package logic;

import com.sun.scenario.effect.impl.sw.sse.SSEBlend_SRC_OUTPeer;
import model.User;
import model.twitt;

import java.io.File;
import java.util.ArrayList;
import java.util.Scanner;

public class ownpage {
    User user;
    modelloader modelloader;
    public ownpage(User user,modelloader md){
        this.user=user;
        this.modelloader=md;

    }
    public void intialize(){

        System.out.println("choose what to do!");
        System.out.println("1. new tweet");
        System.out.println("2. show your own tweet");
        System.out.println("3. edit your page");
        System.out.println("4. lists of followers / followings / blacklist");
        System.out.println("5. info");
        System.out.println("6. notification");
        System.out.println("7. edit friends list");

        System.out.println("0. back");
        int i=inputLoop(0,7);
        while (i!=0){

            if  (i==1){
                twitt t=new twitt();
                File file=new File("out/db/tweets");
                System.out.println("write new tweet");
                Scanner scanner= new Scanner(System.in);
                String s=scanner.nextLine();
                t.setContent(s);
                t.setId(file.listFiles().length+1);
                t.setUserid(this.user.getId());
                t.setName(this.user.getFirstname());
                this.user.getTwitts().add(t.getId());
                this.modelloader.twitts.add(t);
                System.out.println("your tweet posted succesfully");
                System.out.println("size of list: "+this.user.getTwitts().size());

            }
            else if(i==2){
                for(int x=0;x<this.user.getTwitts().size();x++) {
                    twitt tt=this.modelloader.get_twitt_by_id(this.user.getTwitts().get(x));
                    System.out.println(tt.getContent());
                    System.out.println("###########");
                }
            }
            else if(i==3){
                ownprofile ownprofile=new ownprofile(this.modelloader,this.user);
                ownprofile.initialize();

            }
            else if(i==4) {
                System.out.println("1. show & edit  your followings");
                System.out.println("2. show & edit your followers");
                System.out.println("3. show & edit your blacklist");


                System.out.println("0. back");
                int j = inputLoop(0, 3);
                while (j != 0) {

                    if (j == 1) {
                        show_followings();
                        chatpage chatpage = new chatpage(this.modelloader, this.user);
                        User u1 = chatpage.getUser();

                        System.out.println("1. remove from followings");
                        System.out.println("0. back");
                        int u = inputLoop(0, 2);
                        if (u == 1) {
                            if (this.user.getFollowings().contains(u1.getId())) {
                                this.user.getFollowings().remove((Object) u1.getId());
                                u1.getRemove_from_followings().add(this.user.getId());
                                System.out.println("user removed from followings successfully");
                            } else {
                                System.out.println("user is not in your followings ");
                            }
                        }


                    }
                    if (j == 2) {
                        show_followers();
                        chatpage chatpage = new chatpage(this.modelloader, this.user);

                        User u1 = chatpage.getUser();
                        if (this.user.getFollowers().contains(u1.getId())) {
                            System.out.println("do you want to remove this user from followers?");
                            System.out.println("1. yes");
                            System.out.println("2. no");
                            System.out.println("0. back ");
                            int j1 = inputLoop(0, 2);
                            if (j1 == 1) {
                                this.user.getFollowers().remove((Object) u1.getId());
                                u1.getRemove_from_followers().add(this.user.getId());
                                System.out.println("user removed from followers.");
                            }


                        } else {
                            System.out.println("this you user does not follow you");
                        }
                    }

                    if (j == 3) {
                        show_blacklist();
                        chatpage chatpage = new chatpage(this.modelloader, this.user);
                        User u1 = chatpage.getUser();
                        System.out.println("1.  add to blacklist");
                        System.out.println("2.  remove from blacklist");
                        System.out.println("0.  back");
                        int u = inputLoop(0, 2);
                        if (u == 1) {
                            this.user.getBlacklist().add(u1.getId());
                            if (this.user.getFollowers().contains(u1.getId())) {
                                this.user.getFollowers().remove((Object) u1.getId());

                            }
                            if (this.user.getFollowings().contains(u1.getId())) {
                                this.user.getFollowings().remove((Object) u1.getId());
                            }
                            System.out.println("user added to blacklist successfully");
                        } else if (u == 2) {
                            if (this.user.getBlacklist().contains(u1.getId())) {
                                this.user.getBlacklist().remove((Object) u1.getId());
                                System.out.println("user successfully remove from blacklist");
                            }
                        }

                    }

                    System.out.println("1. show & edit  your followings");
                    System.out.println("2. show & edit your followers");
                    System.out.println("3. show & edit your blacklist");


                    System.out.println("0. back");
                    j = inputLoop(0, 3);


                }
            }
            else if(i==5){
                System.out.println(this.user.getFirstname()+ " : "+this.user.getLastname());
                System.out.println("username : "+this.user.getUsername());
                System.out.println("email: "+this.user.getEmail());
                System.out.println("phone num"+this.user.getPhonenum());

            }
            else if(i==6){
                notificationpage np=new notificationpage(this.modelloader,this.user);
                np.initialize();
            }
            else if(i==7){
                show_groups();
                System.out.println("1. add a group to friends");
                System.out.println("2. edit groups");
                System.out.println("0. back");
                int inp=inputLoop(0,2);
                while (inp!=0){
                    if(inp==1){
                        add_group();
                    }
                    else {
                        edit_groups();
                    }
                    System.out.println("1. add a group to friends");
                    System.out.println("2. edit groups");
                    System.out.println("0. back");
                    inp=inputLoop(0,2);
                }


            }
            System.out.println("choose what to do!");
            System.out.println("1. new tweet");
            System.out.println("2. show your own tweet");
            System.out.println("3. edit your page");
            System.out.println("4. lists of followers / followings / blacklist");
            System.out.println("5. info");
            System.out.println("6. notification");
            System.out.println("7. edit groups");

            System.out.println("0. back");
            modelsaver ms=new modelsaver(this.modelloader);
            ms.initialize();
            i=inputLoop(0,7);
        }
    }
    public static int inputLoop(int start, int end){
        Scanner scanner = new Scanner(System.in);
        while (true){
            try {
                int input = scanner.nextInt();
                if (start <= input && input <= end) {
                    return input;
                }
            } catch (Exception ignored){ }
            System.out.println("Invalid command! try again.");
        }
    }


    public void show_followers(){
        for(int i:this.user.getFollowers()){
                    User u=this.modelloader.get_user_by_id(i);
                    System.out.println(u.getUsername());
        }

    }
    public void show_followings(){
        for(int i:this.user.getFollowings()){
            User u=this.modelloader.get_user_by_id(i);
            System.out.println(u.getUsername());
        }

    }
    public void show_blacklist(){
        for(int i:this.user.getBlacklist()){
            User u=this.modelloader.get_user_by_id(i);
            System.out.println(u.getUsername());
        }

    }
    public void add_group(){
        System.out.println("choose a name for group");
        Scanner scanner= new Scanner(System.in);
        String name=scanner.nextLine();
        ArrayList<Integer> newgroup=new ArrayList<>();
        for(int j:this.user.getFollowings()){
            System.out.println(this.modelloader.get_user_by_id(j).getUsername());
            System.out.println("do you want to add this user in group?");
            System.out.println("1. yes");
            System.out.println("2. no");
            int o=inputLoop(1,2);
            if(o==1){
                newgroup.add(j);

            }
        }
        this.user.getGroups().put(name,newgroup);
    }
    public void edit_groups(){
        show_groups();
        System.out.println("choose a group");
        Scanner scanner=new Scanner(System.in);
        String name=scanner.nextLine();
        while (!is_name_valid(name)){
            System.out.println("enter a valid name");
            name=scanner.nextLine();
        }
        System.out.println("1. add a user");
        System.out.println("2. remove a user");
        System.out.println("0. back");
        int o=inputLoop(0,2);
        while (o!=0){
            if(o==1){
                System.out.println("write username");
                chatpage c=new chatpage(this.modelloader,this.user);
                User u=c.getUser();
                this.user.getGroups().get(name).add(u.getId());
                System.out.println("user added to group");

            }
            else {
                System.out.println("write username");
                chatpage c=new chatpage(this.modelloader,this.user);
                User u=c.getUser();
                if(!this.user.getGroups().get(name).contains(u.getId())){
                    this.user.getGroups().get(name).remove((Object)u.getId());
                    System.out.println("user removed from group");
                }
                else {
                    System.out.println("this user is not in list to remove ");
                }
            }
        }

    }
    public boolean is_name_valid(String name){
        for(String s:this.user.getGroups().keySet()){
            if(name.equals(s)){
                return true;
            }
        }
        return false;
    }
    public void show_groups(){
        for(String s:this.user.getGroups().keySet()){
            System.out.println(s+ "   :");

            for(int k:this.user.getGroups().get(s)){
                System.out.println(this.modelloader.get_user_by_id(k).getUsername());

            }

        }
    }

}
