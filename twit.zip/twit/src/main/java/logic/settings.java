package logic;

import java.io.*;
import java.util.Scanner;

import logger.logger;
import model.User;
import model.twitt;

public class settings {
    modelloader md;
    User user;
    public settings(modelloader modelloader,User user){
        this.md=modelloader;
        this.user=user;

    }


    public void changelastseenstate(){
        System.out.println("choose your last seen state");
        System.out.println("1. allusers");
        System.out.println("2. my followings");
        System.out.println("3. no body");
        System.out.println("0. back");

        int i=inputLoop(0,3);
        this.user.setLastseentype(i);
    }
    public void de_active_account(){
        System.out.println("de active your account");
        System.out.println("1. yes");
        System.out.println("2. no");
        int i=inputLoop(0,2);
        if(i==1){
            this.user.setIsactive(true);
        }
        if(i==2){
            this.user.setIsactive(false);
        }

    }
    public void changepassword(){
        Scanner sc=new Scanner(System.in);
        String password=sc.next();
        this.user.setPassword(password);

    }
    public void changeusermode(){
        System.out.println("choose your privacy mode");
        System.out.println("1. public");
        System.out.println("2. private");
        System.out.println("0. back");

        int i= inputLoop(0,2);
        this.user.setPrivacytype(i);

    }


    public void initialize(){
        modelsaver ms=new modelsaver(this.md);
        ms.initialize();
        logger log=new logger();
        log.info("user : "+this.user.getUsername()+" changed his/her profile datas");
        System.out.println("1. privacy settings");
        System.out.println("2. delect account");
        System.out.println("3. log out");
        System.out.println("0. back");
        int i = inputLoop(0,3);
        while (i!=0){
            if(i==1){
                privacy_settings();
            }
            else if(i==2){
                delete_account();

            }
            else if(i==3){
                log_out();
            }
            System.out.println("1. privacy settings");
            System.out.println("2. delect account");
            System.out.println("3. log out");
            System.out.println("0. back");
            i=inputLoop(0,3);

        }
    }

    public static int inputLoop(int start, int end){

        Scanner scanner = new Scanner(System.in);
        while (true){
            try {
                int input = scanner.nextInt();
                if (start <= input && input <= end) {
                    return input;
                }
            } catch (Exception ignored){ }
            System.out.println("Invalid command! try again.");
        }
    }
    public void privacy_settings(){
        System.out.println("1. change last seen type");
        System.out.println("2. change privacy type");
        System.out.println("3. change password");
        System.out.println("4. de active your account");
        int i = inputLoop(0,4);
        while (i!=0){
            if(i==1){
                changelastseenstate();
            }
            else if(i==2){
                changeusermode();
            }
            else if(i==3){
                changepassword();
            }
            else if(i==4){
                de_active_account();
            }
            System.out.println("1. change last seen type");
            System.out.println("2. change privacy type");
            System.out.println("3. change password");
            System.out.println("4. de active your account");
            i = inputLoop(0,4);
        }
    }
    public void delete_account(){
        logger logger= new logger();
        logger.info("user : "+ this.user.getUsername()+ " deleted account ");
        this.md.users.remove(this.user);
        int id=this.user.getId();
        String username=this.user.getUsername();
        //delete chat files of user
        File file=new File("out/db/chats");
        for(File file1:file.listFiles()){
            if(file1.getName().contains(username)){
                file1.delete();
            }
        }

        //delete tweets of user
        for(twitt t:this.md.getTwitts()){
            if(t.getUserid()==id){
                t.setUserid(-1);
            }
        }

        //delete directory of chats_notifs
        File file_dir=new File("out/db/user_chats_notif");
        for(File file1_dir:file_dir.listFiles()){
            if(file1_dir.getName().equals(username)){
                file1_dir.delete();
            }
        }
        //delete saved message
        File file_savedm=new File("out/db/savedmessages");
        for(File file_savedm1:file_savedm.listFiles()){
            if(file_savedm1.getName().equals(username)){
                file_savedm1.delete();
            }
        }
        //delete requests of user
        modelsaver ms=new modelsaver(this.md);
        ms.initialize();
        System.exit(0);
    }
    public void log_out(){
        logger logger= new logger();
        logger.info("user : "+ this.user.getUsername()+ " logged out ");
        System.exit(0);
    }

}
