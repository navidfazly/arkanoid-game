package logic;

import logger.logger;
import model.User;

import java.util.Scanner;

public class ownprofile {
    modelloader modelloader;
    User user;

    public ownprofile(modelloader modelloader, User user) {
        this.modelloader = modelloader;
        this.user = user;
    }
    public void initialize(){
        System.out.println("1. edit your name");
        System.out.println("2. edit your last name");
        System.out.println("3. edit your email");
        System.out.println("4. edit your phonenum");
        System.out.println("0. back ");
        logger log= new logger();
        log.info("user:  "+this.user.getUsername()+" changed his/her profile datas");

        int k=inputLoop(0,4);
        while (k!=0){

            if(k==1){
                System.out.println("enter a new name");
                Scanner scanner=new Scanner(System.in);
                String s=scanner.nextLine();
                this.user.setFirstname(s);
            }
            if(k==2){
                System.out.println("enter a new last name");
                Scanner scanner=new Scanner(System.in);
                String s=scanner.nextLine();
                this.user.setLastname(s);
            }
            if(k==3){
                System.out.println("enter a new email");
                Scanner scanner=new Scanner(System.in);
                String s=scanner.nextLine();
                while (checkifemailused(s)){
                    s=scanner.nextLine();
                }
                this.user.setEmail(s);
            }
            if (k==4){
                System.out.println("enter a new phone number");
                Scanner scanner=new Scanner(System.in);
                String s=scanner.nextLine();
                while (checkifphonenumused(s)){
                    s=scanner.nextLine();
                }
                this.user.setPhonenum(s);


            }
            System.out.println("1. edit your name");
            System.out.println("2. edit your last name");
            System.out.println("3. edit your email");
            System.out.println("4. edit your phonenum");
            System.out.println("0. back ");


             k=inputLoop(0,4);
        }

    }

    public static int inputLoop(int start, int end){
        Scanner scanner = new Scanner(System.in);
        while (true){
            try {
                int input = scanner.nextInt();
                if (start <= input && input <= end) {
                    return input;
                }
            } catch (Exception ignored){ }
            System.out.println("Invalid command! try again.");
        }
    }

    public boolean checkifemailused(String email){
        for(User user:modelloader.getUsers()){
            if(user.getEmail().equals(email)){
                return true;
            }
        }
        return false;

    }
    public boolean checkifphonenumused(String phonenum){
        for(User user:modelloader.getUsers()){
            if(user.getPhonenum().equals(phonenum)){
                return true;
            }
        }
        return false;

    }
}
