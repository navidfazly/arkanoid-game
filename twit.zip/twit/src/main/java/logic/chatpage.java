package logic;

import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;
import model.User;
import model.twitt;

public class chatpage {
    modelloader modelloader;
    User user;
    public chatpage(modelloader md,User user){
        this.modelloader= md;
        this.user=user;
    }
    // show notifications of chats
    public void show_notif_of_chats(){
        File file= new File("out/db/user_chats_notif");
        if(!file.exists()){
            try {
                file.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }




        int ind=0;
        for (File file1:file.listFiles()) {
            String[] usernames=new String[file1.listFiles().length];
            int[]  message_nums=new int[file1.listFiles().length];
            if(file1.getName().equals(this.user.getUsername())) {
                try {
                    for(File file2:file1.listFiles()){
                        Scanner sc=new Scanner(file2);
                        message_nums[ind]=sc.nextInt();
                        usernames[ind]=file2.getName();
                        ind++;

                    }
                    for(int i=0;i<file1.listFiles().length;i++){
                        for(int j=0;j<file1.listFiles().length-1;j++){
                            if(message_nums[j]>message_nums[j+1]){
                                int x=message_nums[j+1];
                                message_nums[j+1]=message_nums[j];
                                message_nums[j]=x;
                                String s=usernames[j+1];
                                usernames[j+1]=usernames[j];
                                usernames[j]=s;
                            }
                        }
                    }
                    for(int i=0;i<file1.listFiles().length;i++){
                        System.out.println(usernames[file1.listFiles().length-1-i]+" : "+ message_nums[file1.listFiles().length-1-i]);
                    }

                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }

            }



        }


    }

    // returns the user with given username
    public User getUser(){
        System.out.println("write the username you want");
        Scanner scanner=new Scanner(System.in);
        String username=scanner.nextLine();
        while (modelloader.get_user_by_username(username)==null || username.equals("0")){
            System.out.println("invalid user name");
            System.out.println("write the username you want or 0. back");
             scanner=new Scanner(System.in);
             username=scanner.nextLine();

        }
        return modelloader.get_user_by_username(username);


    }
    //send message to other users
    public void sendmessage(User user2)  {

        System.out.println("write  your message");
        Scanner scanner =new Scanner(System.in);
        String content=scanner.nextLine();


        String path1="out/db/chats/"+this.user.getUsername()+"_"+user2.getUsername();
        String path2="out/db/chats/"+user2.getUsername()+"_"+this.user.getUsername();
        File file1=new File(path1);
        File file2=new File(path2);
        PrintStream printStream = null;

        if(file1.exists()){
            try {
                printStream=new PrintStream(new FileOutputStream(file1,true));
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }

        }
        else if(file2.exists()){
            try {
                printStream=new PrintStream(new FileOutputStream(file2,true));
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }
        else {

            System.out.println("111");
            try {
                file1.createNewFile();
                printStream=new PrintStream(new FileOutputStream(file1,true));
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            System.out.println("222");
        }
        printStream.println (this.user.getId());
        printStream.println(content);
        printStream.println("*************");
        printStream.flush();
        printStream.close();
        File file3= new File("out/db/user_chats_notif/"+user2.getUsername());
        int flag=0;
        if(!file3.exists()) {

            file3.mkdirs();

            flag = 1;



        }
        else {
            try {
                File file4=new File("out/db/user_chats_notif/"+user2.getUsername()+"/"+this.user.getUsername());
                if(!file4.exists()){
                    try {
                        file4.createNewFile();
                        PrintStream printStream1=new PrintStream(new FileOutputStream(file4,false));
                        printStream1.println(1);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                else {
                    Scanner scanner1= new Scanner(file4);
                    int i= scanner1.nextInt();
                    PrintStream printStream1=new PrintStream(new FileOutputStream(file4,false));
                    printStream1.println(i+1);
                }


            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }
        if(flag==1){
            File file4=new File("out/db/user_chats_notif/"+user2.getUsername()+"/"+this.user.getUsername());
            if(!file4.exists()){
                try {
                    file4.createNewFile();
                } catch (IOException e) {
                    e.printStackTrace();
                }

            }

            try {
                    PrintStream printStream1 = new PrintStream(new FileOutputStream(file4,false));
                printStream1.println(1);
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }

        }




    }

    // load chats with users
    public void loadchats(User user2) throws FileNotFoundException {


        String path1="out/db/chats/"+this.user.getUsername()+"_"+user2.getUsername();
        String path2="out/db/chats/"+user2.getUsername()+"_"+this.user.getUsername();
        File file1=new File(path1);
        File file2=new File(path2);
        if(file1.exists()){
            Scanner scanner=new Scanner(file1);
            ArrayList<String> messages=new ArrayList<>();
            ArrayList<Integer> idS=new ArrayList<>();
            while (scanner.hasNext()){
                int id=scanner.nextInt();
                String content=scanner.next();
                scanner.next();
                idS.add(id);
                messages.add(content);

            }
            for(int i=0;i<=messages.size()-1;i++){

                System.out.println(modelloader.get_user_by_id(idS.get(i)).getFirstname()+" : "+messages.get(i));
            }
            File file3= new File("out/db/user_chats_notif/"+this.user.getUsername());
            if(!file3.exists()){
                file3.mkdirs();

            }
            else {
                File file4=new File("out/db/user_chats_notif/"+this.user.getUsername()+"/"+user2.getUsername());
                if(!file4.exists()){

                }
                else{
                    PrintStream printStream = new PrintStream(new FileOutputStream(file4, false));
                    printStream.println(0);
                }

            }



        }
        else if(file2.exists()){
            Scanner scanner=new Scanner(file2);

            ArrayList<String> messages=new ArrayList<>();
            ArrayList<Integer> idS=new ArrayList<>();
            while (scanner.hasNext()){
                int id=scanner.nextInt();
                String content=scanner.next();
                scanner.next();
                idS.add(id);
                messages.add(content);

            }
            for(int i=messages.size()-1;i>=0;i--){

                System.out.println(modelloader.get_user_by_id(idS.get(i)).getFirstname()+" : "+messages.get(i));
            }
            File file3= new File("out/db/user_chats_notif/"+this.user.getUsername());
            if(!file3.exists()){
                file3.mkdirs();

            }
            else {
                File file4=new File("out/db/user_chats_notif/"+this.user.getUsername()+"/"+user2.getUsername());
                if(!file4.exists()){

                }
                else{
                    PrintStream printStream = new PrintStream(new FileOutputStream(file4, false));
                    printStream.println(0);
                }

            }
        }
        else{
            System.out.println("there is no chat to show");
        }

    }


    public void initialize(){
        modelsaver ms=new modelsaver(this.modelloader);
        ms.initialize();
        show_notif_of_chats();

        System.out.println("1. write new message to 1 user");
        System.out.println("2. show previous chats");
        System.out.println("3. write new message to groups");
        System.out.println("4. send message to all users");
        System.out.println("5. show saved messages");
        System.out.println("6. write message in saved message");
        int i=inputLoop(0,6);
        while (i!=0){
            if(i==1){
                User user1=getUser();
                while (!is_valid_chat(this.user,user1)){
                    System.out.println("you cant send message to this user");
                    user1=getUser();
                }
                sendmessage(user1);
            }
            if(i==2){
                try {
                    User user1=getUser();
                    while (!is_valid_chat(this.user,user1) ){
                        System.out.println("you cant send message to this user");
                        user1=getUser();
                    }
                    loadchats(user1);
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }
            }
            if(i==3){
                sendall();

            }
            if(i==4){
                System.out.println("write your message");
                Scanner scanner =new Scanner(System.in);
                String content=scanner.nextLine();
                for(User u:this.modelloader.getUsers()){
                    if(is_valid_chat(u,this.user)&& u!=this.user){
                        send_contented_message(u,content);
                    }
                }
            }
            if(i==5){
                show_saved();
            }
            if(i==6){
                write_saved();
            }
            System.out.println("1. write new message");
            System.out.println("2. show previous chats");
            System.out.println("3. group message");
            System.out.println("4. all user message");
            System.out.println("5. show saved messages");
            System.out.println("6. write message in saved message");
            System.out.println("0. back");

            i=inputLoop(0,6);
        }

    }


    public void forwardmessage(User user2 , twitt tweet) throws IOException {




        if(this.user==null){
            System.out.println("fuck1");
        }
        if(user2== null){
            System.out.println("fuck2");
        }

        String path1="out/db/chats/"+this.user.getUsername()+"_"+user2.getUsername();
        String path2="out/db/chats/"+user2.getUsername()+"_"+this.user.getUsername();
        File file1=new File(path1);
        File file2=new File(path2);
        PrintStream printStream;

        if(file1.exists()){
            printStream=new PrintStream(new FileOutputStream(file1,true));

        }
        else if(file2.exists()){
            printStream=new PrintStream(new FileOutputStream(file2,true));
        }
        else {
            file1.createNewFile();
            System.out.println("111");
            printStream=new PrintStream(new FileOutputStream(file1,true));
            System.out.println("222");
        }
        printStream.println (this.user.getId());
        printStream.println(tweet.getContent());
        printStream.println("*************");
        printStream.flush();
        printStream.close();

    }
    public boolean is_valid_chat(User user1, User user2){
        if(user1.getFollowings().contains(user2.getId()) || user2.getFollowings().contains(user1.getId())){
            return true;
        }

        return false;
    }

    public static int inputLoop(int start, int end){
        Scanner scanner = new Scanner(System.in);
        while (true){
            try {
                int input = scanner.nextInt();
                if (start <= input && input <= end) {
                    return input;
                }
            } catch (Exception ignored){ }
            System.out.println("Invalid command! try again.");
        }
    }

    public void sendall(){
        System.out.println("write your message");
        Scanner scanner =new Scanner(System.in);
        String content=scanner.nextLine();
        HashMap <String,ArrayList<Integer>> mapp= this.user.getGroups();
        for(String s:mapp.keySet()){
            System.out.println(s+ " : ");
            for(int i:mapp.get(s)){
                System.out.println(this.modelloader.get_user_by_id(i).getUsername());
            }
            System.out.println("####");

        }
        ownpage op=new ownpage(this.user,this.modelloader);
        op.show_groups();
        ArrayList<String> Names=new ArrayList<>();
        System.out.println("1. enter new group name");
        System.out.println("2. send");
        int u=inputLoop(1,2);
        while (u==1){
            System.out.println("1. enter new group name");
            System.out.println("2. send");
            u=inputLoop(1,2);
            if(u==1){
                String s1=scanner.next();
                while (!check_group_name(mapp,s1)){
                    s1=scanner.next();
                    System.out.println("wrong name");
                }
                Names.add(s1);
            }
        }


        for(String name:Names) {

            for (String s : mapp.keySet()) {
                if (s.equals(name)) {
                    for (int i : mapp.get(s)) {
                        send_contented_message(this.modelloader.get_user_by_id(i), content);
                    }
                }
            }
        }
    }
    public void forwardall(String content){
        Scanner scanner=new Scanner(System.in);
        HashMap <String,ArrayList<Integer>> mapp= this.user.getGroups();
        for(String s:mapp.keySet()){
            System.out.println(s+ " : ");
            for(int i:mapp.get(s)){
                System.out.println(this.modelloader.get_user_by_id(i).getUsername());
            }
            System.out.println("####");

        }
        ownpage op=new ownpage(this.user,this.modelloader);
        op.show_groups();
        ArrayList<String> Names=new ArrayList<>();
        System.out.println("1. enter new group name");
        System.out.println("2. send");
        int u=inputLoop(1,2);
        while (u==1){
            System.out.println("1. enter new group name");
            System.out.println("2. send");
            u=inputLoop(1,2);
            if(u==1){
                String s1=scanner.next();
                while (!check_group_name(mapp,s1)){
                    s1=scanner.next();
                    System.out.println("wrong name");
                }
                Names.add(s1);
            }
        }


        for(String name:Names) {

            for (String s : mapp.keySet()) {
                if (s.equals(name)) {
                    for (int i : mapp.get(s)) {
                        send_contented_message(this.modelloader.get_user_by_id(i), content);
                    }
                }
            }
        }
    }
    public void send_contented_message(User user2,String content){




            if(this.user==null){
                System.out.println("fuck1");
            }
            if(user2== null){
                System.out.println("fuck2");
            }

            String path1="out/db/chats/"+this.user.getUsername()+"_"+user2.getUsername();
            String path2="out/db/chats/"+user2.getUsername()+"_"+this.user.getUsername();
            File file1=new File(path1);
            File file2=new File(path2);
            PrintStream printStream = null;

            if(file1.exists()){
                try {
                    printStream=new PrintStream(new FileOutputStream(file1,true));
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }

            }
            else if(file2.exists()){
                try {
                    printStream=new PrintStream(new FileOutputStream(file2,true));
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }
            }
            else {

                System.out.println("111");
                try {
                    file1.createNewFile();
                    printStream=new PrintStream(new FileOutputStream(file1,true));
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                System.out.println("222");
            }
            printStream.println (this.user.getId());
            printStream.println(content);
            printStream.println("*************");
            printStream.flush();
            printStream.close();
            File file3= new File("out/db/user_chats_notif/"+user2.getUsername()+"/"+this.user.getUsername());
            if(!file3.exists()){
                try {
                    file3.createNewFile();

                    PrintStream printStream1=new PrintStream(new FileOutputStream(file3,false));
                    printStream1.println(1);
                } catch (IOException e) {
                    e.printStackTrace();
                }

            }
            else {
                try {
                    Scanner scanner1= new Scanner(file3);
                    int i= scanner1.nextInt();
                    PrintStream printStream1=new PrintStream(new FileOutputStream(file3,false));
                    printStream1.println(i+1);

                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }
            }




        }
        public boolean check_group_name(HashMap<String,ArrayList<Integer>> mapp,String s1){
            for(String s:mapp.keySet()) {
                if (s.equals(s1)) {
                    return true;
                }
            }
            return false;
        }
        public void show_saved(){
            File file=new File("out/db/savedmessages/"+this.user.getUsername());
            if(!file.exists()){
                try {
                    file.createNewFile();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            try {
                Scanner scanner= new Scanner(file);
                while (scanner.hasNext()){
                    System.out.println(scanner.nextLine());
                    scanner.nextLine();
                    System.out.println("*****");
                }
                scanner.close();
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }


        }
        public void write_saved(){
            File file=new File("out/db/savedmessages/"+this.user.getUsername());
            if(!file.exists()){
                try {
                    file.createNewFile();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            try {
                PrintStream printStream= new PrintStream(new FileOutputStream(file,true));
                Scanner scanner= new Scanner(System.in);
                System.out.println("wirte your message!");
                String s=scanner.nextLine();
                printStream.println(s);
                printStream.flush();
                printStream.close();
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }
    }


