package logic;
import com.google.gson.Gson;
import logger.logger;
import model.User;

import java.util.Scanner;
import java.io.*;


public class loginpage {
    modelloader md;
    User user;
    public loginpage(modelloader modelloader) throws FileNotFoundException {

        this.md=modelloader;
    }

    public User sign_up() throws FileNotFoundException {
        File file=new File("out/userdirectory/allusersdata.txt");

        PrintStream printStream = new PrintStream(new FileOutputStream(file,true));


        System.out.println("enter your name");
        Scanner scanner=new Scanner(System.in);
        String name=scanner.next();
        System.out.println("enter your lastname");
        String lastname=scanner.next();
        System.out.println("enter your username");

        String username=scanner.next();
        while (checkifusernameused(username)){
            System.out.println("user name is already occupied");
            username=scanner.next();
        }

        System.out.println("enter your password");
        String password=scanner.next();
        System.out.println("enter your email");

        String email=scanner.next();
        while (checkifemailused(email)){
            System.out.println("email is already occupied");
            email=scanner.next();
        }

        System.out.println("enter your phonenum");
        String phonenum=scanner.next();
        while (checkifphonenumused(phonenum)){
            System.out.println("phonenum  is already occupied");
            phonenum=scanner.next();
        }


        System.out.println("enter your bio");
        String bio=scanner.next();
        System.out.println("enter your birthdate");
        String birthdate=scanner.next();

        int id=md.get_max_id();
        User user = new User(name,lastname,username,password,email,phonenum,bio,id);
        user.setBirthdate(birthdate);
        logger logger= new logger();
        logger.info("user : "+user.getUsername() + " signed up ");
        md.users.add(user);
        Gson gg=new Gson();
        printStream.println(gg.toJson(user));


        printStream.flush();
        printStream.close();

        return user;
    }
    public User loginuser(){
        Scanner sc=new Scanner(System.in);
        System.out.println("user name ro bede");
        String username=sc.next();
        System.out.println("password ro bede");
        String password=sc.next();

        while (!loginusermet(username,password)){
            System.out.println("username or pass word is wrong");
            System.out.println("user name ro bede");
             username=sc.next();
            System.out.println("password ro bede");
             password=sc.next();
        }
        for(User user:md.getUsers()){
            if(user.getUsername().equals(username)){
                if(user.getPassword().equals(password)){
                    System.out.println("successfully entered");
                    logger log=new logger();
                    log.info("user : "+user.getUsername()+ " enterd ");
                    return user;
                }

            }
        }

    return null;
    }

    public boolean checkifusernameused(String username){
        for(User user:md.getUsers()){
            if(user.getUsername().equals(username)){
                return true;
            }
        }
        return false;
    }
    public boolean checkifemailused(String email){
        for(User user:md.getUsers()){
            if(user.getEmail().equals(email)){
                return true;
            }
        }
        return false;

    }
    public boolean checkifphonenumused(String phonenum){
        for(User user:md.getUsers()){
            if(user.getPhonenum().equals(phonenum)){
                return true;
            }
        }
        return false;

    }
    public boolean loginusermet(String username,String password){

        for(User user:md.getUsers()){

            if(user.getUsername().equals(username)){

                if(user.getPassword().equals(password)){
                    return true;
                }
                else {
                    return false;
                }
            }
        }
        return false;
    }
    public int firstquestions(){
        Scanner sc=new Scanner(System.in);
        System.out.println("welcome to our messenger");
        System.out.println("do you have an account?");
        System.out.println("1.yes");
        System.out.println("2.no");
        int i=sc.nextInt();
        return i;

    }
    public User loginpagefinal() throws FileNotFoundException {
        int firsques=firstquestions();
        while (firsques!=1 && firsques!=2){
            firsques=firstquestions();

        }
        if(firsques==1){
            return loginuser();
        }
        else {
            return sign_up();
        }
    }

}
