package logic;

import model.User;
import model.twitt;

import java.util.ArrayList;
import java.util.Scanner;

public class explore {
    modelloader modelloader;
    User user;
    public explore(modelloader md,User user1){
        this.modelloader=md;
        this.user=user1;
    }
    public void show_options(){
        modelsaver ms=new modelsaver(this.modelloader);
        ms.initialize();
        System.out.println("1. search user by username");
        System.out.println("2. show trend tweets");
        System.out.println("0. back");
        int i=inputLoop(0,2);
        while (i!=0){
            if(i==1){
                chatpage chatpage=new chatpage(this.modelloader,this.user);
                User u1= chatpage.getUser();
                if(u1.getIsactive()) {
                    otherprofile otherprofile = new otherprofile(this.modelloader, this.user);
                    otherprofile.show_datas(u1);
                }
                else {
                    System.out.println("account is de active");
                }
            }
            else{
                timeline timeline=new timeline(this.user,this.modelloader);
                ArrayList<twitt> reverse_list=new ArrayList<>();
                for(int x=0;x<this.modelloader.twitts.size();x++){
                    User u=this.modelloader.get_user_by_id(this.modelloader.twitts.get(this.modelloader.twitts.size()-1-x).getUserid());
                    if(u!=null && u.getIsactive()) {
                        reverse_list.add(this.modelloader.twitts.get(this.modelloader.twitts.size() - 1 - x));
                    }
                }
                timeline.tweetoptions(reverse_list,0);

            }
            System.out.println("1. search user by username");
            System.out.println("2. show trend tweets");
            System.out.println("0. back");
            i=inputLoop(0,2);
        }


    }
    public static int inputLoop(int start, int end){
        Scanner scanner = new Scanner(System.in);
        while (true){
            try {
                int input = scanner.nextInt();
                if (start <= input && input <= end) {
                    return input;
                }
            } catch (Exception ignored){ }
            System.out.println("Invalid command! try again.");
        }
    }
}
