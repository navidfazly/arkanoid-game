package logic;

import com.google.gson.Gson;
import logic.modelloader;

import logic.notificationpage;
import model.User;
import model.notification;
import model.twitt;

import java.io.*;

public class modelsaver {
    modelloader modelloader;
    public modelsaver(modelloader md){
        this.modelloader=md;

    }
    public void set_twiits_in_directory(){
        Gson gg= new Gson();

        for(twitt tweet:this.modelloader.getTwitts()) {

            File file = new File("out/db/tweets/" + String.valueOf(tweet.getId()));
            if (tweet.getUserid() != -1) {
                if (!file.exists()) {
                    try {
                        file.createNewFile();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }

                try {
                    PrintStream printStream = new PrintStream(new FileOutputStream(file, false));

                    printStream.println(gg.toJson(tweet));
                    printStream.flush();
                    printStream.close();


                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }
            }
        }
    }
    

    public void set_users_in_file(){
        Gson gg=new Gson();
        File file=new File("out/userdirectory/allusersdata.txt");

        try {
            PrintStream printStream = new PrintStream(new FileOutputStream(file,false));
            for(User user:this.modelloader.getUsers()){
                printStream.println(gg.toJson(user));
            }
            printStream.flush();
            printStream.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }
    public void initialize(){

        set_twiits_in_directory();
        set_users_in_file();
    }
}
