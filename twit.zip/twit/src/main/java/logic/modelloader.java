package logic;
import com.google.gson.Gson;
import model.User;
import model.notification;
import model.twitt;

import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

public class modelloader {
    private File usersdirectory;
    private String path="out/userdirectory/allusersdata.txt";
    int i;
    ArrayList<User> users= new ArrayList<>();
    ArrayList<twitt> twitts=new ArrayList<>();
    ArrayList<notification> notifications=new ArrayList<>();




    public ArrayList<notification> getNotifications() {
        return notifications;
    }

    public ArrayList<twitt> getTwitts() {
        return twitts;
    }

    public void setTwitts(ArrayList<twitt> twitts) {
        this.twitts = twitts;
    }

    public modelloader()  {
        initialize();
    }
    // read users from allusersdata and make users array to initilize
    public void readusersfromfile() throws FileNotFoundException {
        File file=new File("out/userdirectory/allusersdata.txt");
        Gson gson=new Gson();
        Scanner sc=new Scanner(file);
        while (sc.hasNext()){
            User user= gson.fromJson(sc.nextLine(),User.class);
            this.users.add(user);

        }


    }

    public ArrayList<User> getUsers() {
        return users;
    }





    public User get_user_by_id(int id){
        for(User user:users){
            if(user.getId()==id){
                return user;
            }
        }
        return null;
    }


    public User get_user_by_username(String username){
        for(User user:users){
            if(user.getUsername().equals(username)){
                return user;
            }
        }
        return null;
    }




    // loading tweets from directory


    public void load_tweets(){
        Gson gg = new Gson();

        File file=new File("out/db/tweets");
        for (File file1: file.listFiles() ) {
            try {
                Scanner scanner =new Scanner(file1);
                while (scanner.hasNext()){
                    twitt tweet = gg.fromJson(scanner.nextLine(),twitt.class);
                    twitts.add(tweet);
                }
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }


        }

    }


    public void sort_tweets_by_like(){
        for(int i=0;i<twitts.size();i++){
            for(int j=0;j<twitts.size()-1;j++){
                if(twitts.get(j).getLikenum()>twitts.get(j+1).getLikenum()){
                    twitt t=twitts.get(j+1);
                    twitts.set(j+1,twitts.get(j));
                    twitts.set(j,t);
                }
            }
        }
    }
    public twitt get_twitt_by_id(int id){
        for(twitt t:twitts){
            if(t.getId()==id){
                return t;
            }
        }
        return null;
    }
    public void initialize(){
        try {
            readusersfromfile();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        load_tweets();

        sort_tweets_by_like();
    }
    public int get_max_id(){
        int s=0;
        for(User u:this.getUsers()){
            if(u.getId()>s){
                s=u.getId();
            }
        }
        return s+1;
    }
}
