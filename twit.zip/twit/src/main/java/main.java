import com.google.gson.Gson;
import com.google.gson.Gson;
import logic.loginpage;
import model.twitt;

import java.io.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.HashMap;
import java.util.Map;
import java.util.*;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;


public class main {


        public static void main(String[] args) throws IOException {
            cli cli=new cli();
        }
    }

