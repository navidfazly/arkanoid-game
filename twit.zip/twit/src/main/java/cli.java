import logic.*;
import logic.modelloader;

import java.io.FileNotFoundException;
import java.io.IOException;

public class cli {
    modelloader modelloader = new modelloader();

    public cli() throws IOException {
        loginpage lgpage= new loginpage(modelloader);
        mainpage mainpage= new mainpage(lgpage.loginpagefinal(),modelloader);
        mainpage.intialize();

    }
}
