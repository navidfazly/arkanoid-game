package logger;

import java.io.*;
import java.time.LocalDate;
import java.time.LocalTime;

public class logger {

    public void write_in_file(String content){
        File file=new File("out/log_properties/log.txt");
        if(!file.exists()){
            try {
                file.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        try {
            PrintStream printStream= new PrintStream(new FileOutputStream(file,true));
            printStream.println(content);
            printStream.println("-------------------------------------------------------------");
            printStream.flush();
            printStream.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }
    public void info(String content){
        LocalDate ld=LocalDate.now();
        LocalTime lt=LocalTime.now();
        String time=ld.toString()+"    "+lt.getHour()+" : "+lt.getMinute()+" : "+ lt.getSecond();
        String finall_content=content+ " at "+ time;
        write_in_file(finall_content);
    }
}
