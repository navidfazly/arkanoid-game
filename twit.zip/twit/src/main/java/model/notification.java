package model;

public class notification {

    String content;
    int userid;
    int idn;
    public notification(){

    }

    public int getUserid() {
        return userid;
    }

    public void setUserid(int userid) {
        this.userid = userid;
    }

    public int getIdn() {
        return idn;
    }

    public void setIdn(int idn) {
        this.idn = idn;
    }

    public notification(int id){
        this.idn=id;
    }






    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
    public void reqnot(User user1){
        this.setContent(user1.getUsername()+" " + " send a friend request to you ");

    }
    public void likenot(User user1){
        this.setContent(user1.getUsername()+" " + " liked your post ");

    }
    public void commentnot(User user1){
        this.setContent(user1.getUsername()+" " + " commented a view on your post  ");
    }

}
