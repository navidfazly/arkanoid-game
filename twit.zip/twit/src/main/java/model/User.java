package model;


import java.util.ArrayList;
import java.util.HashMap;

public class User {
    private String firstname;
    private String lastname;
    private String username;
    private String email;
    private String phonenum;
    private String birthdate;
    private String password;
    private String bio;
    private int privacytype=1;
    String date;
    String time;
    boolean isactive=true;
    ArrayList<Integer > remove_from_followers= new ArrayList<>();
    ArrayList<Integer> remove_from_followings= new ArrayList<>();

    public ArrayList<Integer> getRemove_from_followers() {
        return remove_from_followers;
    }

    public void setRemove_from_followers(ArrayList<Integer> remove_from_followers) {
        this.remove_from_followers = remove_from_followers;
    }

    public ArrayList<Integer> getRemove_from_followings() {
        return remove_from_followings;
    }

    public void setRemove_from_followings(ArrayList<Integer> remove_from_followings) {
        this.remove_from_followings = remove_from_followings;
    }

    public boolean getIsactive() {
        return isactive;
    }

    public void setIsactive(boolean isactive) {
        this.isactive = isactive;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    private int lastseentype=1;
    int id;
    ArrayList<Integer> followers=new ArrayList<>();

    ArrayList<Integer> followings=new ArrayList<>();

    ArrayList<Integer> notificiations=new ArrayList<>();

    ArrayList<Integer> savedtwitts=new ArrayList<>();

    ArrayList<Integer> twitts=new ArrayList<>();

    ArrayList<Integer> whichliked=new ArrayList<>();

    ArrayList<Integer> friend_req_lists=new ArrayList<>();

    HashMap<String,ArrayList<Integer>> groups = new HashMap<String, ArrayList<Integer>>();
    ArrayList<Integer> blacklist=new ArrayList<>();
    ArrayList<Integer > pending_req=new ArrayList<>();
    ArrayList<Integer> accepted_reqs=new ArrayList<>();
    ArrayList<Integer> rejected_reqs=new ArrayList<>();

    public void add_whichliked(int i){
        whichliked.add(i);
    }

    public void setId(int id) {
        this.id = id;
    }










    public int getLastseentype() {
        return lastseentype;
    }

    public void setLastseentype(int lastseentype) {
        this.lastseentype = lastseentype;
    }














    public ArrayList<Integer> getFriend_req_lists() {
        return friend_req_lists;
    }

    public void setFriend_req_lists(ArrayList<Integer> friend_req_lists) {
        this.friend_req_lists = friend_req_lists;
    }

    public int getPrivacytype() {
        return privacytype;
    }

    public void setPrivacytype(int privacytype) {
        this.privacytype = privacytype;
    }









    public User(String firstname, String lastname, String username, String password, String email, String phonenum, String bio,int id) {

        this.firstname = firstname;
        this.lastname = lastname;
        this.username = username;
        this.email = email;
        this.phonenum = phonenum;
        this.password = password;
        this.bio = bio;
        this.id=id;
    }









    public void addfollower(int i ){
        followers.add(i );
    }
    public void addfollowings(int i){
        followings.add(i);
    }



    public HashMap<String, ArrayList<Integer>> getGroups() {
        return groups;
    }

    public void setinblacklist(int i){
        blacklist.add(i);
    }

    public void removefromblacklist(int x){
        if(blacklist.contains(x)){
            blacklist.remove(x);
        }
    }
    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhonenum() {
        return phonenum;
    }

    public void setPhonenum(String phonenum) {
        this.phonenum = phonenum;
    }

    public String getBirthdate() {
        return birthdate;
    }

    public void setBirthdate(String birthdate) {
        this.birthdate = birthdate;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getBio() {
        return bio;
    }

    public void setBio(String bio) {
        this.bio = bio;
    }


    public int getId() {
        return id;
    }

    public ArrayList<Integer> getFollowers() {
        return followers;
    }

    public ArrayList<Integer> getFollowings() {
        return followings;
    }

    public ArrayList<Integer> getNotificiations() {
        return notificiations;
    }

    public ArrayList<Integer> getSavedtwitts() {
        return savedtwitts;
    }

    public ArrayList<Integer> getTwitts() {
        return twitts;
    }



    public ArrayList<Integer> getWhichliked() {
        return whichliked;
    }



    public ArrayList<Integer> getBlacklist() {
        return blacklist;
    }

    public boolean isIsactive() {
        return isactive;
    }

    public void setFollowers(ArrayList<Integer> followers) {
        this.followers = followers;
    }

    public void setFollowings(ArrayList<Integer> followings) {
        this.followings = followings;
    }

    public void setNotificiations(ArrayList<Integer> notificiations) {
        this.notificiations = notificiations;
    }

    public void setSavedtwitts(ArrayList<Integer> savedtwitts) {
        this.savedtwitts = savedtwitts;
    }

    public void setTwitts(ArrayList<Integer> twitts) {
        this.twitts = twitts;
    }

    public void setWhichliked(ArrayList<Integer> whichliked) {
        this.whichliked = whichliked;
    }

    public void setGroups(HashMap<String, ArrayList<Integer>> groups) {
        this.groups = groups;
    }

    public void setBlacklist(ArrayList<Integer> blacklist) {
        this.blacklist = blacklist;
    }

    public ArrayList<Integer> getPending_req() {
        return pending_req;
    }

    public void setPending_req(ArrayList<Integer> pending_req) {
        this.pending_req = pending_req;
    }

    public ArrayList<Integer> getAccepted_reqs() {
        return accepted_reqs;
    }

    public void setAccepted_reqs(ArrayList<Integer> accepted_reqs) {
        this.accepted_reqs = accepted_reqs;
    }

    public ArrayList<Integer> getRejected_reqs() {
        return rejected_reqs;
    }

    public void setRejected_reqs(ArrayList<Integer> rejected_reqs) {
        this.rejected_reqs = rejected_reqs;
    }
}

