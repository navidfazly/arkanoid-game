package model;

import java.time.LocalTime;
import java.util.ArrayList;

public class twitt {

    ArrayList<Integer> commentsid =new ArrayList<>();
    String content;
    int likenum;
    int id ;
    String name;
    boolean isactive;
    int userid;
    boolean iscomment;
    LocalTime localTime;
    public ArrayList<Integer> getCommentsids() {
        return commentsid;
    }

    public void setCommentsids(ArrayList<Integer> commentsids) {
        this.commentsid = commentsids;
    }

    public boolean isIsactive() {
        return isactive;
    }

    public void setIsactive(boolean isactive) {
        this.isactive = isactive;
    }

    public boolean isIscomment() {
        return iscomment;
    }

    public void setIscomment(boolean iscomment) {
        this.iscomment = iscomment;
    }


    public int getUserid() {
        return userid;
    }
    public void setUserid(int userid) {
        this.userid = userid;
    }
    public twitt(int id){
        this.id=id;

    }

    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


    public LocalTime getLocalTime() {
        return localTime;
    }

    public void setLocalTime(LocalTime localTime) {
        this.localTime = localTime;
    }
    public twitt() {

    }

    public void addcommentid(twitt t){
        this.commentsid.add(t.getId());
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public int getLikenum() {
        return likenum;
    }

    public void setLikenum(int likenum) {
        this.likenum = likenum;
    }


}
