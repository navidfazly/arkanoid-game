package model;

public class like {

    User user;
    twitt twitt;


}
