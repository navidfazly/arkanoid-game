package boxes;

public class glaasbox extends box {

}
