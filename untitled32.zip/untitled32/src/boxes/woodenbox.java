package boxes;

public class woodenbox extends box {
    int type=4;
    int health=2;
}
