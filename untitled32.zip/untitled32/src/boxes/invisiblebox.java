package boxes;

public class invisiblebox extends box {
    int type=3;
}
