package boxes;

public class prizebox extends box{

}
