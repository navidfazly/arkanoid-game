package boxes;

public class flasherbox extends box {


    public void feature(){


    }
}
