package modelsls;

import balls.ball;
import boxes.box;
import controller.ifcontroller;
import model.models;
import prizez.prize;

import java.io.*;

public class modelsaver {


    models models;
    ifcontroller ifc;

    public modelsaver(models md ,ifcontroller ifcontroller){
        this.ifc=ifcontroller;
        this.models=md;
    }
    public void save_model(String gamename){
        File file =new File("database/savedgames/"+this.models.getCurrentplayer().getName());
        if(!file.exists()) {
            file.mkdirs();

        }
        file= new File("database/savedgames/"+this.models.getCurrentplayer().getName()+"/"+gamename);
        if(!file.exists()){
            try {
                file.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        try {
            PrintStream printStream = new PrintStream(new FileOutputStream(file,false));
            printStream.println("boxesnumber: ");
            printStream.println(this.models.getBoxes().size());
            printStream.println("boxes: ");
            for(box b:this.models.getBoxes()){
                printStream.println(b.getType());
                printStream.println(b.getPrize());
                printStream.println(b.getHealth());
                printStream.println(b.getX());
                printStream.println(b.getY());




            }
            printStream.println();
            printStream.println("ballsnumber:");
            printStream.println(this.models.getBalls().size());
            printStream.println("balls:");
            for(ball b: this.models.getBalls()){
                printStream.println(b.getX());
                printStream.println(b.getY());
                printStream.println(b.getXvelocity());
                printStream.println(b.getYvelocity());
                printStream.println(b.getR());
                printStream.println(b.isFireball());
            }
            printStream.println();
            printStream.println("paddel:");
            printStream.println(this.models.getPaddel().getX());
            printStream.println(this.models.getPaddel().getY());
            printStream.println(this.models.getPaddel().getHeight());
            printStream.println(this.models.getPaddel().getLength());
            printStream.println();
            printStream.println("prizesnumber: ");
            printStream.println(this.models.getPrizes().size());
            printStream.println("prizes:");
            for(prize p:this.models.getPrizes()){
                printStream.println(p.getType());
                printStream.println(p.getX());
                printStream.println(p.getY());
            }
            printStream.println();
            printStream.println("prize_types_number:");
            printStream.println(this.models.getPrize_types().size());
            printStream.println("prize_types:");
            for(int i=0;i<this.models.getPrize_types().size();i++){
                int j=this.models.getPrize_types().get(i);
                printStream.println(j);


            }
            printStream.println(this.models.getCurrentplayer().getScore());
            printStream.println(this.models.getCurrentplayer().getHealth());
            printStream.flush();
            printStream.close();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

    }
    public void save_player_data(){
        File file= new File("database/playerfiles/"+this.models.getCurrentplayer().getName());
        if(!file.exists()){
            try {
                file.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        try {
            PrintStream printStream= new PrintStream(new FileOutputStream(file,false));
            printStream.println(this.models.getCurrentplayer().getName());



            printStream.println(this.models.getCurrentplayer().getMaxscore());
            printStream.flush();
            printStream.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }
    public void scoreboradwrite(String name,int score){
        File file=new File("database/scoresfiles/scoreboard");
        if(this.ifc.getNames().contains(name)){
            int index=this.ifc.getNames().indexOf(name);
            this.ifc.getScores().set(index,score);
        }
        else {
            this.ifc.getNames().add(name);
            this.ifc.getScores().add(score);

        }
        try {
            PrintStream printStream= new PrintStream(new FileOutputStream(file,false));
            for(int i=0;i<this.ifc.getNames().size();i++){
                printStream.println(this.ifc.getNames().get(i));
                printStream.println(this.ifc.getScores().get(i));
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }


    }


}
