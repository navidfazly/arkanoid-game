package modelsls;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

import Timer.timer;
import balls.ball;
import boxes.*;
import model.models;
import paddel.padel;
import players.player;
import prizez.prize;

import java.io.File;

public class modelloader {


    public models loadgame(String name, player p){
        File file=new File("database/savedgames/");
        boolean flag=false;
        for (File f:file.listFiles()){
            if(f.getName().equals(p.getName())){
                flag=true;

            }
        }
        File file1;
        if(flag){

            file=new File("database/savedgames/"+p.getName());
            for (File f:file.listFiles()){
                if(f.getName().equals(name)){

                    file1=f;
                    try {
                        Scanner scanner=new Scanner(file1);
                        scanner.next();
                        models  loaded_model= new models(p);
                        ArrayList<box> boxes=new ArrayList<>();
                        ArrayList<ball> balls=new ArrayList<ball>();
                        ArrayList<Integer> prize_types=new ArrayList<>();
                        ArrayList<prize> prizes= new ArrayList<>();
                        ArrayList<timer> timers=new ArrayList<>();
                        int box_nums=scanner.nextInt();
                        scanner.next();
                        //loading boxes
                        for(int i=0;i<box_nums;i++){
                            int type=scanner.nextInt();
                            if(type==1){
                                flasherbox flasherbox=new flasherbox();
                                int prizee=scanner.nextInt();
                                int health=scanner.nextInt();
                                flasherbox.setHealth(health);
                                int x=scanner.nextInt();
                                int y=scanner.nextInt();
                                flasherbox.setType(type);
                                flasherbox.setPrize(prizee);
                                flasherbox.setX(x);
                                flasherbox.setY(y);
                                flasherbox.setWidth(50);
                                flasherbox.setHeight(10);
                                boxes.add(flasherbox);
                            }
                            if(type==2){
                                glaasbox glaasbox= new glaasbox();
                                glaasbox.setType(type);
                                int prizee=scanner.nextInt();
                                int health=scanner.nextInt();
                                glaasbox.setHealth(health);
                                int x=scanner.nextInt();
                                int y=scanner.nextInt();
                                glaasbox.setPrize(prizee);
                                glaasbox.setX(x);
                                glaasbox.setY(y);
                                glaasbox.setWidth(50);
                                glaasbox.setHeight(10);
                                boxes.add(glaasbox);
                            }
                            if(type==3){
                                invisiblebox invisiblebox= new invisiblebox();
                                invisiblebox.setType(type);
                                int prizee=scanner.nextInt();
                                int health=scanner.nextInt();
                                invisiblebox.setHealth(health);
                                int x=scanner.nextInt();
                                int y=scanner.nextInt();
                                invisiblebox.setPrize(prizee);
                                invisiblebox.setX(x);
                                invisiblebox.setY(y);
                                invisiblebox.setWidth(50);
                                invisiblebox.setHeight(10);
                                boxes.add(invisiblebox);
                            }
                            if(type==4){
                                woodenbox woodenbox = new woodenbox();
                                woodenbox.setType(type);
                                int prizee=scanner.nextInt();
                                int health=scanner.nextInt();
                                woodenbox.setHealth(health);
                                int x=scanner.nextInt();
                                int y=scanner.nextInt();
                                woodenbox.setPrize(prizee);
                                woodenbox.setX(x);
                                woodenbox.setY(y);
                                woodenbox.setWidth(50);
                                woodenbox.setHeight(10);
                                boxes.add(woodenbox);
                            }
                            if(type==5){
                                prizebox prizebox= new prizebox();
                                prizebox.setType(type);
                                int prizee=scanner.nextInt();
                                int health=scanner.nextInt();
                                prizebox.setHealth(health);
                                int x=scanner.nextInt();
                                int y=scanner.nextInt();
                                prizebox.setPrize(prizee);
                                prizebox.setX(x);
                                prizebox.setY(y);
                                prizebox.setWidth(50);
                                prizebox.setHeight(10);
                                boxes.add(prizebox);
                            }


                        }
                        scanner.next();
                        int ball_nums=scanner.nextInt();
                        scanner.next();
                        for(int i=0;i<ball_nums;i++){
                            ball b= new ball();
                            int x=scanner.nextInt();
                            int y=scanner.nextInt();
                            int xv=scanner.nextInt();
                            int yv=scanner.nextInt();
                            int r=scanner.nextInt();
                            boolean isf=scanner.nextBoolean();
                            b.setX(x);
                            b.setY(y);
                            b.setXvelocity(xv);
                            b.setYvelocity(yv);
                            b.setFireball(isf);
                            b.setR(r);
                            balls.add(b);
                        }
                        scanner.next();
                        padel pad=new padel();
                        int x=scanner.nextInt();
                        int y=scanner.nextInt();
                        int height=scanner.nextInt();
                        int width=scanner.nextInt();
                        pad.setLength(width);
                        pad.setHeight(height);
                        pad.setX(x);
                        pad.setY(y);
                        scanner.next();
                        int prize_num=scanner.nextInt();
                        scanner.next();
                        for(int i=0;i<prize_num;i++){
                            int type=scanner.nextInt();
                            x=scanner.nextInt();
                            y=scanner.nextInt();
                            prize prize=new prize();
                            prize.setX(x);
                            prize.setY(y);
                            prize.setType(type);
                        }
                        scanner.next();
                        int prize_types1=scanner.nextInt();
                        scanner.next();
                        for(int i=0;i<prize_types1;i++){
                            int p_type= scanner.nextInt();
                            prize_types.add(p_type);
                            timer t=new timer();
                            timers.add(t);
                        }
                        int sc=scanner.nextInt();
                        int hel=scanner.nextInt();
                        p.setHealth(hel);
                        p.setScore(sc);
                        loaded_model.setBalls(balls);
                        loaded_model.setBoxes(boxes);
                        loaded_model.setPrize_types(prize_types);

                        loaded_model.setTimers(timers);
                        loaded_model.setPaddel(pad);
                        loaded_model.setCurrentplayer(p);
                        loaded_model.setPrizes(prizes);

                        scanner.close();
                        return loaded_model;

                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
        else {
            //you have no saved game
        }

        return null;
    }
    public player makeplayer(String name){
        player player=new player();
        File file=new File("database/playerfiles");
        boolean flag=false;
        for(File f:file.listFiles()){
            if(f.getName().equals(name)){
                player.setName(name);
                flag=true;
                try {
                    Scanner scanner = new Scanner(f);
                    scanner.next();
                    player.setMaxscore(scanner.nextInt());
                    return player;

                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }

            }
        }
        if(!flag){
            player.setName(name);
            player.setMaxscore(0);
            return player;
        }
        return null;
    }
}
