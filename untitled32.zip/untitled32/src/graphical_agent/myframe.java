package graphical_agent;



import balls.ball;
import boxes.box;
import controller.ifcontroller;
import l.loop;
import logic.finallogic;
import logic.logic;
import model.models;
import paddel.padel;

import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.ArrayList;

public class myframe extends JFrame  implements KeyListener {

    models model;

    logic logic;
    ifcontroller ifc;
    public myframe(models md,ifcontroller ifc) {

        this.model=md;
        this.ifc=ifc;

        this.addKeyListener(this);
        this.setTitle("Arkanoid");
        this.setBackground(Color.BLACK);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(800,600);




        this.setVisible(true);

    }
    public void frame( ){



        if(this.model.getCurrentplayer().getHealth()==0){
            //finish game
            this.removeAll();
            this.setBackground(Color.BLACK);

        }
        else {

            canvass c=new canvass(this.model,this.ifc);

            this.setContentPane(c);

        }





    }


    public void savepanel(){
        saveframe saveframe=new saveframe(this.model,this.ifc);
        this.add(saveframe);
        this.setContentPane(saveframe);
        this.setFocusable(true);
        this.requestFocusInWindow();
    }
    public void fuck(){
        game_over g= new game_over() ;
        this.add(g);
    }

    @Override
    public void keyTyped(KeyEvent e) {
        if(this.model.getPrize_types().contains(4)) {
            if (e.getKeyChar() == 'd') {
                System.out.println(1);
                model.getPaddel().setX(model.getPaddel().getX() - 10);
            }
            if (e.getKeyChar() == 'a') {
                System.out.println(1);
                model.getPaddel().setX(model.getPaddel().getX() + 10);
            }
        }
        else{
            if (e.getKeyChar() == 'd') {
                System.out.println(1);
                model.getPaddel().setX(model.getPaddel().getX() + 10);
            }
            if (e.getKeyChar() == 'a') {
                System.out.println(1);
                model.getPaddel().setX(model.getPaddel().getX() - 10);
            }
        }
        if(e.getKeyChar()=='p'){
            this.model.setPauseflage(true);
            this.model.setCont_flag(false);
        }
        if(e.getKeyChar()=='r'){
            this.model.setReflag(true);

        }
        if(e.getKeyChar()=='s'){
            this.model.setSaveflage(true);
        }
        if(e.getKeyChar()=='c'){

            this.model.setPauseflage(false);
            this.model.setCont_flag(true);

        }
    }
    @Override
    public void keyPressed(KeyEvent e) {
        if(this.model.getPrize_types().contains(4)) {
            if (e.getKeyChar() == 'd') {
                System.out.println(1);
                model.getPaddel().setX(model.getPaddel().getX() - 10);
            }
            if (e.getKeyChar() == 'a') {
                System.out.println(1);
                model.getPaddel().setX(model.getPaddel().getX() + 10);
            }
        }
        else{
            if (e.getKeyChar() == 'd') {
                System.out.println(1);
                model.getPaddel().setX(model.getPaddel().getX() + 10);
            }
            if (e.getKeyChar() == 'a') {
                System.out.println(1);
                model.getPaddel().setX(model.getPaddel().getX() - 10);
            }
        }
        if(e.getKeyChar()=='p'){
            this.model.setPauseflage(true);
        }
        if(e.getKeyChar()=='r'){
            this.model.setReflag(true);

        }
        if(e.getKeyChar()=='s'){
            this.model.setSaveflage(true);
        }
        if(e.getKeyChar()=='c'){

            this.model.setPauseflage(false);
            this.model.setCont_flag(true);

        }
    }

    @Override
    public void keyReleased(KeyEvent e) {

    }
}









