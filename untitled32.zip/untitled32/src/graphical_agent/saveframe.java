package graphical_agent;

import controller.ifcontroller;
import model.models;
import modelsls.modelsaver;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class saveframe extends JPanel implements MouseListener {
    JButton b1;
    JTextField jf;
    models model;
    ifcontroller ifc;
    public saveframe(models models,ifcontroller ifc){
        this.ifc=ifc;
        this.model=models;
        this.setLayout(null);
        this.setBackground(Color.black);
         jf=new JTextField();
        jf.setBackground(Color.green);
        jf.setText("enter name of game");
        jf.setBounds(250,200,200,100);
        jf.setEditable(true);
         b1=new JButton();
        b1.setBounds(250,400,200,100);
        b1.setBackground(Color.green);
        b1.setText("Save!!!");

        b1.addMouseListener(this);
        this.add(jf);
        this.add(b1);
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        if(e.getSource()==b1){
            String s=jf.getText();
            modelsaver ms=new modelsaver(this.model,this.ifc);
            ms.save_model(s);
            System.exit(0);
        }

    }

    @Override
    public void mousePressed(MouseEvent e) {

    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }
}
