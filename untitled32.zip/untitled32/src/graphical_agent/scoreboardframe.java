package graphical_agent;

import controller.ifcontroller;

import javax.swing.*;
import java.awt.*;

public class scoreboardframe extends JFrame {
    ifcontroller ifc;
    public scoreboardframe(ifcontroller ifcontroller){
        this.ifc=ifcontroller;

        this.setBackground(Color.black);
        this.setSize(800,600);
        this.setTitle("Arkanoid");

        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);
    }
    public void paint(Graphics g){
        this.setBackground(Color.black);
        g.setColor(Color.black);
        g.drawRect(0,0,800,600);
        g.fillRect(0,0,800,600);

        Graphics2D g2= (Graphics2D) g;
        g2.setColor(Color.red);
        g2.setFont(new Font("TimesRoman", Font.PLAIN, 40));
        g2.drawString("top players",280,100);
        g2.setFont(new Font("TimesRoman", Font.PLAIN, 20));

        for(int i=0;i<this.ifc.getNames().size();i++){
            g2.setColor(Color.red);
            g2.setFont(new Font("TimesRoman", Font.PLAIN, 20));
            g2.drawString(String.valueOf(i+1)+" -"+this.ifc.getNames().get(i),300,(i+1)*50+130);

            g2.setFont(new Font("Times", Font.ITALIC, 15));
            g2.setColor(Color.cyan);
            g2.drawString("score: "+String.valueOf(this.ifc.getScores().get(i)),300,(i+1)*50+155);

        }
    }

}
