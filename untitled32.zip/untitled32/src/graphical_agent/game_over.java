package graphical_agent;

import javax.swing.*;
import java.awt.*;

public class game_over extends JComponent {

    public game_over(){
        this.setBackground(Color.red);


    }
    public  void end(Graphics g) {


        g.setFont(new Font("TimesRoman", Font.PLAIN, 50));
        g.setColor(Color.red)  ;// Here
        g.drawString("Game Over",300,300);
    }
    public void paint(Graphics g){
        end(g);
    }

}
