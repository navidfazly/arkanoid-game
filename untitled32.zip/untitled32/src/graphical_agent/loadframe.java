package graphical_agent;

import controller.ifcontroller;
import logic.finallogic;
import model.models;
import modelsls.modelloader;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.File;

public class loadframe extends JFrame implements MouseListener {
    models model;
    JButton b1;
    JButton b2;
    JButton b3;
    JButton b4;
    JButton b5;
    ifcontroller ifc;



    public loadframe(ifcontroller ifcontroller){
        this.setBackground(Color.BLACK);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(800,600);






      this.ifc=ifcontroller;
        this.setBackground(Color.black);
        this.setLayout(null);

        b1=new JButton();
        b2=new JButton();
        b3=new JButton();
        b4=new JButton();
        b5=new JButton();
        b1.setText("no game to load");
        b2.setText("no game to load");
        b3.setText("no game to load");
        b4.setText("no game to load");
        b5.setText("no game to load");
        File file=new File("database/savedgames/"+this.ifc.getPlayer().getName());
        if(file.exists())
        {
            int ind=0;
            for(File f:file.listFiles()){
                ind++;
                if(ind==1){
                    b1.setText(f.getName());
                }
                if(ind==2){
                    b2.setText(f.getName());
                }
                if(ind==3){
                    b3.setText(f.getName());
                }
                if(ind==4){
                    b4.setText(f.getName());
                }
                if(ind==5){
                    b5.setText(f.getName());
                }
            }
        }


        b1.setBounds(280,50,200,80);

        b1.setBackground(Color.GREEN);
        b1.addMouseListener(this);

        b2.setBounds(280,160,200,80);

        b2.setBackground(Color.green);
        b2.addMouseListener(this);


        b3.setBounds(280,270,200,80);
        b4.setBounds(280,380,200,80);
        b5.setBounds(280,490,200,80);
        b3.setBackground(Color.green);
        b3.addMouseListener(this);
        b4.setBackground(Color.green);
        b5.setBackground(Color.green);
        b4.addMouseListener(this);
        b5.addMouseListener(this);
        JPanel panel=new JPanel();
        panel.setLayout(null);
        panel.add(b1);
        panel.add(b2);
        panel.add(b3);
        panel.add(b4);
        panel.add(b5);
        this.setContentPane(panel);
        this.setVisible(true);
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        modelloader modelloader=new modelloader();
        if(e.getSource()==b1){
            if(!b1.getText().equals("no game to load")){
                this.ifc.setBttext(b1.getText());



            }
        }
        if(e.getSource()==b2){
            if(!b2.getText().equals("no game to load")){
                this.ifc.setBttext(b2.getText());



            }
        }
        if(e.getSource()==b3){
            if(!b3.getText().equals("no game to load")){
                this.ifc.setBttext(b3.getText());

            }
        }
        if(e.getSource()==b4){
            if(!b4.getText().equals("no game to load")){
                this.ifc.setBttext(b4.getText());


            }

        }
        if(e.getSource()==b5){
            if(!b5.getText().equals("no game to load")){
                this.ifc.setBttext(b5.getText());


            }

        }
    }

    @Override
    public void mousePressed(MouseEvent e) {

    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }
}
