package graphical_agent;

import controller.ifcontroller;
import model.models;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class sframe extends JFrame implements MouseListener {
    JButton label1;
    JButton label2;
    JButton label3;
    ifcontroller ifc;
    public sframe(ifcontroller ifcontroller){
        this.ifc=ifcontroller;
        this.setLayout(null);
        this.setBackground(Color.black);

        this.setTitle("Arkanoid");
        this.setBackground(Color.BLACK);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(800,600);
        label1=new JButton();

        label1.setBounds(280,100,200,80);
        label1.setText("Start new game");
        label1.setBackground(Color.GREEN);
        label1.addMouseListener(this);
        label2=new JButton();
        label2.setBounds(280,210,200,80);
        label2.setText("load games");
        label2.setBackground(Color.green);
        label2.addMouseListener(this);
        label3=new JButton();

        label3.setBounds(280,320,200,80);
        label3.setBackground(Color.green);
        label3.addMouseListener(this);
        label3.setText("score board");
        JPanel panel=new JPanel();
        panel.setLayout(null);
        panel.setBackground(Color.black);
        panel.add(label1);
        panel.add(label2);
        panel.add(label3);
        this.setContentPane(panel);
        this.setVisible(true);



    }


    @Override
    public void mouseClicked(MouseEvent e) {

        if(e.getSource()==label1){
            this.ifc.setGame_flag(true);
            System.out.println(1);

        }
        if(e.getSource()==label2){
            this.ifc.setLoad_flag(true);
            System.out.println(2);
        }
        if(e.getSource()==label3){
            this.ifc.setScoreboard_flag(true);
            System.out.println(3);
        }





    }

    @Override
    public void mousePressed(MouseEvent e) {

    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }
}
