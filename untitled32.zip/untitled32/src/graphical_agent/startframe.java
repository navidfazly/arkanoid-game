package graphical_agent;

import controller.ifcontroller;
import model.models;
import modelsls.modelloader;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class startframe extends JFrame implements MouseListener {
    JTextField jf;
    JButton b1;
    models  md;
    ifcontroller ifc;
    public startframe(ifcontroller ifcontroller){

        this.ifc=ifcontroller;
        this.setLayout(null);
        this.setBackground(Color.black);

        this.setTitle("Arkanoid");
        this.setBackground(Color.BLACK);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(800,600);        jf=new JTextField();
        JTextField k=new JTextField();
        k.setBackground(Color.blue);
        k.setFont(new Font("TimesRoman", Font.ITALIC, 40));

        k.setText(" Arkanoid");
        k.setBounds(270,50,200,80);
        k.setEditable(false);
        jf.setText("enter your name");
        jf.setBackground(Color.green);
        jf.setBounds(270,150,200,80);
        jf.setEditable(true);
        b1=new JButton();
        b1.setBounds(270,300,200,100);
        b1.setBackground(Color.green);
        b1.setText("GO");

        b1.addMouseListener(this);
        JPanel panel=new JPanel();
        panel.setBackground(Color.black);
        panel.setLayout(null);
        panel.add(k);
        panel.add(jf);
        panel.add(b1);
        this.setContentPane(panel);
        this.setVisible(true);
    }
    @Override
    public void mouseClicked(MouseEvent e) {
        if(e.getSource()==b1){
            modelloader modelloader=new modelloader();

            this.ifc.setPlayerflag(true);
            this.ifc.setPlayer(modelloader.makeplayer(jf.getText()));
            System.out.println("yes");
        }

    }

    @Override
    public void mousePressed(MouseEvent e) {

    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }
}
