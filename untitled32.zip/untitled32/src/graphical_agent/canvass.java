package graphical_agent;



import balls.ball;
import boxes.box;
import controller.ifcontroller;
import model.models;
import modelsls.modelsaver;
import paddel.padel;
import prizez.prize;
import sun.font.Font2D;

import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.geom.Area;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Random;

public class canvass extends JComponent implements MouseListener {
    models model;
    ifcontroller ifc;
    public canvass(models md,ifcontroller ifcontroller){
        this.model=md;
        this.ifc=ifcontroller;
    }
    public void paint(Graphics g) {

        if(this.model.getCurrentplayer().getHealth()==0){
            game_over(g);
            if(this.model.getCurrentplayer().getScore()>this.model.getCurrentplayer().getMaxscore()){
                this.model.getCurrentplayer().setMaxscore(this.model.getCurrentplayer().getScore());
            }
            modelsaver  ms=new modelsaver(this.model,this.ifc);
            ms.save_player_data();
            ms.scoreboradwrite(this.model.getCurrentplayer().getName(),this.model.getCurrentplayer().getMaxscore());
            
        }
        else if(check_box_wall()){
            game_over(g);
            if(this.model.getCurrentplayer().getScore()>this.model.getCurrentplayer().getMaxscore()){
                this.model.getCurrentplayer().setMaxscore(this.model.getCurrentplayer().getScore());
            }
            modelsaver  ms=new modelsaver(this.model,this.ifc);
            ms.save_player_data();
            ms.scoreboradwrite(this.model.getCurrentplayer().getName(),this.model.getCurrentplayer().getMaxscore());

        }
        else {
            Graphics2D g2 = (Graphics2D) g;
            ArrayList<Rectangle2D> rectangles_list = new ArrayList<>();
            ArrayList<Ellipse2D> ellipse2DS_list = new ArrayList<>();
            ArrayList<Ellipse2D> pr_el_list = new ArrayList<>();
            LocalTime lt = LocalTime.now();
            int second = lt.getSecond();
            this.model.handle_prizes();

            for (prize p : model.getPrizes()) {
                Ellipse2D pr_el = new Ellipse2D.Float(p.getX(), p.getY(), 13, 25);
                if(p.getType()==1){
                    g2.setColor(Color.orange);
                }
                if(p.getType()==2){
                    g2.setColor(Color.darkGray);
                }
                if(p.getType()==5){
                    g2.setColor(Color.lightGray);
                }
                if(p.getType()==3){
                    g2.setColor(Color.cyan);
                }
                if(p.getType()==4){
                    g2.setColor(Color.red);
                }

                if(p.getType()==6){
                    g2.setColor(Color.yellow);
                }
                if(p.getType()==7){
                    g2.setColor(Color.white);
                }

                g2.draw(pr_el);
                g2.fill(pr_el);
                pr_el_list.add(pr_el);
                System.out.println(p.getType());
            }
            for (box box : model.getBoxes()) {
                Rectangle2D rec2d = new Rectangle2D.Float(box.getX(), box.getY(), box.getWidth(), box.getHeight());
                rectangles_list.add(rec2d);
                //flasher

                if (box.getType() == 1) {

                    if (second % 2 == 1) {
                        g2.setColor(Color.magenta);
                        g2.draw(rec2d);
                        g2.fill(rec2d);
                    } else {

                    }

                }
                //glass
                if (box.getType() == 2) {

                    g2.setColor(Color.gray);
                    g2.draw(rec2d);
                    g2.fill(rec2d);
                }
                //invisible
                if (box.getType() == 3) {

                }
                //wooden
                if (box.getType() == 4) {

                    g2.setColor(Color.ORANGE);
                    g2.draw(rec2d);
                    g2.fill(rec2d);
                }
                if (box.getType() == 5) {
                    g2.setColor(Color.green);
                    g2.draw(rec2d);
                    g2.fill(rec2d);
                }

            }
            for (ball ball : model.getBalls()) {
                Ellipse2D elips = new Ellipse2D.Float(ball.getX(), ball.getY(), ball.getR(), ball.getR());
                ellipse2DS_list.add(elips);
                if (ball.isFireball()) {
                    g2.setColor(Color.orange);
                    g2.draw(elips);
                    g2.fill(elips);
                } else {
                    g2.setColor(Color.blue);
                    g2.draw(elips);
                    g2.fill(elips);
                }


            }
            Rectangle2D pad_rec = new Rectangle2D.Float(this.model.getPaddel().getX(), this.model.getPaddel().getY(), this.model.getPaddel().getLength(), this.model.getPaddel().getHeight());
            g2.setColor(Color.GREEN);
            g2.draw(pad_rec);
            g2.fill(pad_rec);
            //check box and ball intersects
            int num = -1;
            for (int i = 0; i < rectangles_list.size(); i++) {

                for (int j = 0; j < ellipse2DS_list.size(); j++) {
                    if(checkintersect(rectangles_list.get(i),ellipse2DS_list.get(j))){

                        if (!this.model.getBalls().get(j).isFireball()) {
                            /*if (check_baghal(this.model.getBoxes().get(i), this.model.getBalls().get(j))) {
                                if (this.model.getBoxes().get(i).getType() == 1) {
                                    if (second % 2 == 1) {
                                        this.model.getBalls().get(j).setXvelocity(-this.model.getBalls().get(j).getXvelocity());
                                        this.model.getBalls().get(j).setX(this.model.getBalls().get(j).getX() + this.model.getBalls().get(j).getXvelocity() * 10);

                                        num = i;
                                    }

                                }
                                if (this.model.getBoxes().get(i).getType() == 2) {

                                    this.model.getBalls().get(j).setXvelocity(-this.model.getBalls().get(j).getXvelocity());
                                    this.model.getBalls().get(j).setX(this.model.getBalls().get(j).getX() + this.model.getBalls().get(j).getXvelocity() * 10);

                                    num = i;


                                }
                                if (this.model.getBoxes().get(i).getType() == 3) {
                                    this.model.getBalls().get(j).setXvelocity(-this.model.getBalls().get(j).getXvelocity());
                                    this.model.getBalls().get(j).setX(this.model.getBalls().get(j).getX() + this.model.getBalls().get(j).getXvelocity() * 10);

                                    num = i;


                                }
                                if (this.model.getBoxes().get(i).getType() == 4) {
                                    this.model.getBalls().get(j).setXvelocity(-this.model.getBalls().get(j).getXvelocity());
                                    this.model.getBalls().get(j).setX(this.model.getBalls().get(j).getX() + this.model.getBalls().get(j).getXvelocity() * 10);

                                    num = i;


                                }
                                if (this.model.getBoxes().get(i).getType() == 5) {
                                    this.model.getBalls().get(j).setXvelocity(-this.model.getBalls().get(j).getXvelocity());
                                    this.model.getBalls().get(j).setX(this.model.getBalls().get(j).getX() + this.model.getBalls().get(j).getXvelocity() * 5);
                                    num = i;
                                }
                            }*/
                                if (this.model.getBoxes().get(i).getType() == 1) {
                                    if (second % 2 == 1) {
                                        this.model.getBalls().get(j).setYvelocity(-this.model.getBalls().get(j).getYvelocity());
                                        this.model.getBalls().get(j).setY(this.model.getBalls().get(j).getY() + this.model.getBalls().get(j).getYvelocity() * 5);
                                        num = i;
                                    }

                                }
                                if (this.model.getBoxes().get(i).getType() == 2) {

                                    this.model.getBalls().get(j).setYvelocity(-this.model.getBalls().get(j).getYvelocity());
                                    this.model.getBalls().get(j).setY(this.model.getBalls().get(j).getY() + this.model.getBalls().get(j).getYvelocity() * 10);
                                    num = i;


                                }
                                if (this.model.getBoxes().get(i).getType() == 3) {
                                    this.model.getBalls().get(j).setYvelocity(-this.model.getBalls().get(j).getYvelocity());
                                    this.model.getBalls().get(j).setY(this.model.getBalls().get(j).getY() + this.model.getBalls().get(j).getYvelocity() * 10);
                                    num = i;


                                }
                                if (this.model.getBoxes().get(i).getType() == 4) {
                                    this.model.getBalls().get(j).setYvelocity(-this.model.getBalls().get(j).getYvelocity());
                                    this.model.getBalls().get(j).setY(this.model.getBalls().get(j).getY() + this.model.getBalls().get(j).getYvelocity() * 10);
                                    num = i;


                                }
                                if (this.model.getBoxes().get(i).getType() == 5) {
                                    this.model.getBalls().get(j).setYvelocity(-this.model.getBalls().get(j).getYvelocity());
                                    this.model.getBalls().get(j).setY(this.model.getBalls().get(j).getY() + this.model.getBalls().get(j).getYvelocity() * 10);
                                    num = i;
                                }



                        }else {
                            num = i;
                        }
                    }


                }
            }
            if (num != -1) {
                if (!this.model.getBalls().get(0).isFireball()) {
                    this.model.getBoxes().get(num).setHealth(this.model.getBoxes().get(num).getHealth() - 1);
                    if (this.model.getBoxes().get(num).getHealth() == 0) {
                        if (this.model.getBoxes().get(num).getPrize() != 0) {
                            prize prize = new prize();
                            prize.setType(this.model.getBoxes().get(num).getPrize());
                            prize.setX(this.model.getBoxes().get(num).getX());
                            prize.setY(this.model.getBoxes().get(num).getY());
                            this.model.getPrizes().add(prize);
                        }
                        this.model.getCurrentplayer().setScore(this.model.getCurrentplayer().getScore()+1);
                        this.model.getBoxes().remove(num);
                        rectangles_list.remove(num);
                    }
                } else {
                    this.model.getCurrentplayer().setScore(this.model.getCurrentplayer().getScore()+1);
                    this.model.getBoxes().remove(num);
                    rectangles_list.remove(num);
                }

            }
            for (int i = 0; i < model.getBalls().size(); i++) {
                if (this.model.getBalls().get(i).getX() - this.model.getBalls().get(i).getR() <= 0) {
                    this.model.getBalls().get(i).setXvelocity(-this.model.getBalls().get(i).getXvelocity());
                    this.model.getBalls().get(i).setX(this.model.getBalls().get(i).getX() + 5);
                }
                if (this.model.getBalls().get(i).getX() + this.model.getBalls().get(i).getR() >= 800) {
                    this.model.getBalls().get(i).setXvelocity(-this.model.getBalls().get(i).getXvelocity());
                    this.model.getBalls().get(i).setX(this.model.getBalls().get(i).getX() - 5);
                }
                if (this.model.getBalls().get(i).getY() - this.model.getBalls().get(i).getR() <= 0) {
                    this.model.getBalls().get(i).setYvelocity(-this.model.getBalls().get(i).getYvelocity());
                    this.model.getBalls().get(i).setY(this.model.getBalls().get(i).getY() + 5);
                }
            }

            //check ball and padel intersectiona
            for (int i = 0; i < this.model.getBalls().size(); i++) {
                if (pad_rec.getBounds2D().intersects(ellipse2DS_list.get(i).getBounds2D())) {
                    this.model.getBalls().get(i).setYvelocity(-this.model.getBalls().get(i).getYvelocity());
                    this.model.getBalls().get(i).setY(this.model.getBalls().get(i).getY()-8);
                }
            }
            //check padel and prizes intersection
            int index = -1;
            for (int i = 0; i < pr_el_list.size(); i++) {
                if (pad_rec.getBounds2D().intersects(pr_el_list.get(i).getBounds2D())) {
                    index = i;
                }
            }
            if (index != -1) {
                pr_el_list.remove(index);
                int type = this.model.getPrizes().get(index).getType();
                this.model.getPrizes().remove(index);
                if(type==7){
                    Random r=new Random();
                    type=r.nextInt(5)+1;
                }
                this.model.add_timer_p(type);
            }
            this.model.update_timer_p();
            //check balls intersect down wall
            int y = -1;
            for (int in = 0; in < this.model.getBalls().size(); in++) {
                if (this.model.getBalls().get(in).getY() + this.model.getBalls().get(in).getR() >= 700) {
                    y = in;
                }
            }
            if (y != -1) {
                this.model.getBalls().remove(y);

                if (this.model.getCurrentplayer().getHealth() > 0 && this.model.getBalls().size() == 0) {
                    this.model.getCurrentplayer().setHealth(this.model.getCurrentplayer().getHealth() - 1);
                    this.model.make_ball(1);
                }
            }

            if (this.model.getTimer().getAgeInSeconds() % 20 == 0 && !this.model.isFlag()) {
                this.model.update_boxes();
                this.model.add_new_boxes();
                this.model.setFlag(true);
            }
            if (this.model.getTimer().getAgeInSeconds() % 21 == 0 && this.model.isFlag()) {
                this.model.setFlag(false);
            }
            //draw health
            end(g);
            pausee(g);
            restart(g);
            savee(g);
            score(g);
            //check box and wall intersection

        }








    }
    public boolean checkintersect(Shape a, Shape b){
         return  a.getBounds2D().intersects(b.getBounds2D());
    }
    public boolean check_prize_out(){
    return  false;
    }
    public  void end(Graphics g) {


        g.setFont(new Font("TimesRoman", Font.PLAIN, 24));
        g.setColor(Color.red)  ;// Here
        g.drawString("heath: "+String.valueOf(this.model.getCurrentplayer().getHealth()),30,500);
    }
    public  void score(Graphics g) {


        g.setFont(new Font("TimesRoman", Font.PLAIN, 24));
        g.setColor(Color.red)  ;// Here
        g.drawString("score: "+String.valueOf(this.model.getCurrentplayer().getScore()),30,540);
    }
    public void game_over(Graphics g){
        g.setFont(new Font("TimesRoman", Font.PLAIN, 50));
        g.setColor(Color.red)  ;// Here
        g.drawString("GAME OVER!!!",200,300);
        g.setFont(new Font("TimesRoman", Font.PLAIN, 30));
        g.drawString(this.model.getCurrentplayer().getName(),250,400);
        g.drawString("score:  "+String.valueOf(this.model.getCurrentplayer().getScore()),250,500);
    }
    public void pausee(Graphics g){
        g.setFont(new Font("TimesRoman", Font.PLAIN, 12));
        g.setColor(Color.yellow)  ;// Here
        g.drawString("p for pause",33,450);
    }
    public void restart(Graphics g){
        g.setFont(new Font("TimesRoman", Font.PLAIN, 12));
        g.setColor(Color.yellow)  ;// Here
        g.drawString("r for restart",33,465);

    }
    public void savee(Graphics g){
        g.setFont(new Font("TimesRoman", Font.PLAIN, 12));
        g.setColor(Color.yellow)  ;// Here
        g.drawString("s for save",33,480);

    }


    @Override
    public void mouseClicked(MouseEvent e) {

    }

    @Override
    public void mousePressed(MouseEvent e) {

    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }
    public boolean check_box_wall(){
        for(box b:this.model.getBoxes()){
            if(b.getY()>580){
                return true;
            }
        }
        return false;
    }
    public boolean check_baghal(box box,ball ball){
        if(ball.getX()+ball.getR()<=box.getX()-2 || ball.getX()-ball.getR()>=box.getX()-2){
            return true;
        }
        return false;
    }

}

