package prizez;

public class fireball  extends prize{

}
