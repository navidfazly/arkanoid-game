package prizez;

public class speedyball  extends prize{
}
