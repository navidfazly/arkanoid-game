package prizez;

public class  madpad extends prize{
}
