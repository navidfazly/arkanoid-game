package prizez;

public class shortpad extends prize {
}
