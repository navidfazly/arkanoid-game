package prizez;

public class long_pad  extends prize{
}
