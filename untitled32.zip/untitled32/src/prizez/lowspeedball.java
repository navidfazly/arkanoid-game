package prizez;

public class lowspeedball  extends prize {
}
