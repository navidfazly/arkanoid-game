import balls.ball;
import controller.ifcontroller;
import graphical_agent.loadframe;
import graphical_agent.myframe;
import graphical_agent.sframe;
import graphical_agent.startframe;
import l.loop;
import logic.finallogic;
import logic.initialize;
import model.models;
import modelsls.modelloader;
import players.player;

import javax.swing.*;

public class main {

    public static void main (String[] args) {
        initialize  initialize=new initialize();
        initialize.run();
        //finallogic fl=new finallogic(model);
       // fl.run();


















    }
}
