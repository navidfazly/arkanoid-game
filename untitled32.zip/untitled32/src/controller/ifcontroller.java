package controller;

import players.player;

import java.io.FileNotFoundException;
import  java.util.Scanner;
import java.io.File;
import java.util.ArrayList;

public class ifcontroller {
    public ifcontroller(){
        File file=new File("database/scoresfiles/scoreboard");
        try {
            Scanner sc=new Scanner(file);
            while (sc.hasNext()){
                String nam=sc.next();
                int scoree=sc.nextInt();
                names.add(nam);
                scores.add(scoree);
            }
            sc.close();
            sortscores();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }
    boolean game_flag=false;
    boolean load_flag=false;
    boolean scoreboard_flag=false;
    boolean playerflag=false;
    player player;
    String bttext;
    ArrayList<String> names=new ArrayList<>();
    ArrayList<Integer> scores=new ArrayList<>();

    public ArrayList<String> getNames() {
        return names;
    }

    public void setNames(ArrayList<String> names) {
        this.names = names;
    }

    public ArrayList<Integer> getScores() {
        return scores;
    }

    public void setScores(ArrayList<Integer> scores) {
        this.scores = scores;
    }

    public String getBttext() {
        return bttext;
    }

    public void setBttext(String bttext) {
        this.bttext = bttext;
    }

    public players.player getPlayer() {
        return player;
    }

    public void setPlayer(players.player player) {
        this.player = player;
    }

    public boolean isPlayerflag() {
        return playerflag;
    }

    public void setPlayerflag(boolean playerflag) {
        this.playerflag = playerflag;
    }

    public boolean isGame_flag() {
        return game_flag;
    }

    public void setGame_flag(boolean game_flag) {
        this.game_flag = game_flag;
    }

    public boolean isLoad_flag() {
        return load_flag;
    }

    public void setLoad_flag(boolean load_flag) {
        this.load_flag = load_flag;
    }

    public boolean isScoreboard_flag() {
        return scoreboard_flag;
    }

    public void setScoreboard_flag(boolean scoreboard_flag) {
        this.scoreboard_flag = scoreboard_flag;
    }
    public void sortscores(){
        for(int i=0;i<this.getNames().size();i++){
            for(int j=0;j<this.getNames().size();j++){
                if(this.getScores().get(i)<this.getScores().get(j)){
                    int kkk=this.getScores().get(j);
                    this.getScores().set(j,this.getScores().get(i));
                    this.getScores().set(i,kkk);
                    String nammm=this.getNames().get(j);
                    this.getNames().set(j,this.getNames().get(i));
                    this.getNames().set(i,nammm);
                }
            }
        }
    }
}
