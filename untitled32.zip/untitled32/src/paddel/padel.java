package paddel;

public class padel {
    int x;
    int y;
    int length;
    int height;
    int ussuall_height=1;
    int ussuall_length=60;

    public int getUssuall_height() {
        return ussuall_height;
    }

    public void setUssuall_height(int ussuall_height) {
        this.ussuall_height = ussuall_height;
    }

    public int getUssuall_length() {
        return ussuall_length;
    }

    public void setUssuall_length(int ussuall_length) {
        this.ussuall_length = ussuall_length;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public int getLength() {
        return length;
    }

    public void setLength(int length) {
        this.length = length;
    }
}
