package model;

import Timer.timer;
import balls.ball;
import boxes.*;
import paddel.padel;
import players.player;
import prizez.*;

import java.util.ArrayList;
import java.util.Random;

public class models {
    public models(player player){
        this.currentplayer=player;
    }
    public player getCurrentplayer() {
        return currentplayer;
    }

    public void setCurrentplayer(player currentplayer) {
        this.currentplayer = currentplayer;
    }
    boolean flag=false;

    public boolean isFlag() {
        return flag;
    }

    public void setFlag(boolean flag) {
        this.flag = flag;
    }

    player currentplayer;
    ArrayList<ball> balls=new ArrayList<ball>();
    ArrayList<box> boxes=new ArrayList<box>();
    ArrayList<prize> prizes= new ArrayList<>();
    ArrayList<timer> timers=new ArrayList<>();
    ArrayList<Integer> prize_types=new ArrayList<>();
    timer timer= new timer();
    padel paddel=new padel();
    boolean reflag=false;


    public boolean isPlayerflag() {
        return playerflag;
    }

    public void setPlayerflag(boolean playerflag) {
        this.playerflag = playerflag;
    }


    boolean playerflag=false;
    boolean pauseflage=false;
    boolean saveflage=false;
    boolean cont_flag=true;

    public boolean isReflag() {
        return reflag;
    }

    public void setReflag(boolean reflag) {
        this.reflag = reflag;
    }

    public boolean isPauseflage() {
        return pauseflage;
    }

    public void setPauseflage(boolean pauseflage) {
        this.pauseflage = pauseflage;
    }

    public boolean isSaveflage() {
        return saveflage;
    }

    public void setSaveflage(boolean saveflage) {
        this.saveflage = saveflage;
    }

    boolean game_flag=false;
    boolean load_flag=false;
    boolean scoreboard_flag=false;

    public boolean isGame_flag() {
        return game_flag;
    }

    public void setGame_flag(boolean game_flag) {
        this.game_flag = game_flag;
    }

    public boolean isLoad_flag() {
        return load_flag;
    }

    public void setLoad_flag(boolean load_flag) {
        this.load_flag = load_flag;
    }

    public boolean isScoreboard_flag() {
        return scoreboard_flag;
    }

    public void setScoreboard_flag(boolean scoreboard_flag) {
        this.scoreboard_flag = scoreboard_flag;
    }

    public ArrayList<prize> getPrizes() {
        return prizes;
    }

    public void setPrizes(ArrayList<prize> prizes) {
        this.prizes = prizes;
    }


    public void make_boxes_at_start(){
        for(int j=0;j<3;j++) {
            for (int i = 0; i < 13; i++) {
                if((j*13+i)%16==0){
                    Random random=new Random();
                    int r=random.nextInt(6)+1;


                    prizebox box= new prizebox();
                    box.setPrize(r);
                    box.setType(5);

                    box.setX(i * 60+20);
                    box.setY(j*30+30);
                    boxes.add(box);
                }
                else if((j*13+i)%4==0){
                    flasherbox box = new flasherbox();
                    box.setX(i * 60+20);
                    box.setY(j*30+30);
                    box.setType(1);
                    boxes.add(box);
                }
                else if((j*13+i)%4==1){
                    glaasbox box = new glaasbox();
                    box.setX(i * 60+20);
                    box.setY(j*30+30);
                    box.setType(2);
                    boxes.add(box);
                }
                else if((j*13+i)%4==2){
                    invisiblebox box=new invisiblebox();
                    box.setX(i * 60+20);
                    box.setY(j*30+30);
                    box.setType(3);
                    boxes.add(box);
                }
                else if((j*13+i)%4==3){
                    woodenbox box=new woodenbox();
                    box.setX(i * 60+20);
                    box.setY(j*30+30);
                    box.setType(4);
                    box.setHealth(3);
                    boxes.add(box);
                }

            }
        }

    }
    public void make_ball(int i){
        for(int x=0;x<i;x++){
            ball ball=new ball();
            ball.setR(13);
            ball.setX(paddel.getX()+30);
            ball.setY(paddel.getY()-20);
            balls.add(ball);

        }


    }
    public void make_secondry_balls(int i){
        for(int x=0;x<i;x++){
            ball ball=new ball();
            ball.setR(13);
            ball.setX(100+x*200);
            ball.setY(200+x*200);
            balls.add(ball);

        }

    }
    public void make_paddel(){
        paddel.setX(600);
        paddel.setY(550);
        paddel.setHeight(30);
        paddel.setLength(60);
    }

    public ArrayList<ball> getBalls() {
        return balls;
    }

    public void setBalls(ArrayList<ball> balls) {
        this.balls = balls;
    }

    public ArrayList<box> getBoxes() {
        return boxes;
    }

    public void setBoxes(ArrayList<box> boxes) {
        this.boxes = boxes;
    }

    public padel getPaddel() {
        return paddel;
    }

    public void setPaddel(padel paddel) {
        this.paddel = paddel;
    }

    public void add_new_boxes(){
        Random random = new Random();
        int e=random.nextInt(12);
        for(int i=0;i<13;i++) {
            if (i==e) {

                int r = random.nextInt(5) + 1;


                prizebox box = new prizebox();
                box.setPrize(r);
                box.setType(5);

                box.setX(i * 60 + 20);
                box.setY( 20);
                boxes.add(box);
            }
            else if (i%4==0) {
                flasherbox box = new flasherbox();
                box.setX(i * 60 + 20);
                box.setY( 20);
                box.setType(1);
                boxes.add(box);
            }
            else if (i%4==1) {
                glaasbox box = new glaasbox();
                box.setX(i * 60 + 20);
                box.setY( 20);
                box.setType(2);
                boxes.add(box);
            }
            else if (i%4==2) {
                invisiblebox box = new invisiblebox();
                box.setX(i * 60 + 20);
                box.setY(20);
                box.setType(3);
                boxes.add(box);
            }
            else if (i%4==3) {
                woodenbox box = new woodenbox();
                box.setX(i * 60 + 20);
                box.setY( 20);
                box.setType(4);
                box.setHealth(2);
                boxes.add(box);
            }
        }
    }

    public Timer.timer getTimer() {
        return timer;
    }

    public void setTimer(Timer.timer timer) {
        this.timer = timer;
    }

    public void update_boxes(){
        for (box b:boxes){
            b.setY(b.getY()+30);

        }
    }
    public void run(){

        this.getCurrentplayer().setHealth(3);

        make_boxes_at_start();
        make_paddel();
        make_ball(1);
    }
    public void add_timer_p(int type){
        timer timer=new timer();
        timers.add(timer);
        prize_types.add(type);

    }
    public void update_timer_p(){
        if(timers.size()>0 && prize_types.size()>0) {
            if (timers.get(0).getAgeInSeconds() >= 7) {
                timers.remove(0);
                prize_types.remove(0);
            }
        }

    }
    public void restart(){
        balls.clear();
        prize_types.clear();
        prizes.clear();
        boxes.clear();
        this.paddel=new padel();
    }

    public ArrayList<timer> getTimers() {
        return timers;
    }

    public void setTimers(ArrayList<timer> timers) {
        this.timers = timers;
    }

    public ArrayList<Integer> getPrize_types() {
        return prize_types;
    }

    public void setPrize_types(ArrayList<Integer> prize_types) {
        this.prize_types = prize_types;
    }

    public boolean isCont_flag() {
        return cont_flag;
    }

    public void setCont_flag(boolean cont_flag) {
        this.cont_flag = cont_flag;
    }

    public void handle_prizes(){
        if(prize_types.contains(1)){

            for(ball ball:this.getBalls()){
                ball.setFireball(true);
            }
        }
        else{

            for(ball ball:this.getBalls()){
                ball.setFireball(false);
            }
        }

        if(prize_types.contains(2)){

            paddel.setLength(100);
        }

        if(prize_types.contains(3)){

            for(ball ball:this.getBalls()){
                if(ball.getXvelocity()==4){
                    ball.setXvelocity(2);
                }
                if(ball.getXvelocity()==-4){
                    ball.setXvelocity(-2);
                }
                if(ball.getXvelocity()==2){
                    ball.setXvelocity(1);
                }
                if(ball.getXvelocity()==-2){
                    ball.setXvelocity(-1);
                }



                if(ball.getYvelocity()==4){
                    ball.setYvelocity(2);
                }
                if(ball.getYvelocity()==-4){
                    ball.setYvelocity(-2);
                }
                if(ball.getYvelocity()==2){
                    ball.setYvelocity(1);
                }
                if(ball.getYvelocity()==-2){
                    ball.setYvelocity(-1);
                }
            }
        }


        if(prize_types.contains(5)){

            paddel.setLength(40);

        }

        if(prize_types.contains(6)){

            for(ball ball:this.getBalls()){
                if(ball.getXvelocity()==2){
                    ball.setXvelocity(4);
                }
                if(ball.getXvelocity()==-2){
                    ball.setXvelocity(-4);
                }
                if(ball.getXvelocity()==1){
                    ball.setXvelocity(2);
                }
                if(ball.getXvelocity()==-1){
                    ball.setXvelocity(-2);
                }



                if(ball.getYvelocity()==2){
                    ball.setYvelocity(4);
                }
                if(ball.getYvelocity()==-2){
                    ball.setYvelocity(-4);
                }
                if(ball.getYvelocity()==1){
                    ball.setYvelocity(2);
                }
                if(ball.getYvelocity()==-1){
                    ball.setYvelocity(-2);
                }
            }
        }
        if(prize_types.contains(7)){
            make_secondry_balls(2);
            prize_types.remove((Object)7);

        }
        if(!prize_types.contains(2) && !prize_types.contains(5) ){
            this.paddel.setLength(60);
        }
        if(!prize_types.contains(6) && !prize_types.contains(3)){
            for(ball ball:this.getBalls()){
                if(ball.getXvelocity()==4){
                    ball.setXvelocity(2);
                }
                if(ball.getXvelocity()==-4){
                    ball.setXvelocity(-2);
                }
                if(ball.getXvelocity()==1){
                    ball.setXvelocity(2);
                }
                if(ball.getXvelocity()==-1){
                    ball.setXvelocity(-2);
                }
                if(ball.getYvelocity()==4){
                    ball.setYvelocity(2);
                }
                if(ball.getYvelocity()==-4){
                    ball.setYvelocity(-2);
                }
                if(ball.getYvelocity()==1){
                    ball.setYvelocity(2);
                }
                if(ball.getYvelocity()==-1){
                    ball.setYvelocity(-2);
                }

            }
        }

    }


}
