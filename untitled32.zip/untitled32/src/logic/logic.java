package logic;

import balls.ball;
import boxes.box;
import model.models;
import paddel.padel;
import paddel.padel;
import prizez.prize;

import java.util.ArrayList;

public class logic {
    models model;

    public logic(models model){
        this.model=model;
    }

    public void update_ball(ball ball){
        ball.setY(ball.getY()+ball.getYvelocity());
        ball.setX(ball.getX()+ball.getXvelocity());

    }


    public void update_boxes(){
        for(box box:model.getBoxes()){
            box.setY(box.getY()+40);
        }
    }


    public void update_prize(){
        for(prize p:this.model.getPrizes()){
            p.setY(p.getY()+2);
        }
    }
    public void use_prize(prize p){
        //fire ball
        if(p.getType()==1){

        }
        //long pad
        if(p.getType()==2){

        }
        //low speed ball
        if(p.getType()==3){

        }
        //madpad
        if(p.getType()==4){

        }
        //shortpad
        if(p.getType()==5){

        }
        //speedy ball
        if(p.getType()==6){

        }
    }



}
