package logic;


import balls.ball;
import controller.ifcontroller;
import graphical_agent.*;
import l.loop;
import model.models;
import players.player;

import javax.swing.*;
import java.awt.*;

public class finallogic implements Runnable  {
    ifcontroller ifc;
    models md;


    public finallogic(ifcontroller ifcontroller, models models){
        this.ifc=ifcontroller;
        this.md=models;

    }

    public void run() {






            logic logic = new logic(this.md);
            myframe frame = new myframe(this.md,this.ifc);







                boolean flag=false;
                while (!this.md.isSaveflage()) {

                    if(!flag) {
                        try {
                            Thread.sleep(1000);
                            flag=true;
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }

                    if (this.md.getCurrentplayer().getHealth() == 0) {
                            //finish game
                            frame.removeAll();
                            frame.setBackground(Color.BLACK);

                        } else if (this.md.isReflag()) {

                            this.md.restart();
                            this.md.run();
                            this.md.setReflag(false);
                            frame.frame();

                        } else if (this.md.isPauseflage()) {
                            frame.frame();
                            try {
                                Thread.sleep(400);
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }

                        } else if (this.md.getCurrentplayer().getHealth() > 0) {

                            for (ball b : md.getBalls()) {
                                logic.update_ball(b);
                            }
                            logic.update_prize();
                            frame.frame();



                        }
                    frame.invalidate();
                    frame.validate();
                    frame.repaint();
                    try {
                        Thread.sleep(12);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }



                }





                frame.savepanel();
                frame.invalidate();
                frame.validate();
                frame.repaint();


            }

    }

