package logic;

import controller.ifcontroller;
import graphical_agent.loadframe;
import graphical_agent.scoreboardframe;
import graphical_agent.sframe;
import graphical_agent.startframe;
import model.models;
import modelsls.modelloader;

public class initialize implements Runnable {
    ifcontroller ifc=new ifcontroller();
    public initialize(){

    }

    public void run(){
        modelloader modelloader=new modelloader();

        startframe stf=new startframe(ifc);
        while (!ifc.isPlayerflag()){
            stf.invalidate();
            stf.validate();
            stf.repaint();
        }

        if(ifc.isPlayerflag()){
            stf.dispose();
            stf.setVisible(false);
            sframe sf=new sframe(ifc);
            while (!ifc.isGame_flag() && !ifc.isLoad_flag() &&!ifc.isScoreboard_flag()){
                sf.invalidate();
                sf.validate();
                sf.repaint();
            }
            sf.dispose();
            sf.setVisible(false);
            if(ifc.isGame_flag()){
                ifc.getPlayer().setHealth(3);
                models models=new models(ifc.getPlayer());
                models.run();
                finallogic finallogic=new finallogic(ifc,models);
                finallogic.run();

            }
            if(ifc.isLoad_flag()){
                loadframe loadframe=new loadframe(ifc);
                while (ifc.getBttext()==null){
                    loadframe.invalidate();
                    loadframe.validate();
                    loadframe.repaint();
                }
                loadframe.dispose();
                loadframe.setVisible(false);
                ifc.getPlayer().setHealth(3);
                models model=modelloader.loadgame(ifc.getBttext(),ifc.getPlayer());
                System.out.println(model.getBalls().get(0).getX());
                finallogic finallogic=new finallogic(ifc,model);
                finallogic.run();


            }
            if(ifc.isScoreboard_flag()){
                scoreboardframe scrf=new scoreboardframe(this.ifc);

                scrf.invalidate();
                scrf.validate();
                scrf.repaint();


            }
        }
    }
}
