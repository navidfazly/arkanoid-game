package balls;

public class ball {
    int x;
    int y;
    int type;
    int xvelocity = -2;
    int yvelocity = -2;
    int r;
    boolean fireball=false;

    public boolean isFireball() {
        return fireball;
    }

    public void setFireball(boolean fireball) {
        this.fireball = fireball;
    }

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public int getXvelocity() {
        return xvelocity;
    }

    public void setXvelocity(int xvelocity) {
        this.xvelocity = xvelocity;
    }

    public int getYvelocity() {
        return yvelocity;
    }

    public void setYvelocity(int yvelocity) {
        this.yvelocity = yvelocity;
    }

    public int getR() {
        return r;
    }

    public void setR(int r) {
        this.r = r;
    }


}